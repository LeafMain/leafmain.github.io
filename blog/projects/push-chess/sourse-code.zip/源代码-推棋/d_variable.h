#pragma once

namespace pushchess
{

}