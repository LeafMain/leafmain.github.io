﻿#include "picoloop.h"

// 游戏类实现
namespace picoloop
{
	const int Game::DEFUALT_SLEEP_TIME = 25; // 默认休眠时间

	// 处理事件
	void Game::_handle_events(ExMessage& event)
	{
		// 进入事件循环
		if (Page::current_page() != nullptr)
		{
			Page::current_page()->listen_event(event);
		}
	}

	// 创建必要的目录
	void Game::create_directories()
	{
		int result[4] = {0};
		result[0] = _mkdir("C:\\LeafMain");
		result[1] = _mkdir("C:\\LeafMain\\PicoLoop");
		result[2] = _mkdir("C:\\LeafMain\\PicoLoop\\Data");
		result[3] = _mkdir("C:\\LeafMain\\PicoLoop\\PrtSc");
		std::ofstream file;
		file.open("C:\\LeafMain\\PicoLoop\\Welcome.txt");
		if (file)
		{
			file << "Welcome to PicoLoop!" << std::endl;
			file << "You data will be saved in the directory!" << std::endl;
			file.close();
		}
	}

	// 报告异常
	void Game::report_exception(const std::exception& e) const noexcept
	{
		std::system("cls"); // 清屏
		std::system("color 4"); // 设置控制台文字颜色为红色
		if (_running)
		{
			closegraph(); // 关闭图形窗口
		}
		std::cerr << (
			"Sorry! An unexpected error "
			"occurred in the game just now!\n" 
		) << std::endl;
		// 输出异常信息
		std::cerr << "Error message: \a" << e.what() << std::endl;
		// 输出建议信息
		std::cerr << (
			"\nWhy am I seeing this?\n\n"
			"\tThis is a bug in the game, maybe caused by the carelessness\n"
			"of the developer or some internal or external factors.\n"
		) << std::endl;
		std::cerr << (
			"\tDon't worry, your data has been saved before this happened.\n\n"
			"\tYou can try to restart the game or contact LeafMain.\n"
		) << std::endl;
		std::system("pause");
	}

	// 运行游戏
	void Game::run()
	{
		_running = true;
		window.open();
		// 进入主页
		page_main.enter();
		// 创建必要的目录
		create_directories();
		// 游戏循环
		ExMessage event = getmessage();
		while (_running)
		{
			if (_sleep_time > 0)
			{
				while (peekmessage(&event))
				{
					_handle_events(event);
				}
				sleep();
			}
			else
			{
				peekmessage(&event);
				_handle_events(event);
				sleep();
			}
		}
		// 退出游戏
		window.close();
	}

	// 退出游戏
	void Game::exit() noexcept
	{
		_running = false;
		std::system("cls"); // 清屏
		// 设置控制台文字颜色为绿色
		std::system("color 2");
		// 输出感谢信息
		std::cout << "PicoLoop: Thanks for playing!" << std::endl;
	}

	// 判断游戏是否正在运行
	bool Game::is_running() const
	{
		return _running;
	}

	// 休眠一段时间
	void Game::sleep() const
	{
		if (_sleep_time <= 0) return;
		Sleep(_sleep_time);
	}

	// 设置休眠时间
	void Game::set_sleep_time(int time)
	{
		if (time < 0) time = 0;
		if (time > 1000) time = 1000;
		_sleep_time = time;
	}

	// 获取休眠时间
	int Game::sleep_time() const
	{
		return _sleep_time;
	}
}