﻿#pragma once

// 游戏创建页面类声明
namespace picoloop
{
	/**
	 * @brief 游戏创建页面类
	 */
	class PageGameCreate : public Page
	{
	public:
		/**
		 * @brief 游戏创建页面类构造函数
		 */
		explicit PageGameCreate(Game& game);
		/**
		 * @brief 游戏创建页面类析构函数
		 */
		~PageGameCreate() override;
		/**
		 * @brief 监听事件
		 * @param event 事件
		 */
		void listen_event(ExMessage& event) override;
		/**
		 * @brief 获取元素编辑常对象
		 * @return 元素编辑常对象
		 */
		[[nodiscard]] const PicoElementEditor& get_element_editor() const
		{ return element_editor; }
	protected:
		/**
		 * @brief 绘制页面
		 */
		void draw_page() const override;
		/**
		 * @brief 开始游戏
		 */
		void play_game();
		/**
		* @brief 设置游戏名称
		* @param name 名称
		*/
		void set_level_name(LPCTSTR level_name);
		/**
		* @brief 设置当前关卡
		* @param level 当前关卡
		*/
		void set_level_number(int number);
		/**
		* @brief 从文件中加载数据
		* @param file_name 文件名
		*/
		void load_data(const std::string& file_name);
		/**
		* @brief 从元素数据中加载数据
		* @param data 数据
		*/
		void load_data(const PicoElementCollection::Data&& data);
		/**
		* @brief 保存数据
		*/
		void save_data();
		/**
		 * @brief 退出页面
		 */
		void exit_page();
		/**
		 * @brief 进入帮助页面
		 */
		void enter_help();
		/**
		 * @brief 页面离开时调用的方法
		 */
		void on_leave() override;
	private:
		friend class PageLevelSelect; 
		friend class PageMakeSelect;
		struct COLOR // 颜色常量结构
		{
			static const COLORREF BACKGROUND; // 背景颜色
			static const COLORREF PANEL_LINE; // 面板线颜色
			static const COLORREF PANEL_SELECT; // 面板选中颜色
			static const COLORREF EDITOR_LINE; // 面板线颜色
			static const COLORREF EDITOR_HOVER; // 面板悬停颜色
			static const COLORREF EDITOR_SELECT; // 面板选中颜色
			static const COLORREF BUTTON_PLAY; // 开始按钮颜色
			static const COLORREF BUTTON_PLAY_HOVER; // 开始按钮鼠标悬停颜色
			static const COLORREF BUTTON_FUNCTIONAL; // 功能按钮颜色
			static const COLORREF BUTTON_FUNCTIONAL_HOVER; // 功能按钮鼠标悬停颜色
			static const COLORREF BUTTON_BACK; // 返回按钮颜色
			static const COLORREF BUTTON_BACK_HOVER; // 返回按钮鼠标悬停颜色
			static const COLORREF KEY_SHORTCUT; // 快捷键颜色
		};
		struct FONT // 字体常量结构
		{
			static const LPCTSTR BUTTON_FONT; // 按钮字体
			static const LPCTSTR KEY_SHORTCUT_FONT; // 快捷键字体
		};
		PicoElementSelectPanel element_select_panel; // 元素选择面板
		PicoElementEditor element_editor; // 元素编辑器
		PicoElementCollection::Data _elements_data; // 元素数据
		RectButton button_play; // 开始按钮
		RectButton button_blur; // 取消选择按钮
		RectButton button_undo; // 撤销按钮
		RectButton button_redo; // 重做按钮
		RectButton button_delete; // 删除按钮
		RectButton button_clear; // 清空按钮
		RectButton button_save; // 保存按钮
		RectButton button_back; // 返回按钮
		RectButton button_help; // 帮助按钮
		LPTSTR _game_name = _tcsdup(_T("Mk-")); // 正在创建的游戏名称
		std::string _save_file_name; // 保存文件名
		int _level_number = 0; // 当前关卡
		/**
		 * @brief 绘制快捷键
		 */
		void _draw_shortcuts() const;
		/**
		 * @brief 清除元素数据
		 */
		void _clear_elements_data();
	};
}