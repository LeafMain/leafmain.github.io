﻿#include "picoloop.h"

// 对向上砖块刺元素类的实现
namespace picoloop
{
    // 绘制向上砖块刺元素
    void PicoUpBrickThrustElement::draw() const
    {
        // 调用父类方法绘制砖块
        PicoBrickElement::draw(); 
        clearrectangle(_40x(0), _40y(0), _40x(40), _40y(5));
        POINT points[9]{};
        points[0] = { _40x(0), _40y(6) };
        for (int i = 1; i <= 8; i++)
        {
            if (i % 2 == 1) points[i] = { _40x(i * 5), _40y(0) };
            else points[i] = { _40x(i * 5), _40y(6) };
        }
        setfillcolor(0x888888);
        solidpolygon(points, 9);
    }

    // 向上砖块刺元素被踩时触发的事件
    void PicoUpBrickThrustElement::on_pedal(PicoPlayer& player, 
        bool occurred, bool first)
    {
        return; // 让玩家穿透，停用父类方法
    }

    // 向上砖块刺元素被碰到时触发的事件
    void PicoUpBrickThrustElement::on_bump(PicoPlayer& player, 
        bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.die(); // 碰到刺时，玩家人物死亡
            }
        }
    }

    // 绘制向下砖块刺元素
    void PicoDownBrickThrustElement::draw() const
    {
        // 调用父类方法绘制砖块
        PicoBrickElement::draw();
        clearrectangle(_40x(0), _40y(34), _40x(40), _40y(40));
        POINT points[9]{};
        points[0] = { _40x(0), _40y(33) };
        for (int i = 1; i <= 8; i++)
        {
            if (i % 2 == 1) points[i] = { _40x(i * 5), _40y(39) };
            else points[i] = { _40x(i * 5), _40y(33) };
        }
        setfillcolor(0x888888);
        solidpolygon(points, 9);
    }

    // 向下砖块刺元素被顶起时触发的事件
    void PicoDownBrickThrustElement::on_jump(PicoPlayer& player, 
        bool occurred, bool first)
    {
        return; // 让玩家穿透，停用父类方法
    }

    // 向下砖块刺元素被碰到时触发的事件
    void PicoDownBrickThrustElement::on_bump(PicoPlayer& player, 
        bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.die(); // 碰到刺时，玩家人物死亡
            }
        }
    }

    // 绘制向左砖块刺元素
    void PicoLeftBrickThrustElement::draw() const
    {
        // 调用父类方法绘制砖块
        PicoBrickElement::draw();
        clearrectangle(_40x(0), _40y(0), _40x(5), _40y(40));
        POINT points[9]{};
        points[0] = { _40x(6), _40y(0) };
        for (int i = 1; i <= 8; i++)
        {
            if (i % 2 == 1) points[i] = { _40x(1), _40y(i * 5) };
            else points[i] = { _40x(6), _40y(i * 5) };
        }
        setfillcolor(0x888888);
        solidpolygon(points, 9);
    }

    // 向左砖块刺元素被向右推时触发的事件
    void PicoLeftBrickThrustElement::on_push_right(PicoPlayer& player, 
        bool occurred, bool first)
    {
        return; // 让玩家穿透，停用父类方法
    }

    // 向左砖块刺元素被碰到时触发的事件
    void PicoLeftBrickThrustElement::on_bump(PicoPlayer& player, 
        bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.die(); // 碰到刺时，玩家人物死亡
            }
        }
    }

    // 绘制向右砖块刺元素
    void PicoRightBrickThrustElement::draw() const
    {
        // 调用父类方法绘制砖块
        PicoBrickElement::draw();
        clearrectangle(_40x(35), _40y(0), _40x(40), _40y(40));
        POINT points[9]{};
        points[0] = { _40x(35), _40y(0) };
        for (int i = 1; i <= 8; i++)
        {
            if (i % 2 == 1) points[i] = { _40x(40), _40y(i * 5) };
            else points[i] = { _40x(35), _40y(i * 5) };
        }
        setfillcolor(0x888888);
        solidpolygon(points, 9);
    }

    // 向右砖块刺元素被向左推时触发的事件
    void PicoRightBrickThrustElement::on_push_left(PicoPlayer& player,
        bool occurred, bool first)
    {
        return; // 让玩家穿透，停用父类方法
    }

    // 向右砖块刺元素被碰到时触发的事件
    void PicoRightBrickThrustElement::on_bump(PicoPlayer& player,
        bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.die(); // 碰到刺时，玩家人物死亡
            }
        }
    }
}