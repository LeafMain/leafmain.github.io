﻿#include "picoloop.h"

// 按钮抽象类实现
namespace picoloop
{
	// 监听鼠标悬停事件，做出响应
	void Button::listen_hover(ExMessage& event)
	{
		// 如果按钮禁用，则不响应鼠标悬停事件
		if (_disabled) return;
		// 如果已经处于激活状态，则不再响应鼠标悬停事件
		if (_is_active) return;
		// 按钮悬停，重新绘制按钮
		if (this->hovered(event))
		{
			if (!_is_hover)
			{
				_is_hover = true;
				draw();
			}
		}
		else
		{
			if (_is_hover)
			{
				_is_hover = false;
				draw();
			}
		}
	}

	// 监听鼠标激活事件，做出响应
	void Button::listen_active(ExMessage& event)
	{
		// 如果按钮禁用，则不响应鼠标激活事件
		if (_disabled) return;
		// 按钮激活，重新绘制按钮
		if (this->pressed(event))
		{
			if (!_is_active)
			{
				_is_active = true;
				draw();
			}
		}
		else
		{
			if (_is_active)
			{
				_is_active = false;
				draw();
			}
		}
	}

	// 判断鼠标是否在按钮区域内点击
	bool Button::clicked(ExMessage& event) const
	{
		return !_disabled && in_area(event.x, event.y) &&
			event.message == WM_LBUTTONDOWN;
	}

	// 判断鼠标是否在按钮区域内按下
	bool Button::pressed(ExMessage& event) const
	{
		return !_disabled && event.lbutton &&
			in_area(event.x, event.y);
	}

	// 判断鼠标是否在按钮区域内悬停
	bool Button::hovered(ExMessage& event) const
	{
		return !_disabled && in_area(event.x, event.y) &&
			event.message == WM_MOUSEMOVE;
	}

	// 设置按钮禁用状态
	void Button::set_disabled(bool disabled)
	{
		_disabled = disabled;
		// 重新绘制按钮
		draw();
	}
}