﻿#pragma once

// Pico 旗帜元素类声明
namespace picoloop
{
    /**
    * @brief Pico 旗帜元素类
    */
    class PicoFlagElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制旗帜元素
        */
        void draw() const override;
        /**
        * @brief 绘制旗帜元素，已经解锁
        */
        void draw_unlocked() const;
        /**
        * @brief 绘制旗帜元素，未解锁
        */
        void draw_locked() const;
        /**
        * @brief 克隆旗帜元素
        * @return 克隆的旗帜元素，需要手动管理内存
        */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoFlagElement(*this); }
    protected:
        /**
        * @brief 旗帜元素被碰到时触发的事件
        * @param player 玩家对象
        * @param occurred 是否被碰到
        * @param first 是否是第一次被碰到
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 玩家踩到旗帜元素时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否是第一次发生事件
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 旗帜元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 旗帜元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 旗帜元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 重置旗帜元素的数据
        */
        void reset_data() override;
    private:
        bool _is_locked = false; // 是否已解锁
        bool _drop_disabled = false; // 掉落是否禁用
        bool _move_left_disabled = false; // 向左移动是否禁用
        bool _move_right_disabled = false; // 向右移动是否禁用
    };
}
