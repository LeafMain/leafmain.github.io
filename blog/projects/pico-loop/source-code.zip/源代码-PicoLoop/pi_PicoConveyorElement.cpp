﻿#include "picoloop.h"

// 对向左传送带元素类的实现
namespace picoloop
{
    // 绘制向左传送带元素
    void PicoLeftConveyorElement::draw() const
    {
        _get_bk_image();
        setfillcolor(0xff7213);
        solidrectangle(_40x(0), _40y(0), _40x(39), _40y(39));
        setfillcolor(0x111111);
        POINT points[7] =
        {
            _40x(30), _40y(15), _40x(15), _40y(15), 
            _40x(15), _40y(10), _40x(10), _40y(20),
            _40x(15), _40y(30), _40x(15), _40y(25), 
            _40x(30), _40y(25)
        };
        solidpolygon(points, 7);
    }

    // 向左传送带元素被踩时触发的事件
    void PicoLeftConveyorElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                // 玩家使用被动移动速度，为原来的1/2
                if (player.get_passive_move_speed() <= 0)
                {
                    player.use_passive_move_speed(-PicoPlayer::NORMAL_MOVE_SPEED / 2);
                }
                else
                {
                    player.use_passive_move_speed(0);
                }
                player.disable_drop();
                player.enable_jump();
            }
        }
        else
        {
            if (first)
            {
                player.recover_passive_move_speed();
                player.enable_drop();
                player.disable_jump();
            }
        }
    }

    // 向左传送带元素被顶起时触发的事件
    void PicoLeftConveyorElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.stop_shift();
            }
        }
    }

    // 向左传送带元素向左推动时触发的事件
    void PicoLeftConveyorElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
            }
        }
    }

    // 向左传送带元素向右推动时触发的事件
    void PicoLeftConveyorElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_right();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_right();
            }
        }
    }
}

// 对向右传送带元素类的实现
namespace picoloop
{
    // 绘制向右传送带元素
    void PicoRightConveyorElement::draw() const
    {
        _get_bk_image();
        setfillcolor(0xff7213);
        solidrectangle(_40x(0), _40y(0), _40x(39), _40y(39));
        setfillcolor(0x111111);
        POINT points[7] =
        {
            _40x(10), _40y(15), _40x(25), _40y(15),
            _40x(25), _40y(10), _40x(30), _40y(20),
            _40x(25), _40y(30), _40x(25), _40y(25),
            _40x(10), _40y(25)
        };
        solidpolygon(points, 7);
    }

    // 向右传送带元素被踩时触发的事件
    void PicoRightConveyorElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                // 玩家使用被动移动速度，为原来的 1/2
                if (player.get_passive_move_speed() >= 0)
                {
                    player.use_passive_move_speed(PicoPlayer::NORMAL_MOVE_SPEED / 2);
                }
                else
                {
                    player.use_passive_move_speed(0);
                }
                player.disable_drop();
                player.enable_jump();
            }
        }
        else
        {
            if (first)
            {
                player.recover_passive_move_speed();
                player.enable_drop();
                player.disable_jump();
            }
        }
    }

    // 向右传送带元素被顶起时触发的事件
    void PicoRightConveyorElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.stop_shift();
            }
        }
    }

    // 向右传送带元素向右推动时触发的事件
    void PicoRightConveyorElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
            }
        }
    }

    // 向右传送带元素向右推动时触发的事件
    void PicoRightConveyorElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_right();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_right();
            }
        }
    }
}