﻿#pragma once

// 窗口类定义
namespace picoloop
{
	/**
	* @brief 窗口类
	*/
	class Window
	{
	public:
		static constexpr WPARAM // 最小化数值
			MINIMIZE = 2097152ull; 
		static constexpr WPARAM // 窗口失去焦点数值
			KILL_FOCUS = 0ull;
		static const int WIDTH; // 窗口宽度
		static const int HEIGHT; // 窗口高度

		/**
		* @brief 打开窗口
		*/
		void open();

		/**
		* @brief 关闭窗口
		*/
		void close();

		/**
		* @brief 判断窗口是否打开
		* @return true 窗口打开
		* @return false 窗口关闭
		*/
		[[nodiscard]] bool opened() const;
	private:
		bool _opened = false; // 窗口是否打开
	};
}