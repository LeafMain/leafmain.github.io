﻿#pragma once
// Pico 元素集合类声明
namespace picoloop
{
	/**
	 * @brief Pico 元素集合类
	 */
	class PicoElementCollection
	{
	public:
		PicoElementCollection() = delete; // 不允许实例化
		// 元素类型枚举
		enum TYPE
		{
			EMPTY, // 空元素
			PLAYER, // 玩家元素
			KEY, // 钥匙元素
			FLAG, // 旗帜元素
			BRICK, // 砖块元素
			FIRE, // 火元素
			COIN, // 金币元素
			SUPER_SHOE, // 超级跑鞋元素
			WINGS, // 翅膀元素
			POISON, // 毒药元素
			ANTIDOTE, // 解药元素
			STONE, // 石头元素
			RED_STONE, // 红石元素
			ORANGE_STONE, // 橙石元素
			YELLOW_STONE, // 黄石元素
			GREEN_STONE, // 绿石元素
			CYAN_STONE, // 青石元素
			BLUE_STONE, // 蓝石元素
			PURPLE_STONE, // 紫石元素
			WHITE_STONE, // 白石元素
			PINK_STONE, // 粉石元素
			ONE_USED_DOOR, // 单次门元素
			UP_RIGHT_TUBE, // 左上角管道元素
			NO_UP_TUBE, // 无向上管道元素
			UP_LEFT_TUBE, // 右上角管道元素
			NO_LEFT_TUBE, // 无向左管道元素
			INTERSECT_TUBE, // 十字管道元素
			NO_RIGHT_TUBE, // 无向右管道元素
			DOWN_RIGHT_TUBE, // 左下角管道元素
			NO_DOWN_TUBE, // 无向下管道元素
			DOWN_LEFT_TUBE, // 右下角管道元素
			HORIZONTAL_TUBE, // 水平管道元素
			VERTICAL_TUBE, // 垂直管道元素
			SOIL, // 泥土元素
			WATER, // 水元素
			LADDER, // 梯子元素
			TRANSPARENT_BRICK, // 透明砖块元素
			LEFT_CONVEYOR, // 左侧传送带元素
			RIGHT_CONVEYOR, // 右侧传送带元素
			BOUNCE_BED, // 蹦床元素
			UP_BRICK_THRUST, // 向上砖块刺元素
			DOWN_BRICK_THRUST, // 向下砖块刺元素
			LEFT_BRICK_THRUST, // 向左砖块刺元素
			RIGHT_BRICK_THRUST, // 向右砖块刺元素
			COIN_LOCKER, // 金币锁柜元素
			DOWN_LIFT, // 下降机元素
			UP_BUTTER_BRICK, // 向上黄油砖块元素
			DOWN_BUTTER_BRICK, // 向下黄油砖块元素
			TELEPORT_GATE, // 传送门元素
			LENGTH, // 长度，用于占位
		};
		// 元素数据类型，使用二维数组存储元素类型
		using Data = std::vector<std::vector<TYPE>>;
		/**
		* @brief 根据元素实例获取元素类型
		* @param element 元素实例
		* @return 元素类型
		*/
		[[nodiscard]] static TYPE get_type(const PicoElement* element);
		/**
		* @brief 根据元素类型创建元素实例动态指针
		* @param element_type 元素类型
		* @param x 元素 x 坐标
		* @param y 元素 y 坐标
		* @param size 元素大小
		* @return 元素实例动态指针，分配失败返回 nullptr，需要手动释放
		*/
		[[nodiscard]] static PicoElement* create(TYPE element_type,
			int x, int y, int size);
		/**
		* @brief 判断元素是否为指定类型
		* @param element 元素实例
		* @param element_type 元素类型
		* @return 元素是否为指定类型
		*/
		[[nodiscard]] static bool same_type(const PicoElement* element, 
			TYPE element_type);

		/**
		* @brief 判断元素是否不是空元素
		* @param element_type 元素类型
		* @return 元素是否不是空元素
		*/
		[[nodiscard]] static bool not_empty(TYPE element_type)
		{ return element_type != EMPTY && element_type != LENGTH; }

		/**
		* @brief 判断元素是否不是空元素
		* @param element 元素实例
		* @return 元素是否不是空元素
		*/
		[[nodiscard]] static bool not_empty(const PicoElement* element);
	};
}