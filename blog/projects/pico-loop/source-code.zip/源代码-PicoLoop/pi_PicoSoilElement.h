﻿#pragma once

// 对泥土元素类的声明
namespace picoloop
{
    /**
     * @brief 泥土元素类
     */
    class PicoSoilElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制泥土元素
        */
        void draw() const override;
        /**
         * @brief 克隆泥土元素
         * @return 克隆出的 PicoSoilElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoSoilElement(*this); }
        /**
         * @brief 重置泥土元素数据
         */
        void reset_data() override;
        /**
        * @brief 判断泥土元素是否存在
        * @return 泥土元素是否存在
        */
        [[nodiscard]] bool exist() const { return _exist; }
    protected:
        /**
        * @brief 泥土元素被踩时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 泥土元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 泥土元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 泥土元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
    private:
        bool _exist = true; // 泥土元素是否存在
    };
}