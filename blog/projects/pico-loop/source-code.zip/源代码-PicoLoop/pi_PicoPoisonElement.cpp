﻿#include "picoloop.h"

// Pico 毒药类实现
namespace picoloop
{
    // 绘制毒药元素
    void PicoPoisonElement::draw() const
    {
        // 不存在时不绘制
        if (!_exist) return;
        _get_bk_image();
        setlinecolor(0xff6ca8);
        setlinestyle(PS_SOLID, 1);
        // 绘制毒药元素
        // 瓶子
        setfillcolor(0xa3007f);
        fillroundrect(_40x(6), _40y(7), _40x(34), _40y(38), 8, 8);
        setfillcolor(0xff00be);
        fillroundrect(_40x(6), _40y(8), _40x(34), _40y(38), 8, 8);
        // 盖子
        setfillcolor(0x2255cc);
        fillroundrect(_40x(15), _40y(1), _40x(25), _40y(7), 4, 4);
    }

    // 重置毒药元素数据
    void PicoPoisonElement::reset_data()
    {
        base_reset(); // 调用基类的重置方法
        _exist = true;
    }

    // 玩家碰到毒药时触发的事件
    void PicoPoisonElement::on_bump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred && first)
        {
            if (_exist)
            {
                // 玩家获得毒药 buff
                player.set_buff(PicoPlayer::BUFF::POISON);
                // 销毁毒药元素
                this->erase();
                _exist = false;
            }
        }
    }
}