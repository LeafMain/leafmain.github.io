﻿#include "picoloop.h"

// 对蹦床元素类的实现
namespace picoloop
{
    // 绘制蹦床元素
    void PicoBounceBedElement::draw() const
    {
        if (!_is_pressed)
        {
            draw_normal();
        }
        else
        {
            draw_pressed();
        }
    }

    // 绘制蹦床正常状态
    void PicoBounceBedElement::draw_normal() const
    {
        _get_bk_image();
        setfillcolor(0x1138AA);
        solidrectangle(_40x(0), _40y(0), _40x(39), _40y(3));
        solidrectangle(_40x(0), _40y(35), _40x(39), _40y(39));
        setfillcolor(0x777777);
        for (int i = 4; i <= 33; i += 4)
        {
            solidrectangle(_40x(2), _40y(i), _40x(37), _40y(i + 2));
        }
        setlinecolor(0x333333);
        line(_40x(2), _40y(4), _40x(37), _40y(35));
        line(_40x(2), _40y(35), _40x(37), _40y(4));
        line(_40x(2), _40y(35), _40x(2), _40y(4));
        line(_40x(37), _40y(35), _40x(37), _40y(4));
    }

    // 绘制蹦床按压状态
    void PicoBounceBedElement::draw_pressed() const
    {
        _get_bk_image();
        setfillcolor(0x1138AA);
        solidrectangle(_40x(2), _40y(2), _40x(39), _40y(4));
        solidrectangle(_40x(0), _40y(35), _40x(39), _40y(39));
        setfillcolor(0x777777);
        for (int i = 5; i <= 33; i += 4)
        {
            solidrectangle(_40x(2), _40y(i), _40x(37), _40y(i + 2));
        }
        setlinecolor(0x333333);
        line(_40x(2), _40y(5), _40x(37), _40y(35));
        line(_40x(2), _40y(35), _40x(37), _40y(5));
        line(_40x(2), _40y(35), _40x(2), _40y(4));
        line(_40x(37), _40y(35), _40x(37), _40y(4));
    }

    // 蹦床元素被踩时触发的事件
    void PicoBounceBedElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_drop();
                player.enable_jump();
                // 只有当玩家竖直方向上的速度大于 0 时才会触发
                if (player.get_speed_y() > 0)
                {
                    player.prevent_control_jump();
                    // 特殊处理飞行状态，防止速度过快
                    if (player.get_buff() == PicoPlayer::BUFF::FLY)
                    {
                        player.set_speed_y(-PicoPlayer::NORMAL_JUMP_SPEED);
                    }
                    else
                    {
                        player.set_speed_y(-PicoPlayer::NORMAL_JUMP_SPEED * 71 / 50);
                    }
                }
                else if (player.get_speed_y() == 0)
                {
                    _is_pressed = true;
                    // 擦除后绘制按压状态
                    erase();
                    draw_pressed();
                    FlushBatchDraw();
                }
            }
        }
        else
        {
            if (first)
            {
                // 只在按压时重绘
                if (_is_pressed)
                {
                    _is_pressed = false;
                    // 擦除后绘制正常状态
                    erase();
                    draw_normal();
                    FlushBatchDraw();
                }
                player.enable_drop();
                player.disable_jump();
            }
        }
    }

    // 蹦床元素被顶起时触发的事件
    void PicoBounceBedElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.stop_shift();
            }
        }
    }

    // 蹦床元素向左推动时触发的事件
    void PicoBounceBedElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
            }
        }
    }

    // 蹦床元素向右推动时触发的事件
    void PicoBounceBedElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_right();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_right();
            }
        }
    }
}