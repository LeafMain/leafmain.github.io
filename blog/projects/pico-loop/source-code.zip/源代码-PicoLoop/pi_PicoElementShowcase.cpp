﻿#include "picoloop.h"

// Pico 元素展示类实现
namespace picoloop
{
	// Pico 元素展示类构造函数
	PicoElementShowcase::PicoElementShowcase(int x, int y, int size, int padding,
		PicoElementCollection::TYPE element_type,
		COLORREF border_color, int border_width, int border_type) :
		x(x), y(y), size(size), padding(padding), border_color(border_color),
		border_width(border_width), border_type(border_type)
	{
		element = PicoElementCollection::create(element_type,
			x + padding, y + padding, size - padding * 2);
		_element_type = element_type;
		if (element == nullptr)
		{
			throw std::runtime_error(
				"Failed to construct PicoElementShowcase:\n"
				"The specified element type is not supported."
			);
		}
	}

	// Pico 元素展示类析构函数
	PicoElementShowcase::~PicoElementShowcase()
	{
		// 必须释放 element 指针占用的动态内存
		delete element;
	}

	// Pico 元素展示类拷贝构造函数
	PicoElementShowcase::PicoElementShowcase(const PicoElementShowcase& other) :
		x(other.x), y(other.y), size(other.size), padding(other.padding),
		border_color(other.border_color), border_width(other.border_width),
		border_type(other.border_type)
	{
		_element_type = other._element_type;
		// 深拷贝 element 指针
		element = other.element->clone();
	}

	// Pico 元素展示类赋值运算符
	PicoElementShowcase& PicoElementShowcase::operator=(const PicoElementShowcase& other)
	{
		if (this == &other) return *this;
		x = other.x;
		y = other.y;
		size = other.size;
		padding = other.padding;
		border_color = other.border_color;
		border_width = other.border_width;
		border_type = other.border_type;
		_element_type = other._element_type;
		// 释放原来的 element 指针占用的动态内存
		delete element;
		// 深拷贝 element 指针
		element = other.element ? other.element->clone() : nullptr;
		return *this;
	}

	// 绘制展示框及其元素
	void PicoElementShowcase::draw() const
	{
		// 绘制展示框
		setlinecolor(border_color);
		setlinestyle(border_type, border_width);
		rectangle(x, y, x + size, y + size);
		// 绘制元素
		element->draw();
	}

	// 设置展示框的元素
	void PicoElementShowcase::set_element(PicoElementCollection::TYPE element_type, 
		bool need_draw)
	{
		if (element != nullptr)
		{
			element->erase(); // 清除原来的元素
			// 释放原来的 element 指针占用的动态内存
			delete element;
		}
		_element_type = element_type;
		// 创建新的 element 指针
		element = PicoElementCollection::create(element_type,
			x + padding, y + padding, size - padding * 2);
		if (element == nullptr)
		{
			throw std::runtime_error(
				"Failed to replace PicoElementShowcase element:\n"
				"The specified element type is not supported."
			);
		}
		if (need_draw)
		{
			element->draw();
		}
	}
}
