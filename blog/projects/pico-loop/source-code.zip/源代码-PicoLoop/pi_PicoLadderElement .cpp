﻿#include "picoloop.h"

// 对梯子元素类的实现
namespace picoloop
{
    // 绘制梯子元素
    void PicoLadderElement::draw() const
    {
        _get_bk_image();
        setfillcolor(0x006aaa);
        for (int i = 5; i < 40; i += 10)
        {
            solidrectangle(_40x(5), _40y(i - 1), _40x(35), _40y(i + 1));
        }
        setfillcolor(0x005eaa);
        solidrectangle(_40x(2), _40y(0), _40x(5), _40y(39));
        solidrectangle(_40x(35), _40y(0), _40x(38), _40y(39));
    }

    // 梯子元素被碰到时触发的事件
    void PicoLadderElement::on_bump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                // 正常状态下，玩家的速度为正常移动速度的四分之三
                int speed = PicoPlayer::NORMAL_MOVE_SPEED * 3 / 4;
                // 若玩家处于中毒状态，玩家的速度为正常移动速度的二分之一
                if (player.get_buff() == PicoPlayer::BUFF::POISON)
                {
                    speed = PicoPlayer::NORMAL_MOVE_SPEED / 2;
                }
                player.use_fixed_jump_speed(speed);
            }
        }
        else
        {
            if (first)
            {
                player.recover_fixed_jump_speed();
            }
        }
    }

    // 梯子元素被踩到时触发的事件
    void PicoLadderElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.enable_jump();
            }
        }
        else
        {
            if (first)
            {
                player.disable_jump();
            }
        }
    }
}