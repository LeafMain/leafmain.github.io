﻿#include "picoloop.h"

// 游戏文字类实现
namespace picoloop
{
	const int GameTitle::WIDTH = 31 * 14; // 宽度
	const int GameTitle::HEIGHT = 5 * 14; // 高度
	// 字母颜色数组
	const COLORREF GameTitle::ALPHA_COLOR[ALPHA_COUNT] = {
		RED, GREEN, LIGHTCYAN, YELLOW, 
		MAGENTA, CYAN, LIGHTBLUE, LIGHTRED
	};

	// 绘制游戏标题
	void GameTitle::draw() const
	{
		const int GRID = 14;
		BeginBatchDraw();

		for (int i = 0; i < ALPHA_COUNT; i++)
		{
			const int GAP = i * GRID * 4;
			setfillcolor(ALPHA_COLOR[i]);
			// 绘制 P
			if (i == 0)
			{
				solidrectangle(_ax(GAP + GRID * 0), _ay(GRID * 0), 
					_ax(GAP + GRID * 1), _ay(GRID * 5));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 0), 
					_ax(GAP + GRID * 3), _ay(GRID * 1));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 2), 
					_ax(GAP + GRID * 3), _ay(GRID * 3));
				solidrectangle(_ax(GAP + GRID * 2), _ay(GRID * 1), 
					_ax(GAP + GRID * 3), _ay(GRID * 2));
			}
			// 绘制 I
			else if (i == 1)
			{
				solidrectangle(_ax(GAP + GRID * 0), _ay(GRID * 0), 
					_ax(GAP + GRID * 3), _ay(GRID * 1));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 1),
					_ax(GAP + GRID * 2), _ay(GRID * 4));
				solidrectangle(_ax(GAP + GRID * 0), _ay(GRID * 4), 
					_ax(GAP + GRID * 3), _ay(GRID * 5));
			}
			// 绘制 C
			else if (i == 2)
			{
				solidrectangle(_ax(GAP + GRID * 0), _ay(GRID * 0),
					_ax(GAP + GRID * 1), _ay(GRID * 5));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 0),
					_ax(GAP + GRID * 3), _ay(GRID * 1));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 4),
					_ax(GAP + GRID * 3), _ay(GRID * 5));
			}
			// 绘制 O
			else if (i == 3)
			{
				solidrectangle(_ax(GAP + GRID * 0), _ay(GRID * 0),
					_ax(GAP + GRID * 1), _ay(GRID * 5));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 0),
					_ax(GAP + GRID * 3), _ay(GRID * 1));
				solidrectangle(_ax(GAP + GRID * 2), _ay(GRID * 1),
					_ax(GAP + GRID * 3), _ay(GRID * 4));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 4),
					_ax(GAP + GRID * 3), _ay(GRID * 5));
			}
			// 绘制 L
			else if (i == 4)
			{
				solidrectangle(_ax(GAP + GRID * 0), _ay(GRID * 0),
					_ax(GAP + GRID * 1), _ay(GRID * 5));
				solidrectangle(_ax(GAP + GRID * 0), _ay(GRID * 4),
					_ax(GAP + GRID * 3), _ay(GRID * 5));
			}
			// 绘制 O
			else if (i == 5)
			{
				solidrectangle(_ax(GAP + GRID * 0), _ay(GRID * 0),
					_ax(GAP + GRID * 1), _ay(GRID * 5));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 0),
					_ax(GAP + GRID * 3), _ay(GRID * 1));
				solidrectangle(_ax(GAP + GRID * 2), _ay(GRID * 1),
					_ax(GAP + GRID * 3), _ay(GRID * 4));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 4),
					_ax(GAP + GRID * 3), _ay(GRID * 5));
			}
			// 绘制 O
			else if (i == 6)
			{
				solidrectangle(_ax(GAP + GRID * 0), _ay(GRID * 0),
					_ax(GAP + GRID * 1), _ay(GRID * 5));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 0),
					_ax(GAP + GRID * 3), _ay(GRID * 1));
				solidrectangle(_ax(GAP + GRID * 2), _ay(GRID * 1),
					_ax(GAP + GRID * 3), _ay(GRID * 4));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 4),
					_ax(GAP + GRID * 3), _ay(GRID * 5));
			}
			// 绘制 P
			else if (i == 7)
			{
				solidrectangle(_ax(GAP + GRID * 0), _ay(GRID * 0),
					_ax(GAP + GRID * 1), _ay(GRID * 5));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 0),
					_ax(GAP + GRID * 3), _ay(GRID * 1));
				solidrectangle(_ax(GAP + GRID * 1), _ay(GRID * 2),
					_ax(GAP + GRID * 3), _ay(GRID * 3));
				solidrectangle(_ax(GAP + GRID * 2), _ay(GRID * 1),
					_ax(GAP + GRID * 3), _ay(GRID * 2));
			}
		}

		EndBatchDraw();
	}
}