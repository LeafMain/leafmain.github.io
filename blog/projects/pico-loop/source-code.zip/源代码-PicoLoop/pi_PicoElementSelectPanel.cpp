﻿#include "picoloop.h"

// 元素选择面板类实现
namespace picoloop
{
	
	// 元素选择面板类构造函数
	PicoElementSelectPanel::PicoElementSelectPanel(int x, int y, int grid_row,
		int grid_column, int grid_size, COLORREF line_color, 
		COLORREF hover_color, COLORREF select_color) :
		X(x), Y(y), GRID_ROW(grid_row), GRID_COLUMN(grid_column),
		GRID_SIZE(grid_size), line_color(line_color),
		select_color(select_color), hover_color(hover_color), 
		grid(x, y, grid_row, grid_column, grid_size, 1, PS_SOLID, 
			line_color, hover_color, select_color)
	{
		// 分配元素指针数组行数
		elements = new PicoElement * *[GRID_ROW];
		for (int row = 0; row < GRID_ROW; row++)
		{
			// 分配元素指针数组列数
			elements[row] = new PicoElement * [GRID_COLUMN];
			for (int col = 0; col < GRID_COLUMN; col++)
			{
				// 获取元素坐标
				int x = grid.abs_x(col);
				int y = grid.abs_y(row);
				int size = GRID_SIZE; // 元素大小为网格大小
				int index = row * GRID_COLUMN + col + 1;
				// 元素指针置为对应元素
				if (index < PicoElementCollection::LENGTH)
				{
					PicoElementCollection::TYPE type = static_cast
						<PicoElementCollection::TYPE>(index);
					// 元素指针置为空元素
					elements[row][col] = PicoElementCollection::create
					(type, x, y, size);
				}
				// 超出范围的元素指针置为空元素
				else
				{
					elements[row][col] = new PicoEmptyElement(x, y, size);
				}
			}
		}
	}

	// 元素选择面板类析构函数
	PicoElementSelectPanel::~PicoElementSelectPanel()
	{
		// 避免释放空指针
		if (elements == nullptr) return;
		// 释放元素指针数组
		for (int row = 0; row < GRID_ROW; row++)
		{
			for (int col = 0; col < GRID_COLUMN; col++)
			{
				delete elements[row][col];
			}
			delete[] elements[row];
		}
		delete[] elements;
		// 将指针置空
		elements = nullptr;
	}

	// PicoElementSelectPanel 类保护构造函数
	PicoElementSelectPanel::PicoElementSelectPanel(bool no_allocate, int x,
		int y, int grid_row, int grid_column, int grid_size,
		COLORREF line_color, COLORREF hover_color, COLORREF select_color) :
		X(x), Y(y), GRID_ROW(grid_row), GRID_COLUMN(grid_column),
		GRID_SIZE(grid_size), line_color(line_color), hover_color(hover_color),
		select_color(select_color), grid(x, y, grid_row, grid_column,
			grid_size, 1, PS_SOLID, line_color, hover_color, select_color)
	{
		// 不分配元素指针数组，必须由子类分配
		elements = nullptr;
	}

	// 返回选中元素的类型
	PicoElementCollection::TYPE PicoElementSelectPanel::selected_type() const
	{
		// 未选中元素返回无效类型
		if (!grid.has_active())
		{
			return PicoElementCollection::LENGTH;
		}
		int row = grid.active_row();
		int col = grid.active_column();
		// 超出范围的元素返回无效类型
		if (!grid.in_range(row, col))
		{
			return PicoElementCollection::LENGTH;
		}
		// 返回选中元素类型
		return PicoElementCollection::get_type(elements[row][col]);
	}

	// 返回选中的元素是否非空
	bool PicoElementSelectPanel::selected_not_empty() const
	{
		return PicoElementCollection::not_empty(selected_type());
	}

	// 移除选中元素
	void PicoElementSelectPanel::remove_select()
	{
		grid.remove_hover(); // 移除悬停状态
		grid.remove_active(); // 移除选中元素
	}

	// 选中第一个非空元素
	void PicoElementSelectPanel::select_first()
	{
		for (int row = 0; row < grid.ROW; row++)
		{
			for (int col = 0; col < grid.COLUMN; col++)
			{
				if (PicoElementCollection::not_empty(elements[row][col]))
				{
					grid.set_active(row, col); // 设置选中元素
					return;
				}
			}
		}
	}

	// 选中上一个元素
	void PicoElementSelectPanel::select_prev()
	{
		// 没有选中元素时不切换
		if (!grid.has_active())
		{
			return;
		}
		// 获得当前选中元素的索引
		int index = grid.active_row() * grid.COLUMN + grid.active_column();
		if (index == 0)
		{
			remove_select(); // 移除选中元素
			return;
		}
		// 选中上一个非空元素
		for (int i = index - 1; i >= 0; i--)
		{
			int row = i / grid.COLUMN;
			int col = i % grid.COLUMN;
			if (grid.in_range(row, col))
			{
				if (PicoElementCollection::not_empty(elements[row][col]))
				{
					grid.set_active(row, col); // 设置选中元素
					return;
				}
			}
		}
	}

	// 选中下一个元素
	void PicoElementSelectPanel::select_next()
	{
		// 没有选中元素时切换到第一个元素
		if (!grid.has_active())
		{
			select_first();
			return;
		}
		// 获得当前选中元素的索引
		int index = grid.active_row() * grid.COLUMN + grid.active_column();
		// 选中下一个非空元素
		for (int i = index + 1; i < PicoElementCollection::LENGTH; i++)
		{
			int row = i / grid.COLUMN;
			int col = i % grid.COLUMN;
			if (grid.in_range(row, col))
			{
				if (PicoElementCollection::not_empty(elements[row][col]))
				{
					grid.set_active(row, col); // 设置选中元素
					return;
				}
			}
		}
		remove_select(); // 移除选中元素
	}

	// 绘制元素选择面板
	void PicoElementSelectPanel::draw() const
	{
		BeginBatchDraw();
		// 绘制每个元素
		for (int row = 0; row < GRID_ROW; row++)
		{
			for (int col = 0; col < GRID_COLUMN; col++)
			{
				elements[row][col]->draw(); // 绘制元素
			}
		}
		grid.draw(); // 绘制网格
		EndBatchDraw();
	}

	// 监听点击事件
	void PicoElementSelectPanel::listen_select(ExMessage& event)
	{
		// 当点击事件发生时
		if (event.message == WM_LBUTTONDOWN)
		{
			int row = grid.to_row(event.y); // 获取点击行
			int col = grid.to_column(event.x); // 获取点击列
			int index = row * GRID_COLUMN + col; // 获取索引
			// 只有当点击在元素范围内才触发元素点击事件
			if (index < PicoElementCollection::LENGTH - 1)
			{
				grid.set_active(row, col); // 设置选中元素
			}
			// 否则当点击在网格范围内时移除选中元素
			else if (grid.in_range(row, col))
			{
				grid.remove_active(); // 移除选中元素
			}
		}
	}

	// 监听键盘 tab 事件
	void PicoElementSelectPanel::listen_tab(ExMessage& event)
	{
		// 按下了 shift 键
		if (GetAsyncKeyState(VK_SHIFT) & 0x8000)
		{
			// 按下 shift + tab 组合键切换到上一个元素
			if (event.wParam == VK_TAB && !event.prevdown)
			{
				// 选中元素时才切换
				if (grid.has_active())
				{
					// 获得当前选中元素的索引
					int index = grid.active_row() * grid.COLUMN +
						grid.active_column() - 1;
					if (index >= 0)
					{
						index--;
						grid.set_active(index / grid.COLUMN,
							index % grid.COLUMN);
					}
					// 否则移除选中元素
					else
					{
						grid.remove_hover();
						grid.remove_active(); 
					}
				}
			}
		}
		else
		{
			// 按下 tab 键切换到下一个元素
			if (event.wParam == VK_TAB && !event.prevdown)
			{
				// 没有选中元素时切换到第一个元素
				if (!grid.has_active())
				{
					select_first();
				}
				else
				{
					// 获得当前选中元素的索引
					int index = grid.active_row() * grid.COLUMN +
						grid.active_column() + 1;
					if (index < PicoElementCollection::LENGTH - 1)
					{
						grid.set_active(index / grid.COLUMN, 
							index % grid.COLUMN);
					}
					// 否则移除选中元素
					else
					{
						grid.remove_hover();
						grid.remove_active();
					}
				}
			}
		}
	}
}