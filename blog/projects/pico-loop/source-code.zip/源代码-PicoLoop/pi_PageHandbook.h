﻿#pragma once

// 图鉴页面类声明
namespace picoloop
{
	/**
	* @brief 图鉴页面类
	*/
	class PageHandbook : public Page
	{
	public:
		/**
		* @brief 图鉴页面类构造函数
		* @param game 游戏对象
		*/
		PageHandbook(Game& game);
		/**
		* @brief 监听页面事件
		* @param event 事件
		*/
		void listen_event(ExMessage& event) override;
	protected:
		using TYPE = PicoElementCollection::TYPE;
		enum class RIGHT_BUTTON // 右侧按钮枚举
		{
			SELECT, // 选择按钮
			EDITOR, // 编辑器按钮
			STAGE, // 游戏阶段按钮
			KEYDOWN, // 按键按钮
			NONE // 无按钮
		};
		/**
		* @brief 绘制页面
		*/
		void draw_page() const override;
		/**
		* @brief 页面进入前调用
		*/
		void on_enter() override;
		/**
		* @brief 页面进入后调用
		*/
		void on_after_enter() override;
		/**
		* @brief 页面离开前调用
		*/
		void on_leave() override;
		/**
		* @brief 显示面板元素信息
		* @param type 元素类型
		*/
		void show_element_info(TYPE type);
		/**
		* @brief 设置游戏预览区
		*/
		void set_preview(TYPE type);
		/**
		* @brief 点击右侧按钮
		* @param button 按钮类型
		*/
		void click_right_button(RIGHT_BUTTON button);
		/**
		* @brief 退出页面
		*/
		void exit_page();
	private:
		static const int PLAYGROUND_ROW; // 游戏区行数
		static const int PLAYGROUND_COLUMN; // 游戏区列数
		struct COLOR // 颜色结构体
		{
			static const COLORREF BACKGROUND; // 背景颜色
			static const COLORREF BACKGROUND_INFO; // 信息背景颜色
			static const COLORREF PANEL_LINE; // 面板线颜色
			static const COLORREF PANEL_SELECT; // 面板选中颜色
			static const COLORREF TITLE; // 标题颜色
			static const COLORREF REGION_TITLE; // 区域标题颜色
			static const COLORREF BOTTOM_TIPS; // 底部提示颜色
			static const COLORREF DIVIDER; // 分割线颜色
			static const COLORREF BRIEF; // 简要信息颜色 
			static const COLORREF DETAIL; // 详细信息颜色
			static const COLORREF BUTTON_FUNC; // 功能按钮颜色
			static const COLORREF BUTTON_FUNC_HOVER; // 功能按钮颜色
			static const COLORREF BUTTON_EXIT; // 退出按钮颜色
			static const COLORREF BUTTON_EXIT_HOVER; // 退出按钮颜色
		};
		struct FONT // 字体结构体
		{
			static const LPCTSTR TITLE_FONT; // 标题字体
			static const LPCTSTR BRIEF_FONT; // 简要信息字体
			static const LPCTSTR DETAIL_FONT; // 详细信息字体
			static const LPCTSTR BUTTON_FONT; // 按钮字体
		};
		struct FONT_SIZE // 字体大小结构体
		{
			static const int BRIEF_INFO; // 简要信息字体大小
			static const int DETAIL_INFO; // 详细信息字体大小
			static const int DETAIL_INFO_LARGE; // 详细信息大字体大小
		};
		GameTitle game_title; // 游戏标题
		PicoElementSelectPanel select_panel; // 选择面板
		PicoElementShowcase element_showcase; // 元素展示区
		PicoElementEditor element_data; // 元素数据编辑区
		PicoPlayground playground; // 游戏区
		RectButton button_select; // 选择按钮
		RectButton button_editor; // 编辑器按钮
		RectButton button_stage; // 游戏阶段按钮
		RectButton button_keydown; // 按键按钮
		RectButton button_exit; // 退出按钮
		TYPE _panel_selected_type = TYPE::EMPTY; // 当前面板选择类型
		RIGHT_BUTTON _button_now = RIGHT_BUTTON::NONE; // 当前按钮类型
		int _detail_font_size = 12; // 详细信息字体大小
		/**
		* @brief 重置页面
		*/
		void _reset_page();
		/**
		* @brief 绘制页面标题
		*/
		void _draw_page_title() const;
		/**
		* @brief 绘制简要信息
		* @param text 简要信息文本
		*/
		void _draw_brief_info(LPCTSTR text) const;
		/**
		* @brief 绘制详细信息
		* @param text 详细信息文本
		* @param large 是否使用大字体，默认为 true
		*/
		void _draw_detail_info(LPCTSTR text, bool large = true) const;
		/**
		* @brief 绘制分割线
		*/
		void _draw_divider() const;

		/**
		* @brief 绘制区域文字
		*/
		void _draw_region_text() const;
		/**
		* @brief 监听面板选择事件
		*/
		void _listen_panel_select(void);
		/**
		* @brief 监听按钮事件
		* @param event 事件
		*/
		void _listen_buttons(ExMessage& event);
		/**
		* @brief 监听键盘事件
		* @param event 事件
		*/
		void _listen_keyboard(ExMessage& event);
		/**
		* @brief 监听游戏区事件
		* @param event 事件
		*/
		void _listen_playground(ExMessage& event);
	};
}