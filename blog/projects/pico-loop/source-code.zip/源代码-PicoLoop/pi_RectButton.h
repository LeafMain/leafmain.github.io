﻿#pragma once

// 矩形按钮类声明
namespace picoloop
{
	/**
	* @brief 矩形按钮类
	*/
	class RectButton : public Button
	{
	public:
		int x; // 按钮左上角 x 坐标
		int y; // 按钮左上角 y 坐标
		int width; // 按钮宽度
		int height; // 按钮高度
		int rx; // 按钮圆角 x 半径
		int ry; // 按钮圆角 y 半径
		int font_size; // 按钮字体大小
		int border_thickness; // 按钮边框宽度
		int border_style; // 按钮边框样式
		LPTSTR text_content; // 按钮文本内容
		LPTSTR font_name; // 按钮字体名称
		COLORREF backgroud_color; // 按钮背景颜色
		COLORREF border_color; // 按钮边框颜色
		COLORREF text_color; // 按钮文本颜色
		COLORREF hover_backgroud_color; // 鼠标悬停时按钮背景颜色
		COLORREF hover_border_color; // 鼠标悬停时按钮边框颜色
		COLORREF hover_text_color; // 鼠标悬停时按钮文本颜色
		COLORREF active_backgroud_color; // 按钮按下时背景颜色
		COLORREF active_border_color; // 按钮按下时边框颜色
		COLORREF active_text_color; // 按钮按下时文本颜色
		COLORREF disabled_color; // 禁用按钮颜色
		/**
		* @brief RectButton 构造函数
		* @param x 按钮左上角 x 坐标，默认为 0
		* @param y 按钮左上角 y 坐标，默认为 0
		* @param width 按钮宽度，默认为 72
		* @param height 按钮高度，默认为 24
		* @param rx 按钮圆角 x 半径，默认为 0
		* @param ry 按钮圆角 y 半径，默认为 0
		* @param font_size 按钮字体大小，默认为 16
		* @param border_thickness 按钮边框宽度，默认为 1
		* @param border_style 按钮边框样式，默认为 PS_SOLID
		* @param text_content 按钮文本内容，默认为 "Button"
		* @param font_name 按钮字体名称，默认为 "Arial"
		* @param backgroud_color 按钮背景颜色，默认为 BLACK
		* @param border_color 按钮边框颜色，默认为 WHITE
		* @param text_color 按钮文本颜色，默认为 WHITE
		* @param hover_backgroud_color 鼠标悬停时按钮背景颜色，默认为 BLACK
		* @param hover_border_color 鼠标悬停时按钮边框颜色，默认为 WHITE
		* @param hover_text_color 鼠标悬停时按钮文本颜色，默认为 WHITE
		* @param active_backgroud_color 按钮按下时背景颜色，默认为 BLACK
		* @param active_border_color 按钮按下时边框颜色，默认为 WHITE
		* @param active_text_color 按钮按下时文本颜色，默认为 WHITE
		* @param disabled_color 禁用按钮颜色，默认为 DARKGRAY
		*/
		explicit RectButton(int x = 0, int y = 0, int width = 72, int height = 24,
			int rx = 0, int ry = 0, int font_size = 16, int border_thickness = 1,
			int border_style = PS_SOLID, LPCTSTR text_content = _T("Button"),
			LPCTSTR font_name = _T("Arial"), COLORREF backgroud_color = BLACK,
			COLORREF border_color = WHITE, COLORREF text_color = WHITE,
			COLORREF hover_backgroud_color = BLACK, COLORREF hover_border_color = WHITE,
			COLORREF hover_text_color = WHITE, COLORREF active_backgroud_color = BLACK,
			COLORREF active_border_color = WHITE, COLORREF active_text_color = WHITE,
			COLORREF disabled_color = DARKGRAY);

		/**
		* @brief RectButton 析构函数
		*/
		~RectButton();

		/**
		* @brief RectButton 复制构造函数
		* @param other 要复制的对象
		*/
		RectButton(const RectButton& other);

		/**
		* @brief RectButton 拷贝赋值函数
		* @param other 要赋值的对象
		* @return 赋值后的对象
		*/
		RectButton& operator=(const RectButton& other);

		/**
		* @brief 绘制矩形按钮
		*/
		void draw() const override;
		/**
		* @brief 判断点是否在矩形按钮区域内
		* @param x 点的x坐标
		* @param y 点的y坐标
		* @return true 点在矩形按钮区域内，false 点不在矩形按钮区域内
		*/
		[[nodiscard]] bool in_area(int x, int y) const override
		{ return x >= this->x && x <= this->x + this->width 
			&& y >= this->y && y <= this->y + this->height; }
		/**
		* @brief 设置按钮文本内容
		* @param text 按钮文本内容
		*/
		void set_text(LPCTSTR text);
	private:
		/**
		* @brief 应用样式
		*/
		void _apply_styles() const; 
	};
}