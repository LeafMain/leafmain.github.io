﻿#pragma once

namespace picoloop
{
    // 对向上砖块刺元素的声明
	class PicoUpBrickThrustElement : public PicoBrickElement
	{
    public:
        using PicoBrickElement::PicoBrickElement;
        /**
        * @brief 绘制向上砖块刺元素
        */
        void draw() const override;
        /**
         * @brief 克隆向上砖块刺元素
         * @return 克隆出的 PicoBrickElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override
        { 
            return new PicoUpBrickThrustElement(*this); 
        }
    protected:
        /**
        * @brief 向上砖块刺元素被踩时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向上砖块刺元素被碰到时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
	};

    // 对向下砖块刺元素的声明
    class PicoDownBrickThrustElement : public PicoBrickElement
    {
    public:
        using PicoBrickElement::PicoBrickElement;
        /**
        * @brief 绘制向下砖块刺元素
        */
        void draw() const override;
        /**
         * @brief 克隆向下砖块刺元素
         * @return 克隆出的 PicoBrickElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override
        {
            return new PicoDownBrickThrustElement(*this);
        }
    protected:
        /**
        * @brief 向下砖块刺元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向下砖块刺元素被碰到时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
    };

    // 对向左砖块刺元素的声明
    class PicoLeftBrickThrustElement : public PicoBrickElement
    {
    public:
        using PicoBrickElement::PicoBrickElement;
        /**
        * @brief 绘制向左砖块刺元素
        */
        void draw() const override;
        /**
         * @brief 克隆向左砖块刺元素
         * @return 克隆出的 PicoBrickElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override
        {
            return new PicoLeftBrickThrustElement(*this);
        }
    protected:
        /**
        * @brief 向左砖块刺元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向左砖块刺元素被碰到时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
    };

    // 对向右砖块刺元素的声明
    class PicoRightBrickThrustElement : public PicoBrickElement
    {
    public:
        using PicoBrickElement::PicoBrickElement;
        /**
        * @brief 绘制向右砖块刺元素
        */
        void draw() const override;
        /**
         * @brief 克隆向右砖块刺元素
         * @return 克隆出的 PicoBrickElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override
        {
            return new PicoRightBrickThrustElement(*this);
        }
    protected:
        /**
        * @brief 向右砖块刺元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向右砖块刺元素被碰到时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
    };
}