﻿#include "picoloop.h"

// 对单次门元素类的实现
namespace picoloop
{
    const COLORREF PicoOneUsedDoorElement::DOOR_COLOR = 0x00b5d7; // 门颜色
    // 期望的事件 1
    const std::vector<PicoOneUsedDoorElement::PLAYER_EVENT>
        PicoOneUsedDoorElement::_expect_events_1 = {
        PLAYER_EVENT::PUSH_LEFT_BEGIN, PLAYER_EVENT::PUSH_LEFT_END,
        PLAYER_EVENT::THROUGH_BEGIN, PLAYER_EVENT::THROUGH_END,
        PLAYER_EVENT::PUSH_RIGHT_BEGIN, PLAYER_EVENT::PUSH_RIGHT_END,
    };
    // 期望的事件 2
    const std::vector<PicoOneUsedDoorElement::PLAYER_EVENT>
        PicoOneUsedDoorElement::_expect_events_2 = {
        PLAYER_EVENT::PUSH_RIGHT_BEGIN, PLAYER_EVENT::PUSH_RIGHT_END,
        PLAYER_EVENT::THROUGH_BEGIN, PLAYER_EVENT::THROUGH_END,
        PLAYER_EVENT::PUSH_LEFT_BEGIN, PLAYER_EVENT::PUSH_LEFT_END,
    };

    // 绘制单次门元素
    void PicoOneUsedDoorElement::draw() const
    {
        if (_closed)
        {
            draw_closed();
        }
        else
        {
            draw_opened();
        }
    }

    // 绘制单次门元素打开时的图像
    void PicoOneUsedDoorElement::draw_opened() const
    {
        _get_bk_image();
        setlinecolor(DOOR_COLOR);
        setlinestyle(PS_SOLID, 1);
        for (int i = 1; i <= 39; i += 13)
        {
            if (i == 14)
            {
                setfillcolor(0x000000);
            }
            else
            {
                setfillcolor(DOOR_COLOR);
            }
            fillrectangle(_40x(i), _40y(1), _40x(i + 13), _40y(3));
            fillrectangle(_40x(i), _40y(37), _40x(i + 13), _40y(39));
        }
    }

    // 绘制单次门元素关闭时的图像
    void PicoOneUsedDoorElement::draw_closed() const
    {
        setlinecolor(DOOR_COLOR);
        setlinestyle(PS_SOLID, 1);
        for (int i = 1; i <= 39; i += 13)
        {
            if (i == 14)
            {
                setfillcolor(0x000000);
            }
            else
            {
                setfillcolor(DOOR_COLOR);
            }
            fillrectangle(_40x(i), _40y(1), _40x(i + 13), _40y(3));
            fillrectangle(_40x(i), _40y(37), _40x(i + 13), _40y(39));
        }
        setfillcolor(DOOR_COLOR);//0x27a2cc
        for (int i = 2; i < 38; i += 6)
        {
            solidrectangle(_40x(i + 2), _40y(3), _40x(i + 4), _40y(37));
        }
    }

    // 重置单次门元素数据
    void PicoOneUsedDoorElement::reset_data()
    {
        base_reset(); // 调用基类的重置方法
        _closed = false;
        _event_queue.clear();
    }

    // 推入事件到事件队列
    void PicoOneUsedDoorElement::_push_event_queue(PLAYER_EVENT player_event)
    {
        if (_closed) return; // 门已经关闭，不再推入事件
        if (_event_queue.size() >= QUEUE_MAX_SIZE)
        {
            _event_queue.pop_front();
        }
        // 防止连续的 THROUGH_BEGIN 和 THROUGH_END 事件
        if (player_event == PLAYER_EVENT::THROUGH_BEGIN ||
            player_event == PLAYER_EVENT::THROUGH_END)
        {
            if (_event_queue.empty() || 
                _event_queue.back() == PLAYER_EVENT::THROUGH_END)
            {
                return;
            }
        }
        _event_queue.push_back(player_event);
    }

    // 检查门是否应该关闭
    void PicoOneUsedDoorElement::_check_close_condition(PicoPlayer& player)
    {
        if (_closed) return; // 已经关闭，不再检查
        // 期望的事件队列匹配
        bool close1 = std::equal(_event_queue.begin(), _event_queue.end(), 
            _expect_events_1.begin(), _expect_events_1.end());
        bool close2 = std::equal(_event_queue.begin(), _event_queue.end(),
            _expect_events_2.begin(), _expect_events_2.end());
        // 如果第二个期望事件队列匹配失败，则门应该保持打开状态
        if (close1 || close2)
        {
            _closed = true;
            erase();
            draw_closed();
            // 若玩家在门范围内，则死亡
            if (in_area(player.x, player.y))
            {
                player.die();
            }
        }
    }

    // 单次门元素被踩时触发的事件
    void PicoOneUsedDoorElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_drop();
                player.enable_jump();
            }
        }
        else
        {
            if (first)
            {
                player.enable_drop();
                player.disable_jump();
            }
        }
    }

    // 单次门元素被顶起时触发的事件
    void PicoOneUsedDoorElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.stop_shift();
            }
        }
    }

    // 单次门元素向左推动时触发的事件
    void PicoOneUsedDoorElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                if (_closed)
                {
                    player.disable_move_left();
                }
                _push_event_queue(PLAYER_EVENT::PUSH_LEFT_BEGIN);
            }
        }
        else
        {
            if (first)
            {
                if (_closed)
                {
                    player.enable_move_left();
                }
                _push_event_queue(PLAYER_EVENT::PUSH_LEFT_END);
                _check_close_condition(player);
            }
        }
    }

    // 单次门元素向右推动时触发的事件
    void PicoOneUsedDoorElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                if (_closed)
                {
                    player.disable_move_right();
                }
                _push_event_queue(PLAYER_EVENT::PUSH_RIGHT_BEGIN);
            }
        }
        else
        {
            if (first)
            {
                if (_closed)
                {
                    player.enable_move_right();
                }
                _push_event_queue(PLAYER_EVENT::PUSH_RIGHT_END);
                _check_close_condition(player);
            }
        }
    }

    // 单次门元素向左推动且未对齐时触发的事件
    void PicoOneUsedDoorElement::on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
            }
        }
    }

    // 单次门元素向右推动且未对齐时触发的事件
    void PicoOneUsedDoorElement::on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                
                player.disable_move_right();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_right();
            }
        }
    }

    // 单次门元素被通过时触发的事件
    void PicoOneUsedDoorElement::on_through(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                _push_event_queue(PLAYER_EVENT::THROUGH_BEGIN);
            }
        }
        else
        {
            if (first)
            {
                _push_event_queue(PLAYER_EVENT::THROUGH_END);
            }
        }
    }

    // 单次门元素被触碰到顶部时触发的事件
    void PicoOneUsedDoorElement::on_touch_top(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.stop_shift();
            }
        }
    }

    // 单次门元素被触碰到底部时触发的事件
    void PicoOneUsedDoorElement::on_touch_bottom(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_drop();
                player.enable_jump();
            }
        }
        else
        {
            if (first)
            {
                player.enable_drop();
                player.disable_jump();
            }
        }
    }
}