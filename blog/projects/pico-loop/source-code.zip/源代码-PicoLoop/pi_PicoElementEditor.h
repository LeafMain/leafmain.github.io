﻿#pragma once

// 元素编辑器类声明
namespace picoloop
{
	/**
	* @brief 元素编辑器类
	*/
	class PicoElementEditor : public PicoElementSelectPanel
	{
	public:
		static const int MAX_HISTORY; // 最大历史长度
		COLORREF hover_color; // 悬停颜色
		PicoElementEditor& operator=(const PicoElementEditor&) = delete;
		/**
		* @brief 元素选择面板类构造函数
		* @param x 元素选择面板左上角 x 坐标，默认为 0
		* @param y 元素选择面板左上角 y 坐标，默认为 0
		* @param grid_row 网格行数，默认为 20
		* @param grid_column 网格列数，默认为 30
		* @param grid_size 网格大小，默认为 40
		* @param line_color 网格线颜色，默认为 LIGHTGRAY
		* @param hover_color 悬停颜色，默认为 GREEN
		* @param select_color 选中颜色，默认为 MAGENTA
		*/
		explicit PicoElementEditor(int x = 0, int y = 0, int grid_row = 20,
			int grid_column = 25, int grid_size = 40, COLORREF line_color = LIGHTGRAY, 
			COLORREF hover_color = GREEN, COLORREF select_color = MAGENTA);
		/**
		* @brief 设置元素
		* @param element_type 元素类型
		* @param row 元素行数
		* @param column 元素列数
		* @param need_draw 是否需要绘制
		* @throw std::run_time_error 元素类型不存在
		* @throw std::run_time_error 元素类型无效
		*/
		void set_element(PicoElementCollection::TYPE element_type,
			int row, int column, bool need_draw = true);
		/**
		* @brief 删除元素
		* @param row 元素行数
		* @param column 元素列数
		* @param need_draw 是否需要绘制
		*/
		void remove_element(int row, int column, bool need_draw = true);
		/**
		* @brief 删除选中元素
		* @throw 没有选中元素，静默失败，不抛出异常
		*/
		void remove_selected_element();
		/**
		* @brief 清空元素
		* @param need_draw 是否需要绘制
		*/
		void clear_elements(bool need_draw = true);
		/**
		* @brief 移除选中元素
		*/
		void remove_select();
		/**
		* @brief 失去元素选择面板和编辑器的焦点
		* @param panel 元素选择面板
		*/
		void blur(PicoElementSelectPanel& panel);
		/**
		* @brief 撤销上一次操作
		*/
		void undo();
		/**
		* @brief 重做上一次操作
		*/
		void redo();
		/**
		* @brief 清空操作历史
		*/
		void clear_history();
		/**
		* @brief 绘制元素编辑器
		*/
		void draw() const;
		/**
		* @brief 监听元素选择面板事件
		* @param event 事件
		*/
		void listen_panel_event(ExMessage& event, PicoElementSelectPanel& panel);
		/**
		* @brief 清空元素的修改状态
		*/
		void clear_modified() { _modified = false; }
		/**
		* @brief 判断操作历史是否溢出
		*/
		[[nodiscard]] bool _history_overflow();
		/**
		* @brief 判断元素是否被修改
		*/
		[[nodiscard]] bool has_been_modified() const { return _modified; }
		/**
		* @brief 判断是否有玩家
		*/
		[[nodiscard]] bool has_player() const 
		{ return _player_row != -1 && _player_column != -1; }
		/**
		* @brief 获取玩家位置行数
		* @return 玩家位置行数，如果不存在，返回 -1
		*/
		[[nodiscard]] int player_row() const { return _player_row; }
		/**
		* @brief 获取玩家位置列数
		* @return 玩家位置列数，如果不存在，返回 -1
		*/
		[[nodiscard]] int player_column() const { return _player_column; }
		/**
		* @brief 返回编辑器元素指针常量
		* @return 元素指针常量
		*/
		[[nodiscard]] PicoElement*** const get_elements() const;
		/**
		* @brief 返回元素类型数据
		* @return 元素类型数据
		*/
		[[nodiscard]] PicoElementCollection::Data get_elements_data() const;
		/**
		* @brief 根据元素类型数据设置元素
		* @param data 元素类型数据
		* @param need_draw 是否需要绘制
		* @throw std::run_time_error 数据中玩家数量超过 1
		*/
		void set_elements_from_data(const PicoElementCollection::Data& data,
			bool need_draw = true);
	private:
		using ELEM_TYPE = PicoElementCollection::TYPE;
		struct DoType // 操作类型
		{
			int row;
			int column;
			ELEM_TYPE type;
			/**
			* @briefDoType 默认构造函数
			* @param row 行数
			* @param column 列数
			* @param type 元素类型
			*/
			DoType(int row = -1, int column = -1, 
				ELEM_TYPE type = ELEM_TYPE::LENGTH) :
				row(row), column(column), type(type) {}
			/**
			* @brief DoType bool 转换运算符，判断是否为空操作
			* @return 是否为空操作
			*/
			operator bool()
			{return row != -1 && column != -1 && type != ELEM_TYPE::LENGTH; }
		};
		int _player_row = -1; // 玩家行数
		int _player_column = -1; // 玩家列数
		bool _prev_move = false; // 上一次是否移动
		bool _prev_clear = false; // 上一次是否清空
		bool _move_drag = false; // 是否在拖动元素
		bool _modified = true; // 是否修改
		std::stack<DoType> _undo_stack; // 撤销栈
		std::stack<DoType> _redo_stack; // 重做栈
		std::stack<DoType> _delete_stack; // 删除栈
		/**
		* @brief 监听鼠标悬停事件
		* @param event 鼠标事件
		* @param panel 元素选择面板
		*/
		void listen_hover(ExMessage& event, PicoElementSelectPanel& panel);
		/**
		* @brief 监听元素选中事件，不可作为公有方法调用
		* @param event 鼠标事件
		* @param panel 元素选择面板
		*/
		void listen_select(ExMessage& event, PicoElementSelectPanel& panel);
		/**
		* @brief 撤销方法辅助函数
		*/
		void _undo_func();
		/**
		* @brief 弹出历史记录
		* @param h_stack 操作栈
		* @throw 出现栈空，抛出异常
		*/
		void _history_pop(std::stack<DoType>& h_stack);
		/**
		* @brief 停止移动时拖动
		*/
		void _stop_move_drag();
	};
}