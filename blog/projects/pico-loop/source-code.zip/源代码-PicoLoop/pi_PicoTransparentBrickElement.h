﻿#pragma once

// 对透明砖块元素类的声明
namespace picoloop
{
    /**
     * @brief 透明砖块元素类
     */
    class PicoTransparentBrickElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制透明砖块元素
        */
        void draw() const override;
        /**
        * @brief 绘制不可见时的透明砖块元素
        */
        void draw_invisible() const;
        /**
        * @brief 绘制出现时的透明砖块元素
        */
        void draw_appeared() const;
        /**
         * @brief 克隆透明砖块元素
         * @return 克隆出的 PicoTransparentBrickElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override
        { return new PicoTransparentBrickElement(*this); }
        /**
         * @brief 重置透明砖块元素数据
         */
        void reset_data() override;
    protected:
        /**
        * @brief 透明砖块元素被踩时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 透明砖块元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 透明砖块元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 透明砖块元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
    private:
        bool _appeared = false; // 透明砖块元素是否出现
    };
}