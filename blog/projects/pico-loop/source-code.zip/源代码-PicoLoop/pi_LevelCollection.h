﻿#pragma once

// 关卡集合类声明
namespace picoloop
{
	/**
	* @brief 关卡集合类
	*/
	class LevelCollection
	{
	public:
		using Data = PicoElementCollection::Data;
		using Set = std::set<int>;
		static const int LEVEL_LIMIT; // 关卡数量上限
		LevelCollection() = delete; // 禁止实例化
		/**
		* @brief 获取关卡名称
		* @param level 关卡编号
		* @return 关卡名称
		*/
		[[nodiscard]] static LPCTSTR get_name(int level);
		/**
		* @brief 获取关卡数据
		* @param level 关卡编号
		* @param ROW 行数
		* @param COLUMN 列数
		* @return 关卡数据
		*/
		[[nodiscard]] static Data get_data(int level);
		/**
		* @brief 判断关卡编号是否在限制范围内
		* @param level 关卡编号
		* @return 是否在限制范围内
		*/
		[[nodiscard]] static bool in_limit(int level)
		{ return level > 0 && level <= LEVEL_LIMIT; }
		/**
		* @brief 获取已通过的关卡编号集合
		* @return 已通过的关卡编号集合
		*/
		[[nodiscard]] static const Set& passed_levels()
		{ return _passed_levels; }
		/**
		* @brief 设置已通过的关卡编号
		* @param level 关卡编号
		*/
		static void set_passed(int level);
	private:
		/**
		* @brief 根据关卡编号返回指定的字符串
		* @param level 关卡编号
		* @return 字符串
		*/
		static std::string _data_string(int level);
		static Set _passed_levels; // 已通过的关卡编号集合
	};
}