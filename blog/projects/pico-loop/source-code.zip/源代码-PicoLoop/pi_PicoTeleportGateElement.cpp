﻿#include "picoloop.h"

// 对传送门元素类的实现
namespace picoloop
{
    // 绘制传送门元素
    void PicoTeleportGateElement::draw() const
    {
        _get_bk_image();   // 保留原调用，实际无影响
        const double PI = 3.14159265;
        int r = size / 2 - 2, n = 10;
        int x = _40x(20), y = _40y(20);
        setlinestyle(0, 2);
        setlinecolor(0xbc5ca4);
        setfillcolor(0x760a65);
        fillcircle(x, y, r + 1);
        setlinestyle(0, 1);
        for (int i = 0; i < n; i++)
        {
            double ang = PI * 2 / n * i;
            int mr = r / 2;
            int rx = int(x + mr * cos(ang));
            int ry = int(y - mr * sin(ang));
            setlinecolor(0xd060d0);
            arc(rx - mr, ry - mr, rx + mr, ry + mr, ang, ang + PI);
        }
        putpixel(_40x(20), _40y(20), 0x760a65);
    }

    // 传送门元素通过时触发的事件
    void PicoTeleportGateElement::on_through(PicoPlayer& player, 
        bool occurred, bool first)
    {
        if (occurred)
        {
            if (first && !player.has_transferred())
            {
                player.set_transferred(true);
                player.transfer_to_next(x, y, (size - player.size) / 2,
                    (size - player.size) / 2 - PicoPlayer::MOVE_STEP);
            }
        }
        else
        {
            if (first)
            {
                player.set_transferred(false);
                // 防止速度过快
                player.limit_speed_y(PicoPlayer::MAX_DROP_SPEED);
            }
        }
    }
}