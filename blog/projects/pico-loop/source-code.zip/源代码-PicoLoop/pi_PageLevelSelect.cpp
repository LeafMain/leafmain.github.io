﻿#include "picoloop.h"

// 主页类静态常量定义
namespace picoloop
{
	const COLORREF PageLevelSelect::COLOR::BACKGROUND = 0x111111; // 背景颜色
	const COLORREF PageLevelSelect::COLOR::TITLE = LIGHTRED; // 标题颜色
	const COLORREF PageLevelSelect::COLOR::LEVEL_BORDER = DARKGRAY; // 关卡边框颜色
	const COLORREF PageLevelSelect::COLOR::SELECTOR_BACKGROUND = 0x118800; // 选择器背景颜色
	const COLORREF PageLevelSelect::COLOR::SELECTOR_BORDER = 0x008800; // 选择器边框颜色
	const COLORREF PageLevelSelect::COLOR::SELECTOR_TEXT = BLACK; // 选择器文字颜色
	const COLORREF PageLevelSelect::COLOR::SELECTOR_HOVER = CYAN; // 选择器悬停颜色
	const COLORREF PageLevelSelect::COLOR::SELECTOR_SELECTED = 0xFFFF00; // 选择器选中颜色
	const COLORREF PageLevelSelect::COLOR::GRID_LINE = BACKGROUND; // 网格线颜色
	const COLORREF PageLevelSelect::COLOR::GRID_SELECTED = LIGHTRED; // 网格选中颜色
	const COLORREF PageLevelSelect::COLOR::BUTTON = LIGHTGRAY; // 按钮颜色
	const COLORREF PageLevelSelect::COLOR::BUTTON_HOVER = DARKGRAY; // 按钮悬停颜色
	const COLORREF PageLevelSelect::COLOR::LEVEL_PASSED = 0x880000; // 关卡通过颜色
	const LPCTSTR PageLevelSelect::FONT::TITLE_FONT = // 标题字体颜色
		_T("Arial Black"); 
	const LPCTSTR PageLevelSelect::FONT::BUTTON_FONT = // 按钮字体颜色
		_T("Arial Rounded MT Bold"); 
}

// 主页类实现
namespace picoloop
{
	// PageLevelSelect 构造函数
	PageLevelSelect::PageLevelSelect(Game& game) :
		Page(game),
		level_selector{
			65, 90, 80, 6, 10, LevelCollection::LEVEL_LIMIT, 
			COLOR::SELECTOR_BACKGROUND, COLOR::SELECTOR_BORDER,
			COLOR::SELECTOR_TEXT, COLOR::SELECTOR_HOVER, 
			COLOR::SELECTOR_SELECTED, COLOR::LEVEL_PASSED
		},
		grid{ 
			60, 85, 7, 12, 90, 2, PS_SOLID,
			COLOR::GRID_LINE, COLOR::GRID_LINE, COLOR::GRID_SELECTED
		}, button_help{
			250, 730, 100, 55, 3, 3, 33, 1, PS_SOLID,
			_T("Help"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON, COLOR::BUTTON, COLOR::BACKGROUND,
			COLOR::BUTTON_HOVER, COLOR::BUTTON_HOVER
		}, button_back{
			850, 730, 100, 55, 3, 3, 33, 1, PS_SOLID,
			_T("Back"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON, COLOR::BUTTON, COLOR::BACKGROUND,
			COLOR::BUTTON_HOVER, COLOR::BUTTON_HOVER
		}
	{}

	// 绘制页面
	void PageLevelSelect::draw_page() const
	{
		setlinecolor(COLOR::LEVEL_BORDER);
		setlinestyle(PS_DOT, 1);
		rectangle(50, 75, 1150, 720);
		settextcolor(COLOR::TITLE);
		settextstyle(55, 0, FONT::TITLE_FONT);
		RECT rect = { 50, 10, 1150, 70 };
		drawtext(_T("Select a level to play"), &rect,
			DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		level_selector.draw();
		button_help.draw();
		button_back.draw();
		grid.draw();
	}

	// 页面进入时调用
	void PageLevelSelect::on_enter()
	{
		_apply_passed_levels();
	}

	// 聚焦第一个关卡
	void PageLevelSelect::_focus_first()
	{
		// 关卡数量为0，则不聚焦
		if (level_selector.level_limit() < 1)
		{
			return;
		}
		// 聚焦第一个关卡
		grid.set_active(0, 0);
	}

	// 聚焦下一个关卡
	void PageLevelSelect::_focus_next()
	{
		// 如果没有焦点，则聚焦第一个关卡
		if (!grid.has_active())
		{
			_focus_first();
			return;
		}
		// 获取当前选中项
		int row = grid.active_row();
		int col = grid.active_column();
		int index = row * grid.COLUMN + col + 1;
		// 如果超过了最大限制关卡数，则失去焦点
		if (index >= level_selector.level_limit())
		{
			grid.remove_active();
			return;
		}
		// 移动到下一项
		if (col < grid.COLUMN - 1)
		{
			grid.set_active(row, col + 1);
		}
		// 移动到下一行
		else if (row < grid.ROW - 1)
		{
			grid.set_active(row + 1, 0);
		}
		// 移到最后一项，失去焦点
		else
		{
			grid.remove_active();
		}
	}

	// 聚焦上一个关卡
	void PageLevelSelect::_focus_prev()
	{
		// 如果没有焦点，则聚焦第一个关卡
		if (!grid.has_active())
		{
			_focus_first();
			return;
		}
		// 获取当前选中项
		int row = grid.active_row();
		int col = grid.active_column();
		int index = row * grid.COLUMN + col - 1;
		// 如果超过了最大限制关卡数，则失去焦点
		if (index >= level_selector.level_limit())
		{
			grid.remove_active();
			return;
		}
		// 移动到上一项
		if (col > 0)
		{
			grid.set_active(row, col - 1);
		}
		// 移动到上一行
		else if (row > 0)
		{
			grid.set_active(row - 1, grid.COLUMN - 1);
		}
		// 移到第一项，失去焦点
		else
		{
			grid.remove_active();
		}
	}

	// 将焦点移动到下一行
	void PageLevelSelect::_focus_next_line()
	{
		// 如果没有焦点，则聚焦第一个关卡
		if (!grid.has_active())
		{
			_focus_first();
			return;
		}
		// 获取当前选中项
		int row = grid.active_row();
		int col = grid.active_column();
		int index = (row + 1) * grid.COLUMN + col;
		// 如果超过了最大限制关卡数，则失去焦点
		if (index >= level_selector.level_limit())
		{
			grid.remove_active();
			return;
		}
		// 移动到下一行
		if (row < grid.ROW - 1)
		{
			grid.set_active(row + 1, col);
		}
		// 移到最后一项，失去焦点
		else
		{
			grid.remove_active();
		}
	}

	// 将焦点移动到上一行
	void PageLevelSelect::_focus_prev_line()
	{
		// 如果没有焦点，则聚焦第一个关卡
		if (!grid.has_active())
		{
			_focus_first();
			return;
		}
		// 获取当前选中项
		int row = grid.active_row();
		int col = grid.active_column();
		int index = (row - 1) * grid.COLUMN + col;
		// 如果超过了最大限制关卡数，则失去焦点
		if (index >= level_selector.level_limit())
		{
			grid.remove_active();
			return;
		}
		// 移动到上一行
		if (row > 0)
		{
			grid.set_active(row - 1, col);
		}
		// 移到第一项，失去焦点
		else
		{
			grid.remove_active();
		}
	}

    // 选择事件
	void PageLevelSelect::_listen_select(ExMessage& event)
	{
		for (int level = 1; level <= level_selector.level_limit(); level++)
		{
			if (level_selector.selected(level, event))
			{
				_enter_playing(level);
				break;
			}
		}
	}

	// 进入关卡
	void PageLevelSelect::_enter_playing(int level)
	{
		// 关卡编号超出范围，则忽略
		if (level < 1 || level > level_selector.level_limit())
		{
			return;
		}
		grid.remove_active(); // 失去焦点
		// 加载关卡数据并进入游戏
		game.page_game_create.set_level_name(LevelCollection::get_name(level));
		game.page_game_create.set_level_number(level);
		game.page_game_create.load_data(LevelCollection::get_data(level));
		game.page_playground.enter();
		// 设置上一页面为本页面
		game.page_playground.set_previous_page(this);
	}

	// 进入帮助页面
	void PageLevelSelect::_enter_help()
	{
		game.page_handbook.enter();
	}

	// 加载通过的关卡集合
	void PageLevelSelect::_load_passed_levels()
	{
		// 读取或创建文件
		std::string path = std::string(game.parent_path()) + 
			std::string("\\Data\\Levels");
		auto mode = std::ios::in | std::ios::out | std::ios::app;
		std::fstream file(path, mode);
		// 如果打开失败，取消操作
		if (!file)
		{
			// 重新创建目录
			 game.create_directories();
			return;
		}
		int level = 0;
		while (file >> level)
		{
			// 跳过数值不正确的关卡
			if (level < 1 || level > level_selector.level_limit())
			{
				continue;
			}
			// 放进通过关卡集合中
			LevelCollection::set_passed(level);
		}
		file.close();
	}

	// 应用通过的关卡
	void PageLevelSelect::_apply_passed_levels()
	{
		if (!_passed_levels_loaded)
		{
			_load_passed_levels();
			_passed_levels_loaded = true;
		}
		if (LevelCollection::passed_levels().empty())
		{
			return; // 空集合，无需应用
		}
		// 遍历所有关卡
		int level_limit = level_selector.level_limit();
		for (int level = 1; level <= level_limit; level++)
		{
			// 如果关卡存在于集合中，则设置为通过
			if (LevelCollection::passed_levels().count(level))
			{
				level_selector.set_passed(level, true, false);
			}
		}
	}

	// 监听事件
	void PageLevelSelect::listen_event(ExMessage& event)
	{
		if (event.message == WM_LBUTTONDOWN)
		{
			_listen_select(event);
			// 当点击返回按钮时，返回到主页
			if (button_back.clicked(event))
			{
				game.page_main.enter();
				event.message = WM_NULL;
			}
			// 当点击帮助按钮时，进入帮助页面
			else if (button_help.clicked(event))
			{
				_enter_help();
				event.message = WM_NULL;
			}
		}
		else if (event.message == WM_MOUSEMOVE)
		{
			level_selector.listen_hover(event);
			button_help.listen_hover(event);
			button_back.listen_hover(event);
		}
		else if (event.message == WM_KEYDOWN && !event.prevdown)
		{
			switch(event.vkcode)
			{
			case VK_RIGHT: // 按下右方向键，聚焦下一个关卡
				_focus_next();
				break;
			case VK_LEFT: // 按下左方向键，聚焦上一个关卡
				_focus_prev();
				break;
			case VK_UP: // 按下上方向键，聚焦上一行
				_focus_prev_line();
				break;
			case VK_DOWN: // 按下下方向键，聚焦下一行
				_focus_next_line();
				break;
			case VK_TAB: // 按下Tab键，聚焦下一个或上一个
				if (GetAsyncKeyState(VK_SHIFT) & 0x8000)
				{
					_focus_prev();
				}
				else
				{
					_focus_next();
				}
				break;
			case VK_RETURN: // 按下回车键，开始游戏
				if (grid.has_active())
				{
					int index = grid.active_row() * grid.COLUMN + 
						grid.active_column() + 1;
					_enter_playing(index);
				}
				break;
			case VK_ESCAPE: // 按下Esc键，返回到主页
				game.page_main.enter();
				break;
			case 'H': 
			case 'h': // 按下H键，进入帮助页面
				_enter_help();
			}
		}
	}
}