﻿#include "picoloop.h"

// 主页类静态常量定义
namespace picoloop
{
	const COLORREF PageMakeSelect::COLOR::BACKGROUND = 0x111111; // 背景颜色
	const COLORREF PageMakeSelect::COLOR::TITLE = LIGHTRED; // 标题颜色
	const COLORREF PageMakeSelect::COLOR::LEVEL_BORDER = DARKGRAY; // 关卡边框颜色
	const COLORREF PageMakeSelect::COLOR::SELECTOR_BACKGROUND = 0x998800; // 选择器背景颜色
	const COLORREF PageMakeSelect::COLOR::SELECTOR_BORDER = 0x888800; // 选择器边框颜色
	const COLORREF PageMakeSelect::COLOR::SELECTOR_TEXT = BLACK; // 选择器文字颜色
	const COLORREF PageMakeSelect::COLOR::SELECTOR_HOVER = GREEN; // 选择器悬停颜色
	const COLORREF PageMakeSelect::COLOR::SELECTOR_SELECTED = 0xFFFF00; // 选择器选中颜色
	const COLORREF PageMakeSelect::COLOR::GRID_LINE = BACKGROUND; // 网格线颜色
	const COLORREF PageMakeSelect::COLOR::GRID_SELECTED = LIGHTRED; // 网格选中颜色
	const COLORREF PageMakeSelect::COLOR::BUTTON = LIGHTGRAY; // 按钮颜色
	const COLORREF PageMakeSelect::COLOR::BUTTON_HOVER = DARKGRAY; // 按钮悬停颜色
	const LPCTSTR PageMakeSelect::FONT::TITLE_FONT = _T("Arial Black"); // 按钮字体颜色
	const LPCTSTR PageMakeSelect::FONT::BUTTON_FONT = _T("Arial Rounded MT Bold"); // 按钮字体颜色
}

// 主页类实现
namespace picoloop
{
	// PageMakeSelect 构造函数
	PageMakeSelect::PageMakeSelect(Game& game) :
		Page(game),
		level_selector{
			65, 90, 80, 6, 10, LevelSelector::LEVEL_COUNT, 
			COLOR::SELECTOR_BACKGROUND, COLOR::SELECTOR_BORDER,
			COLOR::SELECTOR_TEXT, COLOR::SELECTOR_HOVER, COLOR::SELECTOR_SELECTED
		},
		grid{
			60, 85, 7, 12, 90, 2, PS_SOLID,
			COLOR::GRID_LINE, COLOR::GRID_LINE, COLOR::GRID_SELECTED
		}, button_help{
			250, 730, 100, 55, 3, 3, 33, 1, PS_SOLID,
			_T("Help"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON, COLOR::BUTTON, COLOR::BACKGROUND,
			COLOR::BUTTON_HOVER, COLOR::BUTTON_HOVER
		}, button_back{
			850, 730, 100, 55, 3, 3, 33, 1, PS_SOLID,
			_T("Back"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON, COLOR::BUTTON, COLOR::BACKGROUND,
			COLOR::BUTTON_HOVER, COLOR::BUTTON_HOVER
		}
	{
	}

	// 绘制页面
	void PageMakeSelect::draw_page() const
	{
		setlinecolor(COLOR::LEVEL_BORDER);
		setlinestyle(PS_DOT, 1);
		rectangle(50, 75, 1150, 720);
		settextcolor(COLOR::TITLE);
		settextstyle(55, 0, FONT::TITLE_FONT);
		RECT rect = { 50, 10, 1150, 70 };
		drawtext(_T("Select a level to make"), &rect, 
			DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		level_selector.draw();
		button_help.draw();
		button_back.draw();
		grid.draw();
	}

	// 聚焦第一个关卡
	void PageMakeSelect::_focus_first()
	{
		// 关卡数量为0，则不聚焦
		if (level_selector.level_limit() < 1)
		{
			return;
		}
		// 聚焦第一个关卡
		grid.set_active(0, 0);
	}

	// 聚焦下一个关卡
	void PageMakeSelect::_focus_next()
	{
		// 如果没有焦点，则聚焦第一个关卡
		if (!grid.has_active())
		{
			_focus_first();
			return;
		}
		// 获取当前选中项
		int row = grid.active_row();
		int col = grid.active_column();
		int index = row * grid.COLUMN + col + 1;
		// 如果超过了最大限制关卡数，则失去焦点
		if (index >= level_selector.level_limit())
		{
			grid.remove_active();
			return;
		}
		// 移动到下一项
		if (col < grid.COLUMN - 1)
		{
			grid.set_active(row, col + 1);
		}
		// 移动到下一行
		else if (row < grid.ROW - 1)
		{
			grid.set_active(row + 1, 0);
		}
		// 移到最后一项，失去焦点
		else
		{
			grid.remove_active();
		}
	}

	// 聚焦上一个关卡
	void PageMakeSelect::_focus_prev()
	{
		// 如果没有焦点，则聚焦第一个关卡
		if (!grid.has_active())
		{
			_focus_first();
			return;
		}
		// 获取当前选中项
		int row = grid.active_row();
		int col = grid.active_column();
		int index = row * grid.COLUMN + col - 1;
		// 如果超过了最大限制关卡数，则失去焦点
		if (index >= level_selector.level_limit())
		{
			grid.remove_active();
			return;
		}
		// 移动到上一项
		if (col > 0)
		{
			grid.set_active(row, col - 1);
		}
		// 移动到上一行
		else if (row > 0)
		{
			grid.set_active(row - 1, grid.COLUMN - 1);
		}
		// 移到第一项，失去焦点
		else
		{
			grid.remove_active();
		}
	}

	// 将焦点移动到下一行
	void PageMakeSelect::_focus_next_line()
	{
		// 如果没有焦点，则聚焦第一个关卡
		if (!grid.has_active())
		{
			_focus_first();
			return;
		}
		// 获取当前选中项
		int row = grid.active_row();
		int col = grid.active_column();
		int index = (row + 1) * grid.COLUMN + col;
		// 如果超过了最大限制关卡数，则失去焦点
		if (index >= level_selector.level_limit())
		{
			grid.remove_active();
			return;
		}
		// 移动到下一行
		if (row < grid.ROW - 1)
		{
			grid.set_active(row + 1, col);
		}
		// 移到最后一项，失去焦点
		else
		{
			grid.remove_active();
		}
	}

	// 将焦点移动到上一行
	void PageMakeSelect::_focus_prev_line()
	{
		// 如果没有焦点，则聚焦第一个关卡
		if (!grid.has_active())
		{
			_focus_first();
			return;
		}
		// 获取当前选中项
		int row = grid.active_row();
		int col = grid.active_column();
		int index = (row - 1) * grid.COLUMN + col;
		// 如果超过了最大限制关卡数，则失去焦点
		if (index >= level_selector.level_limit())
		{
			grid.remove_active();
			return;
		}
		// 移动到上一行
		if (row > 0)
		{
			grid.set_active(row - 1, col);
		}
		// 移到第一项，失去焦点
		else
		{
			grid.remove_active();
		}
	}

	// 监听选择事件
	void PageMakeSelect::_listen_select(ExMessage& event)
	{
		const int LIMIT = level_selector.level_limit();
		for (int level = 1; level <= LIMIT; level++)
		{
			if (level_selector.selected(level, event))
			{
				_enter_making(level);
				return;
			}
		}
	}

	// 进入指定制作关卡
	void PageMakeSelect::_enter_making(int level)
	{
		// 超过最大限制关卡数，则不进入制作关卡
		if (level < 1 || level > LevelSelector::LEVEL_COUNT)
		{
			return;
		}
		grid.remove_active(); // 失去焦点
		TCHAR l_text[12]{};
		TCHAR l_name[48]{};
		_itot_s(level, l_text, 12, 10);
		_tcsncat_s(l_name, _countof(l_name), _T("Mk-"), 46);
		_tcsncat_s(l_name, _countof(l_name), l_text, 46);
		_tcsncat_s(l_name, _countof(l_name), _T("\nMade by Myself"), 46);
		std::string file_name = "Mk-";
		file_name += std::to_string(level);
		// 设置关卡名称
		game.page_game_create.set_level_name(l_name);
		game.page_game_create.set_level_number(0);
		// 设置关卡文件名
		game.page_game_create.load_data(file_name);
		game.page_game_create.enter();
	}

	// 进入帮助页面
	void PageMakeSelect::_enter_help()
	{
		game.page_handbook.enter();
	}

	// 监听事件
	void PageMakeSelect::listen_event(ExMessage& event)
	{
		if (event.message == WM_LBUTTONDOWN)
		{
			_listen_select(event);
			// 点击返回按钮，返回主页
			if (button_back.clicked(event))
			{
				game.page_main.enter();
				event.message = WM_NULL;
			}
			// 点击帮助按钮，进入帮助页面
			else if (button_help.clicked(event))
			{
				_enter_help();
				event.message = WM_NULL;
			}
		}
		else if (event.message == WM_MOUSEMOVE)
		{
			level_selector.listen_hover(event);
			button_help.listen_hover(event);
			button_back.listen_hover(event);
		}
		else if (event.message == WM_KEYDOWN && !event.prevdown)
		{
			switch (event.vkcode)
			{
			case VK_RIGHT: // 按下右方向键，聚焦下一个关卡
				_focus_next();
				break;
			case VK_LEFT:  // 按下左方向键，聚焦上一个关卡
				_focus_prev();
				break;
			case VK_UP:
				_focus_prev_line(); // 按下上方向键，聚焦上一行
				break;
			case VK_DOWN:
				_focus_next_line(); // 按下下方向键，聚焦下一行
				break;
			case VK_TAB:  // 按下Tab键，聚焦下一个或上一个
				if (GetAsyncKeyState(VK_SHIFT) & 0x8000)
				{
					_focus_prev();
				}
				else
				{
					_focus_next();
				}
				break;
			case VK_RETURN:  // 按下回车键，进入制作关卡
				if (grid.has_active())
				{
					int index = grid.active_row() * grid.COLUMN + 
						grid.active_column() + 1;
					_enter_making(index);
				}
				break;
			case VK_ESCAPE:  // 按下Esc键，返回主页
				game.page_main.enter();
				break;
			case 'H':
			case 'h': // 按下H键，进入帮助页面
				_enter_help();
			}
		}
	}
}