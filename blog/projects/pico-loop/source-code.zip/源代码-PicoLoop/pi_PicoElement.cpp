﻿#include "picoloop.h"

// Pico元素抽象类实现
namespace picoloop
{
	const bool PicoElement::DISABLE_ANIMATION = true; // 禁用动画
	const int PicoElement::ELEMENT_INIT_SIZE = 40; // 元素初始大小

	// PicoElement 构造函数
	PicoElement::PicoElement(int x, int y, int size) :
		x(x), y(y), size(size) 
	{
		// 预计算常量
		if (!_init_pre_calc_40)
		{
			_pre_calc_40();
			_init_pre_calc_40 = true;
		}
	}

	// 判断元素是否被点击
	bool PicoElement::clicked(ExMessage& event) const
	{
		return event.message == WM_LBUTTONDOWN &&
			in_area(event.x, event.y);
	}

	// 将元素后面的背景缓存
	void PicoElement::_get_bk_image() const
	{
		getimage(&_bk_image_, x, y, size + 1, size + 1);
	}

	// 将元素后面的背景缓存绘制到屏幕上
	void PicoElement::_put_bk_image() const
	{
		putimage(x, y, &_bk_image_);
	}

	// 擦除元素
	void PicoElement::erase() const
	{
		_put_bk_image();
	}

	// 监听玩家事件
	void PicoElement::listen_player(PicoPlayer& player)
	{
		// 元素是否被碰到
		if (bumped_by(player)) // 玩家碰到元素
		{
			if (!_bumped)
			{
				on_bump(player, true, true);
				_bumped = true;
			}
			else
			{
				on_bump(player, true, false);
			}
		}
		else // 玩家未碰到元素
		{
			if (_bumped)
			{
				on_bump(player, false, true);
				_bumped = false;
			}
			else
			{
				on_bump(player, false, false);
			}
		}
		// 元素是否被踩到
		if (pedaled_by(player)) // 玩家踩到元素
		{
			if (!_pedaled)
			{
				on_pedal(player, true, true);
				_pedaled = true;
			}
			else
			{
				on_pedal(player, true, false);
			}
		}
		else // 玩家未踩到元素
		{
			if (_pedaled)
			{
				on_pedal(player, false, true);
				_pedaled = false;
			}
			else
			{
				on_pedal(player, false, false);
			}
		}
		// 元素是否被顶起
		if (jumped_by(player)) // 玩家顶起元素
		{
			if (!_jumped)
			{
				on_jump(player, true, true);
				_jumped = true;
			}
			else
			{
				on_jump(player, true, false);
			}
		}
		else // 玩家未顶起元素
		{
			if (_jumped)
			{
				on_jump(player, false, true);
				_jumped = false;
			}
			else
			{
				on_jump(player, false, false);
			}
		}
		// 元素是否被左推
		if (pushed_left_by(player)) // 玩家左推元素
		{
			if (!_left_pushed)
			{
				on_push_left(player, true, true);
				_left_pushed = true;
			}
			else
			{
				on_push_left(player, true, false);
			}
		}
		else // 玩家未左推元素
		{
			if (_left_pushed)
			{
				on_push_left(player, false, true);
				_left_pushed = false;
			}
			else
			{
				on_push_left(player, false, false);
			}
		}
		// 元素是否被右推
		if (pushed_right_by(player)) // 玩家右推元素
		{
			if (!_right_pushed)
			{
				on_push_right(player, true, true);
				_right_pushed = true;
			}
			else
			{
				on_push_right(player, true, false);
			}
		}
		else // 玩家未右推元素
		{
			if (_right_pushed)
			{
				on_push_right(player, false, true);
				_right_pushed = false;
			}
			else
			{
				on_push_right(player, false, false);
			}
		}
		// 元素是否被通过
		if (through_by(player))
		{
			if (!_through)
			{
				on_through(player, true, true);
				_through = true;
			}
			else
			{
				on_through(player, true, false);
			}
		}
		else
		{
			if (_through)
			{
				on_through(player, false, true);
				_through = false;
			}
			else
			{
				on_through(player, false, false);
			}
		}
		// 元素是否被触碰到内壁左侧
		if (touched_left_by(player))
		{
			if (!_touched_left)
			{
				on_touch_left(player, true, true);
				_touched_left = true;
			}
			else
			{
				on_touch_left(player, true, false);
			}
		}
		else
		{
			if (_touched_left)
			{
				on_touch_left(player, false, true);
				_touched_left = false;
			}
			else
			{
				on_touch_left(player, false, false);
			}
		}
		// 元素是否被触碰到内壁顶部
		if (touched_top_by(player))
		{
			if (!_touched_top)
			{
				on_touch_top(player, true, true);
				_touched_top = true;
			}
			else
			{
				on_touch_top(player, true, false);
			}
		}
		else
		{
			if (_touched_top)
			{
				on_touch_top(player, false, true);
				_touched_top = false;
			}
			else
			{
				on_touch_top(player, false, false);
			}
		}
		// 元素是否被触碰到内壁右侧
		if (touched_right_by(player))
		{
			if (!_touched_right)
			{
				on_touch_right(player, true, true);
				_touched_right = true;
			}
			else
			{
				on_touch_right(player, true, false);
			}
		}
		else
		{
			if (_touched_right)
			{
				on_touch_right(player, false, true);
				_touched_right = false;
			}
			else
			{
				on_touch_right(player, false, false);
			}
		}
		// 元素是否被触碰到内壁底部
		if (touched_bottom_by(player))
		{
			if (!_touched_bottom)
			{
				on_touch_bottom(player, true, true);
				_touched_bottom = true;
			}
			else
			{
				on_touch_bottom(player, true, false);
			}
		}
		else
		{
			if (_touched_bottom)
			{
				on_touch_bottom(player, false, true);
				_touched_bottom = false;
			}
			else
			{
				on_touch_bottom(player, false, false);
			}
		}
		// 元素是否被踩到且不对齐
		if (unaligned_pedaled_by(player))
		{
			if (!_unaligned_pedaled)
			{
				on_unaligned_pedal(player, true, true);
				_unaligned_pedaled = true;
			}
			else
			{
				on_unaligned_pedal(player, true, false);
			}
		}
		else
		{
			if (_unaligned_pedaled)
			{
				on_unaligned_pedal(player, false, true);
				_unaligned_pedaled = false;
			}
			else
			{
				on_unaligned_pedal(player, false, false);
			}
		}
		// 元素是否被顶起且不对齐
		if (unaligned_jumped_by(player))
		{
			if (!_unaligned_jumped)
			{
				on_unaligned_jump(player, true, true);
				_unaligned_jumped = true;
			}
			else
			{
				on_unaligned_jump(player, true, false);
			}
		}
		else
		{
			if (_unaligned_jumped)
			{
				on_unaligned_jump(player, false, true);
				_unaligned_jumped = false;
			}
			else
			{
				on_unaligned_jump(player, false, false);
			}
		}
		// 元素是否被左推且不对齐
		if (unaligned_pushed_left_by(player))
		{
			if (!_unaligned_left_pushed)
			{
				on_unaligned_push_left(player, true, true);
				_unaligned_left_pushed = true;
			}
			else
			{
				on_unaligned_push_left(player, true, false);
			}
		}
		else
		{
			if (_unaligned_left_pushed)
			{
				on_unaligned_push_left(player, false, true);
				_unaligned_left_pushed = false;
			}
			else
			{
				on_unaligned_push_left(player, false, false);
			}
		}
		// 元素是否被右推且不对齐
		if (unaligned_pushed_right_by(player))
		{
			if (!_unaligned_right_pushed)
			{
				on_unaligned_push_right(player, true, true);
				_unaligned_right_pushed = true;
			}
			else
			{
				on_unaligned_push_right(player, true, false);
			}
		}
		else
		{
			if (_unaligned_right_pushed)
			{
				on_unaligned_push_right(player, false, true);
				_unaligned_right_pushed = false;
			}
			else
			{
				on_unaligned_push_right(player, false, false);
			}
		}
		// 元素是否被触碰到内壁左侧且不对齐
		if (unaligned_touched_left_by(player))
		{
			if (!_unaligned_touched_left)
			{
				on_unaligned_touch_left(player, true, true);
				_unaligned_touched_left = true;
			}
			else
			{
				on_unaligned_touch_left(player, true, false);
			}
		}
		else
		{
			if (_unaligned_touched_left)
			{
				on_unaligned_touch_left(player, false, true);
				_unaligned_touched_left = false;
			}
			else
			{
				on_unaligned_touch_left(player, false, false);
			}
		}
		// 元素是否被触碰到内壁顶部且不对齐
		if (unaligned_touched_top_by(player))
		{
			if (!_unaligned_touched_top)
			{
				on_unaligned_touch_top(player, true, true);
				_unaligned_touched_top = true;
			}
			else
			{
				on_unaligned_touch_top(player, true, false);
			}
		}
		else
		{
			if (_unaligned_touched_top)
			{
				on_unaligned_touch_top(player, false, true);
				_unaligned_touched_top = false;
			}
			else
			{
				on_unaligned_touch_top(player, false, false);
			}
		}
		// 元素是否被触碰到内壁右侧且不对齐
		if (unaligned_touched_right_by(player))
		{
			if (!_unaligned_touched_right)
			{
				on_unaligned_touch_right(player, true, true);
				_unaligned_touched_right = true;
			}
			else
			{
				on_unaligned_touch_right(player, true, false);
			}
		}
		else
		{
			if (_unaligned_touched_right)
			{
				on_unaligned_touch_right(player, false, true);
				_unaligned_touched_right = false;
			}
			else
			{
				on_unaligned_touch_right(player, false, false);
			}
		}
		// 元素是否被触碰到内壁底部且不对齐
		if (unaligned_touched_bottom_by(player))
		{
			if (!_unaligned_touched_bottom)
			{
				on_unaligned_touch_bottom(player, true, true);
				_unaligned_touched_bottom = true;
			}
			else
			{
				on_unaligned_touch_bottom(player, true, false);
			}
		}
		else
		{
			if (_unaligned_touched_bottom)
			{
				on_unaligned_touch_bottom(player, false, true);
				_unaligned_touched_bottom = false;
			}
			else
			{
				on_unaligned_touch_bottom(player, false, false);
			}
		}
	}

	// 更新系统时钟
	void PicoElement::update_clock()
	{
		return; // 子类实现，需要设置 clock_now = std::clock();
	}

	// 更新动画
	void PicoElement::update_animation()
	{
		return; // 子类实现
	}

	// 重置基础元素数据，子类需在 reset_data() 调用
	void PicoElement::base_reset()
	{
		// 重置基础数据
		_bumped = false;
		_pedaled = false;
		_jumped = false;
		_left_pushed = false;
		_right_pushed = false;
		_through = false;
		_touched_left = false;
		_touched_top = false;
		_touched_right = false;
		_touched_bottom = false;
		_unaligned_pedaled = false;
		_unaligned_jumped = false;
		_unaligned_left_pushed = false;
		_unaligned_right_pushed = false;
		_unaligned_touched_left = false;
		_unaligned_touched_top = false;
		_unaligned_touched_right = false;
		_unaligned_touched_bottom = false;
	}

	// 重置元素数据
	void PicoElement::reset_data()
	{
		base_reset(); // 默认调用 base_reset() 重置基础数据
		return; // 子类实现，重写时需调用基类 base_reset()
	}

	// 判断元素是否被玩家碰到
	bool PicoElement::bumped_by(const PicoPlayer& player) const
	{
		// 四个顶点，只要有一个在元素的范围内，就认为玩家碰到了元素
		return in_area(player.x, player.y) ||
			in_area(player.x + player.size, player.y) ||
			in_area(player.x, player.y + player.size) ||
			in_area(player.x + player.size, player.y + player.size);
	}

	// 判断元素是否被玩家踩到
	bool PicoElement::pedaled_by(const PicoPlayer& player) const
	{
		return this->y > player.y + player.size &&
			this->y <= player.y + player.size + player.MOVE_STEP &&
			this->x <= player.x + player.size &&
			this->x + this->size >= player.x;
	}

	// 判断元素是否被玩家顶起
	bool PicoElement::jumped_by(const PicoPlayer& player) const
	{
		return this->y + this->size < player.y + player.MOVE_STEP &&
			this->y + this->size >= player.y  &&
			this->x + this->size >= player.x &&
			this->x <= player.x + player.size;
	}

	// 判断元素是否被玩家向左推
	bool PicoElement::pushed_left_by(const PicoPlayer& player) const
	{
		return this->x + this->size < player.x &&
			this->x + this->size >= player.x - player.MOVE_STEP &&
			this->y + this->size >= player.y &&
			this->y <= player.y + player.size;
	}

	// 判断元素是否被玩家向右推
	bool PicoElement::pushed_right_by(const PicoPlayer& player) const
	{
		return this->x > player.x + player.size &&
			this->x <= player.x + player.size + player.MOVE_STEP &&
			this->y <= player.y + player.size &&
			this->y + this->size >= player.y;
	}

	// 判断元素是否被玩家通过
	bool PicoElement::through_by(const PicoPlayer& player) const
	{
		// 当玩家的中点在元素范围内时，认为玩家通过了元素
		return in_area(player.x + player.size / 2, player.y + player.size / 2);
	}

	// 判断元素是否被玩家触碰到内壁左侧
	bool PicoElement::touched_left_by(const PicoPlayer& player) const
	{
		return this->x < player.x &&
			this->x >= player.x - player.MOVE_STEP &&
			this->y + this->size >= player.y &&
			this->y <= player.y + player.size;
	}

	// 判断元素是否被玩家触碰到内壁顶部
	bool PicoElement::touched_top_by(const PicoPlayer& player) const
	{
		return this->y < player.y &&
			this->y >= player.y - player.MOVE_STEP &&
			this->x + this->size >= player.x &&
			this->x <= player.x + player.size;
	}

	// 判断元素是否被玩家触碰到内壁右侧
	bool PicoElement::touched_right_by(const PicoPlayer& player) const
	{
		return this->x + this->size > player.x + player.size &&
			this->x + this->size <= player.x + player.size + player.MOVE_STEP &&
			this->y + this->size >= player.y &&
			this->y <= player.y + player.size;
	}

	// 判断元素是否被玩家触碰到内壁底部
	bool PicoElement::touched_bottom_by(const PicoPlayer& player) const
	{
		return this->y + this->size > player.y + player.size &&
			this->y + this->size <= player.y + player.size + player.MOVE_STEP &&
			this->x <= player.x + player.size &&
			this->x + this->size >= player.x;
	}

	// 判断元素是否被玩家踩且不对齐
	bool PicoElement::unaligned_pedaled_by(const PicoPlayer& player) const
	{
		return this->pedaled_by(player) && !_aligned_x(player, 1);
	}

	// 判断元素是否被玩家顶起且不对齐
	bool PicoElement::unaligned_jumped_by(const PicoPlayer& player) const
	{
		return this->jumped_by(player) && !_aligned_x(player, 1);
	}

	// 判断元素是否被玩家向左推且不对齐
	bool PicoElement::unaligned_pushed_left_by(const PicoPlayer& player) const
	{
		return this->pushed_left_by(player) && !_aligned_y(player, 1);
	}

	// 判断元素是否被玩家向右推且不对齐
	bool PicoElement::unaligned_pushed_right_by(const PicoPlayer& player) const
	{
		return this->pushed_right_by(player) && !_aligned_y(player, 1);
	}

	// 判断元素是否被玩家触碰到内壁左侧且不对齐
	bool PicoElement::unaligned_touched_left_by(const PicoPlayer& player) const
	{
		return this->touched_left_by(player) && !_aligned_y(player, 1);
	}

	// 判断元素是否被玩家触碰到内壁顶部且不对齐
	bool PicoElement::unaligned_touched_top_by(const PicoPlayer& player) const
	{
		return this->touched_top_by(player) && !_aligned_x(player, 1);
	}

	// 判断元素是否被玩家触碰到内壁右侧且不对齐
	bool PicoElement::unaligned_touched_right_by(const PicoPlayer& player) const
	{
		return this->touched_right_by(player) && !_aligned_y(player, 1);
	}

	// 判断元素是否被玩家触碰到内壁底部且不对齐
	bool PicoElement::unaligned_touched_bottom_by(const PicoPlayer& player) const
	{	
		return this->touched_bottom_by(player) && !_aligned_x(player, 1);
	}

	// 元素被碰撞时调用
	void PicoElement::on_bump(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被踩时调用
	void PicoElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被顶起时调用
	void PicoElement::on_jump(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素向左推动时调用
	void PicoElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素向右推动时调用
	void PicoElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被玩家通过时调用
	void PicoElement::on_through(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被玩家触碰到内壁左侧时调用
	void PicoElement::on_touch_left(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被玩家触碰到内壁顶部时调用
	void PicoElement::on_touch_top(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被玩家触碰到内壁右侧时调用
	void PicoElement::on_touch_right(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被玩家触碰到内壁底部时调用
	void PicoElement::on_touch_bottom(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 判断元素是否与玩家在 x 轴对齐
	bool PicoElement::_aligned_x(const PicoPlayer& player, int offset) const
	{
		return this->x + offset <= player.x &&
			this->x + this->size - offset >= player.x + player.size;
	}

	// 判断元素是否与玩家在 y 轴对齐
	bool PicoElement::_aligned_y(const PicoPlayer& player, int offset) const
	{
		return this->y + offset <= player.y &&
			this->y + this->size - offset >= player.y + player.size;
	}

	// 元素被踩且不对齐时调用
	void PicoElement::on_unaligned_pedal(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被顶起且不对齐时调用
	void PicoElement::on_unaligned_jump(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被向左推且不对齐时调用
	void PicoElement::on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被向右推且不对齐时调用
	void PicoElement::on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被玩家触碰到内壁左侧且不对齐时调用
	void PicoElement::on_unaligned_touch_left(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被玩家触碰到内壁顶部且不对齐时调用
	void PicoElement::on_unaligned_touch_top(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被玩家触碰到内壁右侧且不对齐时调用
	void PicoElement::on_unaligned_touch_right(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 元素被玩家触碰到内壁底部且不对齐时调用
	void PicoElement::on_unaligned_touch_bottom(PicoPlayer& player, bool occurred, bool first)
	{
		return; // 子类实现
	}

	// 预计算 40x 坐标和 40y 坐标
	void PicoElement::_pre_calc_40()
	{
		if (!_pre_40x.empty() || !_pre_40y.empty()) return;
		// 预计算 40x 坐标和 40y 坐标
		for (int i = 0; i <= 40; i++)
		{
			int part = static_cast<int>(std::round(i * size / 40.0));
			_pre_40x.push_back(static_cast<int>(part));
			_pre_40y.push_back(static_cast<int>(part));
		}
	}
}