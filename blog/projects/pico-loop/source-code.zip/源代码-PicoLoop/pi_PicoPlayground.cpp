﻿#include "picoloop.h"

// 游戏广场类实现
namespace picoloop
{
	// 游戏广场类构造函数
	PicoPlayground::PicoPlayground(const PicoElementEditor& editor) :
		EDITOR(editor)
	{
		// 初始化元素数组
		PicoElement *** editor_elements = EDITOR.get_elements();
		elements = new PicoElement * *[EDITOR.GRID_ROW];
		for (int row = 0; row < EDITOR.GRID_ROW; row++)
		{
			elements[row] = new PicoElement * [EDITOR.GRID_COLUMN];
			for (int col = 0; col < EDITOR.GRID_COLUMN; col++)
			{
				elements[row][col] = editor_elements[row][col]->clone();
			}
		}
	}

	// 游戏广场类析构函数
	PicoPlayground::~PicoPlayground()
	{
		// 释放元素数组
		if (elements == nullptr) return;
		// 删除 elements***
		for (int row = 0; row < EDITOR.GRID_ROW; row++)
		{
			for (int col = 0; col < EDITOR.GRID_COLUMN; col++)
			{
				delete elements[row][col];
			}
			delete[] elements[row];
		}
		// 删除元素数组
		delete[] elements;
	}

	// 重新获取编辑器元素数据
	void PicoPlayground::reload_editor_data()
	{
		for (int row = 0; row < EDITOR.GRID_ROW; row++)
		{
			for (int col = 0; col < EDITOR.GRID_COLUMN; col++)
			{
				delete elements[row][col]; // 删除原有元素
				elements[row][col] = EDITOR.get_elements()[row][col]->clone();
			}
		}
		// 寻找玩家
		bool found = false;
		player = nullptr;
		int keys = 0; // 数据中的钥匙数量，初始为 0，即不需钥匙
		// 寻找玩家元素
		for (int row = 0; row < EDITOR.GRID_ROW; row++)
		{
			for (int col = 0; col < EDITOR.GRID_COLUMN; col++)
			{ 
				if (elements[row][col] && elements[row][col]->is_player() &&
					typeid(*elements[row][col]) == typeid(PicoPlayer))
				{
					// 使用 dynamic_cast 转换类型
					player = dynamic_cast<PicoPlayer*>(elements[row][col]);
					if (player == nullptr)
					{
						throw std::runtime_error("The player is null.");
					}
					// 设置玩家移动范围
					player->set_limit(EDITOR.X, EDITOR.Y,
						EDITOR.X + EDITOR.GRID_COLUMN * EDITOR.GRID_SIZE,
						EDITOR.Y + EDITOR.GRID_ROW * EDITOR.GRID_SIZE);
					found = true;
					break;
				}
			}
			if (found) break;
		}
		// 寻找特定元素
		for (int row = 0; row < EDITOR.GRID_ROW; row++)
		{
			for (int col = 0; col < EDITOR.GRID_COLUMN; col++)
			{
				if (!elements[row][col]) continue;
				// 寻找钥匙元素
				if (typeid(*elements[row][col]) == typeid(PicoKeyElement))
				{
					keys++;
				}
				// 寻找传送门元素
				else if (player && typeid(*elements[row][col]) ==
					typeid(PicoTeleportGateElement))
				{
					player->add_transferables(std::make_pair(
						elements[row][col]->x, elements[row][col]->y ));
				}
			}
		}
		if (!found) player = nullptr;
		else player->set_keys_required(keys);
	}

	// 绘制游戏广场
	void PicoPlayground::draw() const
	{
		BeginBatchDraw();
		// 对每一个非玩家元素进行绘制
		for (int row = 0; row < EDITOR.GRID_ROW; row++)
		{
			for (int col = 0; col < EDITOR.GRID_COLUMN; col++)
			{
				if (!elements[row][col]->is_player())
				{
					elements[row][col]->draw();
				}
			}
		}
		// 最后绘制玩家元素
		if (player) player->draw();
		EndBatchDraw();
	}

	// 擦除游戏广场
	void PicoPlayground::erase() const
	{
		// 对每一个元素进行擦除
		for (int row = 0; row < EDITOR.GRID_ROW; row++)
		{
			for (int col = 0; col < EDITOR.GRID_COLUMN; col++)
			{
				elements[row][col]->erase();
			}
		}
	}

	// 开始游戏
	void PicoPlayground::play()
	{
		if (player == nullptr)
		{
			throw std::runtime_error(
				"No player in playground."
			);
		}
		player->update_clock();
		_is_playing = true;
		_paused = false;
	}

	// 停止游戏
	void PicoPlayground::stop()
	{
		if (player == nullptr)
		{
			throw std::runtime_error(
				"No player in playground."
			);
		}
		_is_playing = false;
	}

	// 重新开始游戏
	void PicoPlayground::replay()
	{
		if (player == nullptr)
		{
			throw std::runtime_error(
				"No player in playground."
			);
		}
		BeginBatchDraw();
		// 将每一个非空元素擦除
		for (int row = 0; row < EDITOR.GRID_ROW; row++)
		{
			for (int col = 0; col < EDITOR.GRID_COLUMN; col++)
			{
				if (elements[row][col]->is_empty()) continue;
				elements[row][col]->erase();
			}
		}
		// 将每一个非空元素的坐标恢复到初始状态
		for (int row = 0; row < EDITOR.GRID_ROW; row++)
		{
			for (int col = 0; col < EDITOR.GRID_COLUMN; col++)
			{
				if (elements[row][col]->is_empty()) continue;
				int x = EDITOR.X + col * EDITOR.GRID_SIZE;
				int y = EDITOR.Y + row * EDITOR.GRID_SIZE;
				if (elements[row][col] == player)
				{
					int d = (EDITOR.GRID_SIZE - player->size) / 2;
					elements[row][col]->x = x + d;
					elements[row][col]->y = y + d;
				}
				else
				{
					elements[row][col]->x = x;
					elements[row][col]->y = y;
				}
				elements[row][col]->reset_data();
				elements[row][col]->draw();
			}
		}
		EndBatchDraw();
		resume(); // 恢复游戏
	}

	// 将元素编辑器数据转移到游戏广场上
	void PicoPlayground::transfer(PicoElementEditor& editor, 
		const PicoElementCollection::Data* data, bool clear, bool run)
	{
		if (data != nullptr)
		{
			editor.set_elements_from_data(*data, false);
		}
		reload_editor_data();
		if (clear)
		{
			editor.clear_modified();
		}
		if (run)
		{
			draw();
			play();
		}
	}

	// 游戏事件监听
	void PicoPlayground::listen_event(ExMessage& event, bool jump_if, 
		bool left_if, bool right_if, bool disable_keyborad)
	{
		// 如果没有玩家，则不进行任何操作
		if (!player) return;
		// 如果游戏没有开始，则只更新时钟
		if (_paused)
		{
			player->update_clock();
			_listen_all_elements(event);
			return;
		}
		// 对玩家元素的键盘事件进行监听
		if (!disable_keyborad)
		{
			player->listen_keyboard_and_condition(
				event, jump_if, left_if, right_if);
		}
		// 对玩家元素的条件事件进行监听
		else
		{
			player->listen_condition(
				jump_if, left_if, right_if);
		}
		// 监听所有元素
		_listen_all_elements(event);
	}

	// 对所有元素进行事件监听
	void PicoPlayground::_listen_all_elements(ExMessage& event)
	{
		// 对每一个非空非玩家元素进行监听
		for (int row = 0; row < EDITOR.GRID_ROW; row++)
		{
			for (int col = 0; col < EDITOR.GRID_COLUMN; col++)
			{
				if (!elements[row][col]->is_empty() &&
					!elements[row][col]->is_player())
				{
					// 如果游戏处于暂停状态，则只更新时钟
					if (_paused)
					{
						elements[row][col]->update_clock();
					}
					else
					{
						elements[row][col]->listen_player(*player);
					}
				}
			}
		}
	}
}