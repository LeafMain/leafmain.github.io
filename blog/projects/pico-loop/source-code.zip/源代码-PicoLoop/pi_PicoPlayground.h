﻿#pragma once

// 游戏广场类声明
namespace picoloop
{
	/**
	* @brief 游戏广场类
	*/
	class PicoPlayground
	{
	public:
		const PicoElementEditor& EDITOR;
		/**
		* @brief 游戏广场类构造函数
		* @param editor 编辑器对象
		*/
		PicoPlayground(const PicoElementEditor& editor);
		/**
		* @brief 游戏广场类析构函数
		*/
		~PicoPlayground();
		PicoPlayground(const PicoPlayground&) = delete;
		PicoPlayground& operator=(const PicoPlayground&) = delete;
		/**
		* @brief 重新获取编辑器元素数据
		*/
		void reload_editor_data();
		/**
		* @brief 绘制游戏广场
		*/
		void draw() const;
		/**
		* @brief 擦除游戏广场
		*/
		void erase() const;
		/**
		* @brief 开始游戏
		* @throw std::run_time_error 玩家对象为空
		*/
		void play();
		/**
		* @brief 停止游戏
		* @throw std::run_time_error 玩家对象为空
		*/
		void stop();
		/**
		* @brief 重新开始游戏
		* @throw std::run_time_error 玩家对象为空
		*/
		void replay();
		/**
		* @brief 暂停游戏
		*/
		void pause() { _paused = true; }
		/**
		* @brief 继续游戏
		*/
		void resume() { _paused = false; }
		/**
		* @brief 游戏事件监听
		* @param event
		* @param jump_if 满足条件时跳跃，默认为 false
		* @param left_if 满足条件时向左移动，默认为 false
		* @param right_if 满足条件时向右移动，默认为 false
		* @param disable_keyboard 是否停用键盘，默认为 false
		*/
		void listen_event(ExMessage& event, bool jump_if = false, 
			bool left_if = false, bool right_if = false, 
			bool disable_keyboard = false);
		/**
		* @brief 获取游戏广场 x 坐标
		* @return x 坐标
		*/
		[[nodiscard]] int get_x() const { return EDITOR.X; }
		/**
		* @brief 获取游戏广场 y 坐标
		* @return y 坐标
		*/
		[[nodiscard]] int get_y() const { return EDITOR.Y; }
		/**
		* @brief 获取游戏广场宽度
		* @return 宽度
		*/
		[[nodiscard]] int get_width() const { return EDITOR.get_width(); }
		/**
		* @brief 获取游戏广场高度
		* @return 高度
		*/
		[[nodiscard]] int get_height() const { return EDITOR.get_height(); }
		/**
		* @brief 判断玩家人物是否死亡
		* @return 死亡返回 true，否则返回 false
		*/
		[[nodiscard]] bool player_died() const 
		{ return player && player->has_died(); }
		/**
		* @brief 判断玩家是否胜利
		* @return 胜利返回 true，否则返回 false
		*/
		[[nodiscard]] bool player_won() const 
		{ return player && player->has_won(); }
		/**
		* @brief 获取玩家获得的钥匙数量
		* @return 钥匙数量
		*/
		[[nodiscard]] int player_keys_count() const
		{ return player ? player->keys_count() : 0; }
		/**
		* @brief 获取玩家获得的金币数量
		* @return 金币数量
		*/
		[[nodiscard]] int player_coins_count() const 
		{ return player ? player->coins_count() : 0; }
		/**
		* @brief 获取玩家 buff
		* @return 玩家 buff
		*/
		[[nodiscard]] PicoPlayer::BUFF player_buff() const { return player->get_buff(); }
		/**
		* @brief 判断游戏是否正在进行
		* @return 是否正在进行
		*/
		[[nodiscard]] bool is_playing() const { return _is_playing; }
		/**
		* @brief 判断游戏是否暂停
		* @return 是否暂停
		*/
		[[nodiscard]] bool paused() const { return _paused; }
		/*
		* @brief 将元素编辑器数据转移到游戏广场上
		* @param editor 元素编辑器
		* @param data 元素数据指针，默认为 nullptr
		* @param clear 是否清除编辑器数据，默认 false
		* @param run 是否立即运行，默认 true
		*/
		void transfer(PicoElementEditor& editor, 
			const PicoElementCollection::Data* data = nullptr, 
			bool clear = false, bool run = true);
	private:
		bool _is_playing = false; // 游戏是否正在进行
		bool _paused = false; // 游戏是否暂停
		PicoElement*** elements; // 元素指针数组
		PicoPlayer* player = nullptr; // 玩家对象
		/**
		* @brief 对所有元素进行事件监听
		*/
		void _listen_all_elements(ExMessage& event);
	};
}