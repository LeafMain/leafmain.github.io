﻿#include "picoloop.h"

// 对泥土元素类的实现
namespace picoloop
{
    // 绘制泥土元素
    void PicoSoilElement::draw() const
    {
        if (!_exist) return; // 泥土元素不存在则不绘制
        _get_bk_image();
        setfillcolor(0x6396b7);
        solidrectangle(_40x(0), _40y(0), _40x(39), _40y(39));
        for (int i = 0; i <= 38; i += 2)
        {
            for (int j = 0; j <= 38; j += 2)
            {
                if (i % 4 != j % 4) continue;
                putpixel(_40x(i + 1), _40y(j + 1), 0x225ac1);
            }
        }
        setlinecolor(0x3c7fae);
        setlinestyle(PS_DOT, 1);
        rectangle(_40x(0), _40y(0), _40x(39), _40y(39));
        setlinestyle(PS_SOLID, 1);
    }

    // 重置泥土元素数据
    void PicoSoilElement::reset_data()
    {
        base_reset(); // 调用基类的重置数据函数
        _exist = true; // 泥土元素存在
    }

    // 泥土元素被踩时触发的事件
    void PicoSoilElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist) return; // 泥土元素不存在则不处理事件
        if (occurred)
        {
            if (first)
            {
                player.disable_drop();
                player.enable_jump();
            }
        }
        else
        {
            if (first)
            {
                player.enable_drop();
                player.disable_jump();
            }
        }
    }

    // 泥土元素被顶起时触发的事件
    void PicoSoilElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist) return; // 泥土元素不存在则不处理事件
        if (occurred && first)
        {
            player.stop_shift();
            //if ()
            // 泥土元素被顶起时，被玩家消除
            _exist = false;
            erase();
            draw();
        }
    }

    // 泥土元素向左推动时触发的事件
    void PicoSoilElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist) return; // 泥土元素不存在则不处理事件
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
            }
        }
    }

    // 泥土元素向右推动时触发的事件
    void PicoSoilElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist) return; // 泥土元素不存在则不处理事件
        if (occurred)
        {
            if (first)
            {
                player.disable_move_right();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_right();
            }
        }
    }
}