﻿#include "picoloop.h"

// Pico 空元素类实现
namespace picoloop
{
	void PicoEmptyElement::draw() const
	{
		_get_bk_image();
		// 空元素不绘制任何内容
		return;
	}
}