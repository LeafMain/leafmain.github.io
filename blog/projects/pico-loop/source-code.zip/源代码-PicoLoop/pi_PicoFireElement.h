﻿#pragma once

// Pico 火元素声明
namespace picoloop
{
	/**
	* @brief Pico 火元素类
	*/
	class PicoFireElement : public PicoElement
	{
	public:
		using PicoElement::PicoElement;
		/**
		* @brief 绘制火元素
		*/
		void draw() const override;
		/**
		* @brief 绘制火元素向左摆动的动画
		*/
		void draw_left_swing() const;
		/**
		* @brief 绘制火元素向右摆动的动画
		*/
		void draw_right_swing() const;
		/**
		* @brief 更新系统时钟
		*/
		void update_clock() override;
		/**
		* @brief 更新火元素动画
		*/
		void update_animation() override;
		/**
		* @brief 重置火元素数据
		*/
		void reset_data() override;
		/**
		* @brief 克隆火元素
		* @return 克隆出的火元素对象，需要手动管理内存
		*/
		[[nodiscard]] PicoElement* clone() const override 
		{ return new PicoFireElement(*this); }
	protected:
		/**
		* @brief 玩家碰到火元素时触发的事件
		*/
		void on_bump(PicoPlayer& player, bool occurred, bool first) override;
	private:
		bool _swing_right = false; // 是否向右摆动
		std::clock_t _last_animate_time = 0; // 上次动画刷新时间
		/**
		* @brief 绘制火元素向左摆动
		*/
		void _draw_left() const;
		/**
		* @brief 绘制火元素向右摆动
		*/
		void _draw_right() const;
	};
}
	