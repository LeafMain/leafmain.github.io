﻿#include "picoloop.h"

// 关卡选择器类实现
namespace picoloop
{
	// 关卡选择器类构造函数
	LevelSelector::LevelSelector(int x, int y, int button_size, int cr, 
		int button_gap, int level_limit, COLORREF button_background_color, 
		COLORREF button_border_color, COLORREF button_text_color, 
		COLORREF button_hover_color, COLORREF button_select_color,
		COLORREF level_passed_color) :
		x(x), y(y), button_size(button_size), button_gap(button_gap),
		cr(cr), _level_limit(level_limit),
		button_background_color(button_background_color),
		button_border_color(button_border_color),
		button_text_color(button_text_color),
		button_hover_color(button_text_color),
		button_select_color(button_select_color),
		level_passed_color(level_passed_color)
	{
		// 初始化关卡按钮数组
		for (int row = 0; row < ROW; row++)
		{
			for (int col = 0; col < COLUMN; col++)
			{
				// 计算关卡编号，并创建关卡按钮
				int level = row * COLUMN + col;
				int x = this->x + col * (button_size + button_gap);
				int y = this->y + row * (button_size + button_gap);
				TCHAR level_text[5]{};
				// 转换为字符串，数值加 1
				_itot_s(level + 1, level_text, 5, 10);
				levels[row][col] = LevelButton(x, y, button_size, button_size,
					cr, cr, 46, 2, PS_SOLID, level_text, _T("Arial Rounded MT Bold"),
					button_background_color, button_border_color, button_text_color,
					button_background_color, button_hover_color, button_text_color,
					button_select_color, button_border_color, button_text_color);
			}
		}
	}

	// 绘制关卡选择器
	void LevelSelector::draw() const
	{
		BeginBatchDraw();
		for (int i = 0; i < LEVEL_COUNT; i++)
		{
			if (i >= _level_limit) break;
			int row = i / COLUMN;
			int col = i % COLUMN;
			levels[row][col].draw();
		}
		EndBatchDraw();
	}

	// 判断是否选中了某个关卡
	bool LevelSelector::selected(int level, ExMessage& event) const
	{
		// 如果关卡超出范围，则返回false
		if (level < 1 || level > _level_limit)
		{
			return false;
		}
		int row = (level - 1) / COLUMN;
		int col = (level - 1) % COLUMN;
		// 如果关卡行列超出范围，则返回false
		if (row < 0 || row >= ROW || col < 0 || col >= COLUMN)
		{
			return false;
		}
		return levels[row][col].clicked(event);
	}

	// 设置某个关卡是否通过
	void LevelSelector::set_passed(int level, bool passed, bool redraw)
	{
		// 如果关卡超出范围，则不操作
		if (level < 1 || level > _level_limit)
		{
			return;
		}
		int row = (level - 1) / COLUMN;
		int col = (level - 1) % COLUMN;
		// 通过则设置通过颜色，否则设置默认颜色
		if (passed)
		{
			levels[row][col].text_color = level_passed_color;
			levels[row][col].hover_text_color = level_passed_color;
		}
		else
		{
			levels[row][col].text_color = button_text_color;
			levels[row][col].hover_text_color = button_text_color;
		}
		if (redraw)
		{
			// 设置文字颜色后，需要重新绘制按钮
			levels[row][col].draw();
		}		
	}

	// 监听鼠标悬停事件
	void LevelSelector::listen_hover(ExMessage& event)
	{
		// 遍历所有关卡按钮，监听鼠标悬停事件
		for (int i = 0; i < LEVEL_COUNT; i++)
		{
			if (i >= _level_limit) break;
			int row = i / COLUMN;
			int col = i % COLUMN;
			levels[row][col].listen_hover(event);
		}
	}

	// 监听鼠标选中事件
	void LevelSelector::listen_select(ExMessage& event)
	{
		// 遍历所有关卡按钮，监听鼠标选中事件
		for (int i = 0; i < LEVEL_COUNT; i++)
		{
			if (i >= _level_limit) break;
			int row = i / COLUMN;
			int col = i % COLUMN;
			levels[row][col].listen_active(event);
		}
	}
}