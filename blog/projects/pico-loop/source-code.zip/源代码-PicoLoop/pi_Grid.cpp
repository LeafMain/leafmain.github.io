﻿#include "picoloop.h"

// 网格类实现
namespace picoloop
{
	// 绘制网格线
	void Grid::draw() const
	{
		BeginBatchDraw();
		setlinecolor(line_color);
		setlinestyle(line_type, line_width);
		for (int row = 0; row < ROW; row++)
		{
			for (int col = 0; col < COLUMN; col++)
			{
				rectangle(X + col * SIZE, Y + row * SIZE,
					X + (col + 1) * SIZE, Y + (row + 1) * SIZE);
			}
		}
		EndBatchDraw();
	}

	// 补充网格线
	void Grid::supple_grid(int row, int column) const
	{
		_draw_rect(row, column, line_color);
	}

	// 设置鼠标悬停的行列
	void Grid::set_hover(int row, int column, bool over)
	{
		// 行列超出范围时不做任何操作
		if (!in_range(row, column))
		{
			return;
		}
		// 不重叠时，如果已经选中了一样的，则不操作
		if (!over && _hover_row == row && _hover_column == column)
		{
			return;
		}
		// 先清除之前悬停效果
		if (has_hover())
		{
			_draw_rect(_hover_row, _hover_column, line_color);
		}
		_hover_row = row;
		_hover_column = column;
		_draw_rect(row, column, hover_color);
	}

	// 设置鼠标按下时的行列
	void Grid::set_active(int row, int column, bool over)
	{
		// 行列超出范围时不做任何操作
		if (!in_range(row, column))
		{
			return;
		}
		// 不重叠时，如果已经选中了一样的，则不操作
		if (!over && _active_row == row && _active_column == column)
		{
			return;
		}
		// 先清除之前选中效果
		if (has_active())
		{
			_draw_rect(_active_row, _active_column, line_color);
		}
		_active_row = row;
		_active_column = column;
		_draw_rect(row, column, active_color);
	}

	// 移除悬停状态
	void Grid::remove_hover()
	{
		if (has_hover())
		{
			_draw_rect(_hover_row, _hover_column, line_color);
			_hover_row = -1;
			_hover_column = -1;
		}
	}

	// 移除激活状态
	void Grid::remove_active()
	{
		if (has_active())
		{
			_draw_rect(_active_row, _active_column, line_color);
			_active_row = -1;
			_active_column = -1;
		}
	}

	// 绘制网格矩形辅助函数
	void Grid::_draw_rect(int row, int column, COLORREF line_color) const
	{
		setlinecolor(line_color);
		setlinestyle(line_type, line_width);
		rectangle(X + column * SIZE, Y + row * SIZE,
			X + (column + 1) * SIZE, Y + (row + 1) * SIZE);
	}

	// 判断活动格是否与指定行列相邻
	bool Grid::active_adjacent(int row, int column) const
	{
		return row == _active_row && std::abs(column - 
			_active_column) == 1 || column == _active_column && 
			std::abs(row - _active_row) == 1;
	}

	// 监听鼠标悬停事件
	void Grid::listen_hover(ExMessage& event)
	{
		int row = to_row(event.y);
		int col = to_column(event.x);
		// 鼠标悬停在网格外时清除悬停效果
		if (!in_range(row, col))
		{
			if (has_hover())
			{
				if (!_activated(_hover_row, _hover_column))
				{
					_draw_rect(_hover_row, _hover_column, line_color);
				}
			}
		}
		// 鼠标悬停在网格内时绘制悬停效果
		else if (_hover_row != row || _hover_column != col)
		{
			// 如果之前有悬停效果，先清除
			if (has_hover())
			{
				if (!_activated(_hover_row, _hover_column))
				{
					_draw_rect(_hover_row, _hover_column, line_color);
				}
			}
			// 绘制悬停效果
			if (!_activated(row, col))
			{
				_draw_rect(row, col, hover_color);
			}
			_hover_row = row;
			_hover_column = col;
		}
	}

	// 监听网格选中事件
	void Grid::listen_active(ExMessage& event)
	{
		if (event.message == WM_LBUTTONDOWN)
		{
			int row = to_row(event.y);
			int col = to_column(event.x);
			// 不在范围内不选中
			if (!in_range(row, col))
			{
				return;
			}
			// 如果已经选中了一样的，则不操作
			if (_active_row == row && _active_column == col)
			{
				return;
			}
			// 点击网格时清除之前选中效果
			if (has_active())
			{
				_draw_rect(_active_row, _active_column, line_color);
			}
			// 绘制选中效果
			_draw_rect(row, col, active_color);
			_active_row = row;
			_active_column = col;
		}
	}
}