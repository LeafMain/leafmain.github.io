﻿#include "picoloop.h"

// 对水元素类的实现
namespace picoloop
{
    const int PicoWaterElement::GRAVITY = PicoPlayer::NORMAL_GRAVITY / 4; // 水中的重力加速度
    const int PicoWaterElement::MOVE_SPEED = PicoPlayer::NORMAL_MOVE_SPEED / 2; // 水中的移动速度
    const int PicoWaterElement::JUMP_SPEED = PicoPlayer::NORMAL_JUMP_SPEED / 4; // 水中的跳跃速度

    // 绘制水元素
    void PicoWaterElement::draw() const
    {
        _get_bk_image();
        setfillcolor(0x973833);
        solidrectangle(_40x(0), _40y(0), _40x(39), _40y(39));
        for (int t = 0; t <= 3; t += 3)
        {
            setfillcolor(0xff7755);
            for (int i = 0; i < 40; i += 4)
            {
                solidcircle(_40x(i + 2), _40y(2 + t), _40x(2) - _40x(0));
            }
            setfillcolor(0x973833);
            solidrectangle(_40x(0), _40y(2 + t), _40x(39), _40y(5 + t));
        }
    }

    // 水元素被碰到时触发的事件
    void PicoWaterElement::on_bump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                // 限制玩家的水平速度
                player.limit_speed_x(MOVE_SPEED);
                // 限制玩家的垂直速度
                player.limit_speed_y(JUMP_SPEED);
                // 启用水元素的重力加速度、移动速度、跳跃速度
                player.use_gravity(GRAVITY);
                player.use_move_speed(MOVE_SPEED);
                player.use_jump_speed(JUMP_SPEED);
                // 允许玩家跳跃
                player.enable_jump();
            }
        }
        else
        {
            if (first)
            {
                player.recover_gravity(); // 恢复玩家的重力加速度
                player.recover_move_speed(); // 恢复玩家的移动速度
                player.recover_jump_speed(); // 恢复玩家的跳跃速度
                player.disable_jump(); // 禁止玩家跳跃
            }
        }
    }
}