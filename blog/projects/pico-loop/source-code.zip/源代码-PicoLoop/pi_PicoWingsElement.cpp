﻿#include "picoloop.h"

// Pico 翅膀类实现
namespace picoloop
{
    const int PicoWingsElement::ROTATE_PART = 9; // 翅膀元素旋转份数
    const double PicoWingsElement::ROTATE_ANGLE = PI / 4; // 旋转角度
    const double PicoWingsElement::ANIMATION_CYCLE = 0.5; // 动画周期

    // Pico 翅膀类构造函数
    PicoWingsElement::PicoWingsElement(int x, int y, int size) :
        PicoElement(x, y, size)
    {
        if (!_pre_calculated)
        {
            _pre_calculate();
            _pre_calculated = true;
        }
    }

    // 绘制翅膀元素
    void PicoWingsElement::draw() const
    {
        draw_rotated(_rotate_part);
    }

    // 绘制旋转翅膀元素
    void PicoWingsElement::draw_rotated(int rotate_part) const
    {
        // 不存在时不绘制
        if (!_exist) return;
        _get_bk_image();
        _draw_rotated(rotate_part);
    }

    // 绘制旋转翅膀元素
    void PicoWingsElement::_draw_rotated(int rotate_part) const
    {
        // 绘制翅膀
        setlinecolor(0xffb660);
        setlinestyle(PS_SOLID, 1);
        setfillcolor(0xffeeee);
        int rx = _rotate_rx.at(rotate_part);
        int cx = 14;
        int gap = 13;
        for (int i = 5; i <= 25; i += 10)
        {
            solidellipse(_40x(cx - rx), _40y(i), _40x(cx + rx), _40y(i + 10));
            solidellipse(_40x(cx - rx + gap), _40y(i), _40x(cx + rx + gap), _40y(i + 10));
            ellipse(_40x(cx - rx), _40y(i), _40x(cx + rx), _40y(i + 10));
            ellipse(_40x(cx - rx + gap), _40y(i), _40x(cx + rx + gap), _40y(i + 10));
        }
        setfillcolor(0xffb660);
        fillellipse(_40x(15), _40y(1), _40x(25), _40y(39));
    }

    // 更新系统时钟
    void PicoWingsElement::update_clock()
    {
        clock_now = std::clock();
        _last_clock = clock_now;
    }

    // 更新翅膀元素动画
    void PicoWingsElement::update_animation()
    {
        clock_now = std::clock();
        if (!_exist) return;
        double elapsed = double(clock_now - _last_clock) / CLOCKS_PER_SEC;
        if (elapsed >= ANIMATION_CYCLE / (ROTATE_PART * 2))
        {
            _rotate_part = (_rotate_part + 1) % (ROTATE_PART * 2);
            erase(); // 擦除之前的图像
            _draw_rotated(_rotate_part);
            FlushBatchDraw(); // 刷新缓存区，防止闪烁
            _last_clock = clock_now;
        }
    }

    // 重置翅膀元素数据
    void PicoWingsElement::reset_data()
    {
        base_reset(); // 调用基类的重置方法
        _exist = true;
        _rotate_part = 0;
        update_clock();
    }

    // 玩家碰到翅膀时触发的事件
    void PicoWingsElement::on_bump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred && first)
        {
            if (first)
            {
                if (!_exist) return;
                // 玩家获得翅膀，获得飞行 buff
                player.set_buff(PicoPlayer::BUFF::FLY);
                // 销毁翅膀元素
                this->erase();
                _exist = false;
            }
        }
        else
        {
            if (DISABLE_ANIMATION) return;
            update_animation();
        }
    }

    // 预计算翅膀元素数据
    void PicoWingsElement::_pre_calculate()
    {
        if (_pre_calculated) return;
        int r = 11;
        double part = ROTATE_ANGLE / ROTATE_PART;
        for (int i = 0; i < ROTATE_PART; i++)
        {
            _rotate_rx.push_back(static_cast<int>(r * std::cos(i * part)));
        }
        // 逆序添加元素
        for (int i = ROTATE_PART; i > 0; i--)
        {
            _rotate_rx.push_back(static_cast<int>(r * std::cos(i * part)));
        }
    }
}