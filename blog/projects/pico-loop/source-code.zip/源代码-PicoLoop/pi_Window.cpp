﻿#include "picoloop.h"

// 窗口类实现
namespace picoloop
{
	const int Window::WIDTH = 1200; // 窗口宽度
	const int Window::HEIGHT = 800; // 窗口高度

	// 打开窗口
	void Window::open()
	{
		if (_opened) return; // 如果窗口已经打开，则直接返回
		initgraph(WIDTH, HEIGHT, EX_NOCLOSE);
		SetWindowText(GetHWnd(), _T("PicoLoop"));
		setbkcolor(BLACK); // 设置背景色为黑色
		cleardevice(); // 清除窗口内容
		_opened = true;
	}

	// 关闭窗口
	void Window::close()
	{
		if (!_opened) return; // 如果窗口已经关闭，则直接返回
		closegraph();
		_opened = false;
	}

	// 窗口是否打开
	bool Window::opened() const
	{
		return _opened;
	}
}