﻿#include "picoloop.h"

// Pico 钥匙类实现
namespace picoloop
{
    // 绘制钥匙元素
    void PicoKeyElement::draw() const
    {
        // 不存在时不绘制
        if (!_exist) return;
        _get_bk_image();
        // 绘制钥匙头
        setlinecolor(0x00d7ee);
        setlinestyle(PS_SOLID, 1);
        setfillcolor(0x00d7ff);
        fillellipse(_40x(3), _40y(1), _40x(37), _40y(19));
        setfillcolor(0x111111);
        fillellipse(_40x(12), _40y(6), _40x(28), _40y(16));
        setfillcolor(0x00d7ff);
        // 绘制钥匙把手
        POINT hand_points[12] = {
            _40x(15), _40y(17), _40x(25), _40y(17), _40x(25), _40y(22), 
            _40x(30), _40y(22), _40x(30), _40y(27), _40x(25), _40y(27), 
            _40x(25), _40y(32), _40x(30), _40y(32), _40x(30), _40y(37), 
            _40x(25), _40y(37), _40x(25), _40y(39), _40x(15), _40y(39)
        };
        fillpolygon(hand_points, 12);
    }

    // 重置钥匙元素数据
    void PicoKeyElement::reset_data()
    {
        base_reset(); // 调用基类的重置方法
        _exist = true;
    }

    // 玩家碰到钥匙时触发的事件
    void PicoKeyElement::on_bump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred && first)
        {
            if (_exist)
            {
                // 玩家获得钥匙
                player.find_a_key();
                // 销毁钥匙元素
                this->erase();
                _exist = false;
                //player.draw();
            }
        }
    }
}