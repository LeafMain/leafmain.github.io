﻿#include "picoloop.h"

// 对管道元素类的实现
namespace picoloop
{
    const COLORREF _PicoTubeElement::BACKGROUND_COLOR = 0x222222; // 背景色
    const COLORREF _PicoTubeElement::RECTANGLE_COLOR = 0x8c8c8c; // 矩形色
    const int _PicoTubeElement::RECTANGLE_WIDTH = 2; // 矩形宽度

    // 绘制管道元素的背景
    void _PicoTubeElement::draw_background() const
    {
        setfillcolor(BACKGROUND_COLOR);
        solidrectangle(_40x(0), _40y(0), _40x(39), _40y(39));
    }

    // 绘制管道元素左上角的矩形
    void _PicoTubeElement::draw_up_left_rect() const
    {
        setfillcolor(RECTANGLE_COLOR);
        solidrectangle(_40x(0), _40y(0), _40x(RECTANGLE_WIDTH),
            _40y(RECTANGLE_WIDTH));
    }

    // 绘制管道元素右上角的矩形
    void _PicoTubeElement::draw_up_right_rect() const
    {
        setfillcolor(RECTANGLE_COLOR);
        solidrectangle(_40x(39 - RECTANGLE_WIDTH), _40y(0), 
            _40x(39), _40y(RECTANGLE_WIDTH));
    }

    // 绘制管道元素左下角的矩形
    void _PicoTubeElement::draw_down_left_rect() const
    {
        setfillcolor(RECTANGLE_COLOR);
        solidrectangle(_40x(0), _40y(39 - RECTANGLE_WIDTH),
            _40x(RECTANGLE_WIDTH), _40y(39));
    }

    // 绘制管道元素右下角的矩形
    void _PicoTubeElement::draw_down_right_rect() const
    {
        setfillcolor(RECTANGLE_COLOR);
        solidrectangle(_40x(39 - RECTANGLE_WIDTH), _40y(39 - RECTANGLE_WIDTH),
            _40x(39), _40y(39));
    }

    // 绘制管道元素上部的矩形
    void _PicoTubeElement::draw_up_rect() const
    {
        setfillcolor(RECTANGLE_COLOR);
        solidrectangle(_40x(0), _40y(0), _40x(39),
            _40y(RECTANGLE_WIDTH));
    }

    // 绘制管道元素下部的矩形
    void _PicoTubeElement::draw_down_rect() const
    {
        setfillcolor(RECTANGLE_COLOR);
        solidrectangle(_40x(0), _40y(39 - RECTANGLE_WIDTH),
            _40x(39), _40y(39));
    }

    // 绘制管道元素左侧的矩形
    void _PicoTubeElement::draw_left_rect() const
    {
        setfillcolor(RECTANGLE_COLOR);
        solidrectangle(_40x(0), _40y(0), _40x(RECTANGLE_WIDTH),
            _40y(39));
    }

    // 绘制管道元素右侧的矩形
    void _PicoTubeElement::draw_right_rect() const
    {
        setfillcolor(RECTANGLE_COLOR);
        solidrectangle(_40x(39 - RECTANGLE_WIDTH), _40y(0),
            _40x(39), _40y(39));
    }

    // 处理踩事件
    void _PicoTubeElement::handle_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_drop();
                player.enable_jump();
            }
        }
        else
        {
            if (first)
            {
                player.enable_drop();
                player.disable_jump();
            }
        }
    }

    // 处理顶起事件
    void _PicoTubeElement::handle_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.stop_shift();
            }
        }
    }

    // 处理向左推动事件
    void _PicoTubeElement::handle_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
            }
        }
    }

    // 处理向右推动事件
    void _PicoTubeElement::handle_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_right();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_right();
            }
        }
    }
}

// 对左上角管道元素类的实现
namespace picoloop
{
    // 绘制左上角管道元素
    void PicoUpRightTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_up_rect();
        draw_left_rect();
        draw_down_right_rect();
    }

    // 左上角管道元素被踩时触发的事件
    void PicoUpRightTubeElement::on_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 左上角管道元素被顶起且未对齐时触发的事件
    void PicoUpRightTubeElement::on_unaligned_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 左上角管道元素向左推动且未对齐时触发的事件
    void PicoUpRightTubeElement::on_unaligned_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 左上角管道元素向右推动时触发的事件
    void PicoUpRightTubeElement::on_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 左上角管道元素左侧内壁被触碰时触发的事件
    void PicoUpRightTubeElement::on_touch_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 左上角管道元素顶部内壁被触碰时触发的事件
    void PicoUpRightTubeElement::on_touch_top(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }
}

// 对无向上管道元素类的实现
namespace picoloop
{
    // 绘制无向上管道元素
    void PicoNoUpTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_up_rect();
        draw_down_left_rect();
        draw_down_right_rect();
    }

    // 无向上管道元素被踩时触发的事件
    void PicoNoUpTubeElement::on_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 无向上管道元素被顶起且未对齐时时触发的事件
    void PicoNoUpTubeElement::on_unaligned_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 无向上管道元素向左推动且未对齐时触发的事件
    void PicoNoUpTubeElement::on_unaligned_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 无向上管道元素向右推动且未对齐时触发的事件
    void PicoNoUpTubeElement::on_unaligned_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 无向上管道元素左侧内壁被触碰且未对齐时触发的事件
    void PicoNoUpTubeElement::on_unaligned_touch_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 无向上管道元素顶部内壁被触碰时触发的事件
    void PicoNoUpTubeElement::on_touch_top(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }
}

// 对右上角管道元素类的实现
namespace picoloop
{
    // 绘制右上角管道元素
    void PicoUpLeftTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_up_rect();
        draw_right_rect();
        draw_down_left_rect();
    }

    // 右上角管道元素被踩时触发的事件
    void PicoUpLeftTubeElement::on_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 右上角管道元素被顶起且未对齐时触发的事件
    void PicoUpLeftTubeElement::on_unaligned_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 右上角管道元素向左推动时触发的事件
    void PicoUpLeftTubeElement::on_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 右上角管道元素向右推动且未对齐时触发的事件
    void PicoUpLeftTubeElement::on_unaligned_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 右上角管道元素顶部内壁被触碰时触发的事件
    void PicoUpLeftTubeElement::on_touch_top(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 右上角管道元素右侧内壁被触碰时触发的事件
    void PicoUpLeftTubeElement::on_touch_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }
}

// 对无向左管道元素类的实现
namespace picoloop
{
    // 绘制无向左管道元素
    void PicoNoLeftTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_left_rect();
        draw_up_right_rect();
        draw_down_right_rect();
    }

    // 无向左管道元素被踩且未对齐时触发的事件
    void PicoNoLeftTubeElement::on_unaligned_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 无向左管道元素被顶起且未对齐时触发的事件
    void PicoNoLeftTubeElement::on_unaligned_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 无向左管道元素向左推动且未对齐时触发的事件
    void PicoNoLeftTubeElement::on_unaligned_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 无向左管道元素向右推动时触发的事件
    void PicoNoLeftTubeElement::on_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 无向左管道元素左侧内壁被触碰时触发的事件
    void PicoNoLeftTubeElement::on_touch_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }
}

// 对十字管道元素类的实现
namespace picoloop
{
    // 绘制十字管道元素
    void PicoIntersectTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_up_left_rect();
        draw_up_right_rect();
        draw_down_left_rect();
        draw_down_right_rect();
    }

    // 十字管道元素被踩且未对齐时触发的事件
    void PicoIntersectTubeElement::on_unaligned_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 十字管道元素被顶起且未对齐时触发的事件
    void PicoIntersectTubeElement::on_unaligned_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 十字管道元素向左推动且未对齐时触发的事件
    void PicoIntersectTubeElement::on_unaligned_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 十字管道元素向右推动且未对齐时触发的事件
    void PicoIntersectTubeElement::on_unaligned_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }
}

// 对无向右管道元素类的实现
namespace picoloop
{
    // 绘制无向右管道元素
    void PicoNoRightTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_right_rect();
        draw_up_left_rect();
        draw_down_left_rect();
    }

    // 无向右管道元素被踩且未对齐时触发的事件
    void PicoNoRightTubeElement::on_unaligned_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 无向右管道元素被顶起且未对齐时触发的事件
    void PicoNoRightTubeElement::on_unaligned_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 无向右管道元素向左推动时触发的事件
    void PicoNoRightTubeElement::on_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 无向右管道元素向右推动且未对齐时触发的事件
    void PicoNoRightTubeElement::on_unaligned_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 无向右管道元素右侧内壁被触碰时触发的事件
    void PicoNoRightTubeElement::on_touch_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }
}

// 对左下角管道元素类的实现
namespace picoloop
{
    // 绘制左下角管道元素
    void PicoDownRightTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_left_rect();
        draw_down_rect();
        draw_up_right_rect();
    }

    // 左下角管道元素被踩且未对齐时触发的事件
    void PicoDownRightTubeElement::on_unaligned_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 左下角管道元素被顶起时触发的事件
    void PicoDownRightTubeElement::on_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 左下角管道元素向左推动且未对齐时触发的事件
    void PicoDownRightTubeElement::on_unaligned_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 左下角管道元素向右推动时触发的事件
    void PicoDownRightTubeElement::on_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 左下角管道元素左侧内壁被触碰时触发的事件
    void PicoDownRightTubeElement::on_touch_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 左下角管道元素底部内壁被触碰时触发的事件
    void PicoDownRightTubeElement::on_touch_bottom(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }
}

// 对无向下管道元素类的实现
namespace picoloop
{
    // 绘制无向下管道元素
    void PicoNoDownTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_down_rect();
        draw_up_left_rect();
        draw_up_right_rect();
    }

    // 无向下管道元素被踩且未对齐时触发的事件
    void PicoNoDownTubeElement::on_unaligned_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 无向下管道元素被顶起时触发的事件
    void PicoNoDownTubeElement::on_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 无向下管道元素向左推动且未对齐时触发的事件
    void PicoNoDownTubeElement::on_unaligned_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 无向下管道元素向右推动且未对齐时触发的事件
    void PicoNoDownTubeElement::on_unaligned_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 无向下管道元素底部内壁被触碰时触发的事件
    void PicoNoDownTubeElement::on_touch_bottom(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }
}

// 对右下角管道元素类的实现
namespace picoloop
{
    // 绘制右下角管道元素
    void PicoDownLeftTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_right_rect();
        draw_down_rect();
        draw_up_left_rect();
    }

    // 右下角管道元素被踩且未对齐时触发的事件
    void PicoDownLeftTubeElement::on_unaligned_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 右下角管道元素被顶起时触发的事件
    void PicoDownLeftTubeElement::on_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 右下角管道元素向左推动时触发的事件
    void PicoDownLeftTubeElement::on_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 右下角管道元素向右推动且未对齐时触发的事件
    void PicoDownLeftTubeElement::on_unaligned_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 右下角管道元素右侧内壁被触碰时触发的事件
    void PicoDownLeftTubeElement::on_touch_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 右下角管道元素底部内壁被触碰时触发的事件
    void PicoDownLeftTubeElement::on_touch_bottom(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }
}

// 对水平管道元素类的实现
namespace picoloop
{
    // 绘制水平管道元素
    void PicoHorizontalTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_up_rect();
        draw_down_rect();
    }

    // 水平管道元素被踩时触发的事件
    void PicoHorizontalTubeElement::on_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 水平管道元素被顶起时触发的事件
    void PicoHorizontalTubeElement::on_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 水平管道元素顶部内壁被触碰时触发的事件
    void PicoHorizontalTubeElement::on_touch_top(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }

    // 水平管道元素底部内壁被触碰时触发的事件
    void PicoHorizontalTubeElement::on_touch_bottom(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 水平管道元素向左推动且未对齐时触发的事件
    void PicoHorizontalTubeElement::on_unaligned_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 水平管道元素向右推动且未对齐时触发的事件
    void PicoHorizontalTubeElement::on_unaligned_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }
}

// 对垂直管道元素类的实现
namespace picoloop
{
    // 绘制垂直管道元素
    void PicoVerticalTubeElement::draw() const
    {
        _get_bk_image();
        draw_background();
        draw_left_rect();
        draw_right_rect();
    }

    // 垂直管道元素向左推动且未对齐时触发的事件
    void PicoVerticalTubeElement::on_push_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 垂直管道元素向右推动且未对齐时触发的事件
    void PicoVerticalTubeElement::on_push_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 垂直管道元素左侧内壁被触碰时触发的事件
    void PicoVerticalTubeElement::on_touch_left(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_left(player, occurred, first);
    }

    // 垂直管道元素右侧内壁被触碰时触发的事件
    void PicoVerticalTubeElement::on_touch_right(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_push_right(player, occurred, first);
    }

    // 垂直管道元素被踩且未对齐时触发的事件
    void PicoVerticalTubeElement::on_unaligned_pedal(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_pedal(player, occurred, first);
    }

    // 垂直管道元素被顶起且未对齐时触发的事件
    void PicoVerticalTubeElement::on_unaligned_jump(
        PicoPlayer& player, bool occurred, bool first)
    {
        handle_jump(player, occurred, first);
    }
}