﻿#pragma once

// 对向左传送带元素类的声明
namespace picoloop
{
    /**
     * @brief 向左传送带元素类
     */
    class PicoLeftConveyorElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制向左传送带元素
        */
        void draw() const override;
        /**
         * @brief 克隆向左传送带元素
         * @return 克隆出的 PicoLeftConveyorElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoLeftConveyorElement(*this); }
    protected:
        /**
        * @brief 向左传送带元素被踩时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向左传送带元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向左传送带元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向左传送带元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
     * @brief 向右传送带元素类
     */
    class PicoRightConveyorElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制向右传送带元素
        */
        void draw() const override;
        /**
         * @brief 克隆向右传送带元素
         * @return 克隆出的 PicoRightConveyorElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoRightConveyorElement(*this); }
    protected:
        /**
        * @brief 向右传送带元素被踩时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向右传送带元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向右传送带元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向右传送带元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
    };
}