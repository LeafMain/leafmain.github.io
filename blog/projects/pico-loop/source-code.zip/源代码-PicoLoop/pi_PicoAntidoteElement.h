﻿#pragma once

// Pico 解药类声明
namespace picoloop
{
    /**
    * @brief Pico 解药类
    */
    class PicoAntidoteElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制解药元素
        */
        void draw() const override;
        /**
        * @brief 克隆解药元素
        * @return 克隆的解药元素指针，需要手动管理内存
        */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoAntidoteElement(*this); }
        /**
        * @brief 重置解药元素数据
        */
        void reset_data() override;
        /**
        * @brief 解药是否存在
        * @return 解药是否存在，存在 true，不存在 false
        */
        [[nodiscard]] bool exist() const { return _exist; }
    protected:
        /**
        * @brief 玩家碰到解药时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生了按下事件
        * @param first 是否是第一次按下
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
    private:
        bool _exist = true; // 解药是否存在
    };
}