﻿#include "picoloop.h"

// Pico 金币类实现
namespace picoloop
{
    const int PicoCoinElement::ROTATE_SPEED = 40; // 金币旋转速度
    const int PicoCoinElement::OFFSET = 2; // 金币椭圆偏移量
    const double PicoCoinElement::ANIMATION_CYCLE = 1.0; // 动画周期

    // Pico 金币类构造函数
    PicoCoinElement::PicoCoinElement(int x, int y, int size) 
        : PicoElement(x, y, size)
    {
        if (!_pre_calculated)
        {
            _pre_calculate();
            _pre_calculated = true;
        }
    }

    // 绘制金币元素
    void PicoCoinElement::draw() const
    {
        // 根据锁定状态绘制
        if (!_locked)
        {
            draw_normal();
        }
        else
        {
            draw_locked();
        }
    }

    // 绘制普通金币元素
    void PicoCoinElement::draw_normal() const
    {
        // 不存在时不绘制
        if (!_exist) return;
        draw_rotated(_rotate_part);
    }

    // 绘制锁定金币元素
    void PicoCoinElement::draw_locked() const
    {
        if (!_exist) return;
        _get_bk_image();
        setlinecolor(0x666666);
        setlinestyle(PS_SOLID, 1);
        setfillcolor(0x444444);
        fillrectangle(_40x(0), _40y(0), _40x(40), _40y(40));
        setlinecolor(0x444444);
        setfillcolor(0x666666);
        fillcircle(x + size / 2, y + size / 2, size / 2 - OFFSET);
        setfillcolor(0x333333);
        solidrectangle(x + size * 3 / 8, y + size * 3 / 8, 
            x + size * 5 / 8, y + size * 5 / 8);
    }

    // 绘制旋转的金币元素
    void PicoCoinElement::draw_rotated(int rotate_part) const
    {
       _get_bk_image();
       _draw_rotated(rotate_part);
    }

    // 绘制旋转的金币元素
    void PicoCoinElement::_draw_rotated(int rotate_part) const
    {
        setlinecolor(0x00d7ff);
        setlinestyle(PS_SOLID, 1);
        setfillcolor(0x55ddff);
        // 绘制金币椭圆
        int cx = x + (size >> 1);
        int cy = y + (size >> 1);
        int rx = _rotate_rx.at(rotate_part);
        int ry = (size >> 1) - OFFSET;
        fillellipse(cx - rx, y + OFFSET, cx + rx, y + size - OFFSET);
        // 绘制金币内部矩形
        setfillcolor(0x111111);
        fillrectangle(cx - rx / 3, cy - ry / 3, cx + rx / 3, cy + ry / 3);
    }

    // 更新系统时钟
    void PicoCoinElement::update_clock()
    {
        clock_now = std::clock();
        _last_rotate_time = clock_now;
    }

    // 重置金币元素数据
    void PicoCoinElement::reset_data()
    {
        base_reset(); // 调用基类的重置方法
        update_clock();
        _rotate_part = 0;
        _exist = true;
        _locked = false;
        _drop_disabled = false; // 掉落是否禁用
        _move_left_disabled = false; // 向左移动是否禁用
        _move_right_disabled = false; // 向右移动是否禁用
    }

    // 更新金币旋转动画
    void PicoCoinElement::update_animation()
    {
        clock_now = std::clock();
        double elapsed = double(clock_now - _last_rotate_time) / CLOCKS_PER_SEC;
        // 当旋转周期结束时，重置旋转角度
        if (elapsed >= ANIMATION_CYCLE / ROTATE_SPEED)
        {
            _rotate_part = (_rotate_part + 1) % ROTATE_SPEED;
            erase();
            _draw_rotated(_rotate_part);
            _last_rotate_time = clock_now;
            FlushBatchDraw();
        }
    }

    // 玩家碰到金币时触发的事件
    void PicoCoinElement::on_bump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first && _exist && !_locked)
            {
                // 玩家获得金币
                player.find_a_coin();
                // 销毁金币元素
                this->erase();
                _exist = false;
            }
        }
        else
        {
            if (_exist && !_locked)
            {
                if (DISABLE_ANIMATION) return;
                update_animation();
            }
        }
        
    }

    // 金币元素被踩时触发的事件
    void PicoCoinElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist)
        {
            return;
        }
        // 自动切换状态
        if (player.coins_locked() != _locked)
        {
            _locked = player.coins_locked();
            erase();
            draw();
        }
        if (occurred)
        {
            if (first && _locked)
            {
                player.disable_drop();
                player.enable_jump();
                _drop_disabled = true;
            }
            else if (!_locked && _drop_disabled)
            {
                player.enable_drop();
                player.disable_jump();
                _drop_disabled = false;
            }
        }
        else
        {
            if (first && _drop_disabled)
            {
                player.enable_drop();
                player.disable_jump();
                _drop_disabled = false;
            }
        }
    }

    // 金币元素被顶起时触发的事件
    void PicoCoinElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist)
        {
            return;
        }
        if (occurred)
        {
            if (first && _locked)
            {
                player.stop_shift();
            }
        }
    }

    // 金币元素向左推动时触发的事件
    void PicoCoinElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist)
        {
            return;
        }
        if (occurred)
        {
            if (first && _locked)
            {
                player.disable_move_left();
                _move_left_disabled = true;
            }
            else if (!_locked && _move_left_disabled)
            {
                player.enable_move_left();
                _move_left_disabled = false;
            }
        }
        else
        {
            if (first && _move_left_disabled)
            {
                player.enable_move_left();
                _move_left_disabled = false;
            }
        }
    }

    // 金币元素向右推动时触发的事件
    void PicoCoinElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist)
        {
            return;
        }
        if (occurred)
        {
            if (first && _locked)
            {
                player.disable_move_right();
                _move_right_disabled = true;
            }
            else if (!_locked && _move_right_disabled)
            {
                player.enable_move_right();
                _move_right_disabled = false;
            }
        }
        else
        {
            if (first && _move_right_disabled)
            {
                player.enable_move_right();
                _move_right_disabled = false;
            }
        }
    }

    // 预计算旋转坐标点
    void PicoCoinElement::_pre_calculate()
    {
        if (!_rotate_rx.empty()) return;
        double part = 2 * PI / ROTATE_SPEED; // 每份的弧度
        int r = (size >> 1) - OFFSET; // 半径
        for (int i = 0; i < ROTATE_SPEED; i++)
        {
            double angle = i * part;
            _rotate_rx.push_back(int(r * std::cos(angle)));
        }
    }
}