﻿#pragma once

// 对砖块元素类的声明
namespace picoloop
{
    /**
     * @brief 砖块元素类
     */
    class PicoBrickElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制砖块元素
        */
        void draw() const override;
        /**
         * @brief 克隆砖块元素
         * @return 克隆出的 PicoBrickElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoBrickElement(*this); }
    protected:
        /**
        * @brief 砖块元素被踩时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 砖块元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
		* @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 砖块元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
		* @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 砖块元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
		* @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
    };
}