﻿#pragma once

// Pico 超级跑鞋元素类声明
namespace picoloop
{
	/**
	* @brief Pico 超级跑鞋元素类
	*/
	class PicoSuperShoeElement : public PicoElement
	{
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制超级跑鞋元素
        */
        void draw() const override;
        /**
        * @brief 克隆超级跑鞋元素
        * @return 克隆的超级跑鞋元素指针，需要手动管理内存
        */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoSuperShoeElement(*this); }
        /**
        * @brief 重置超级跑鞋元素数据
        */
        void reset_data() override;
        /**
        * @brief 超级跑鞋是否存在
        * @return 超级跑鞋是否存在，存在 true，不存在 false
        */
        [[nodiscard]] bool exist() const { return _exist; }
    protected:
        /**
        * @brief 玩家碰到超级跑鞋时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生了按下事件
        * @param first 是否是第一次按下
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
    private:
        bool _exist = true; // 超级跑鞋是否存在

	};
}