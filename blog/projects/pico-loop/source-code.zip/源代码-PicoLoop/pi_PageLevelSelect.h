﻿#pragma once

// 选择关卡页面类声明
namespace picoloop
{
	/**
	* @brief 选择关卡页面类
	*/
	class PageLevelSelect : public Page
	{
	public:
		/**
		* @brief PageLevelSelect 构造函数
		* @param game 游戏对象引用
		*/
		explicit PageLevelSelect(Game& game);
		/**
		* @brief 监听事件
		* @param event 事件
		*/
		void listen_event(ExMessage& event) override;
	protected:
		/**
		* @brief 显示主页
		*/
		void draw_page() const override;
		/**
		* @brief 页面进入时调用
		*/
		void on_enter() override;
	private:
		struct COLOR // 颜色结构体
		{
			static const COLORREF BACKGROUND; // 背景颜色
			static const COLORREF TITLE; // 标题颜色
			static const COLORREF LEVEL_BORDER; // 关卡边框颜色
			static const COLORREF SELECTOR_BACKGROUND; // 选择器背景颜色
			static const COLORREF SELECTOR_BORDER; // 选择器边框颜色
			static const COLORREF SELECTOR_TEXT; // 选择器文字颜色
			static const COLORREF SELECTOR_HOVER; // 选择器悬停颜色
			static const COLORREF SELECTOR_SELECTED; // 选择器选中颜色
			static const COLORREF GRID_LINE; // 网格线颜色
			static const COLORREF GRID_SELECTED; // 网格选中颜色
			static const COLORREF BUTTON; // 按钮颜色
			static const COLORREF BUTTON_HOVER; // 按钮悬停颜色
			static const COLORREF LEVEL_PASSED; // 关卡通过颜色
		};
		struct FONT // 字体结构体
		{
			static const LPCTSTR TITLE_FONT; // 标题字体颜色
			static const LPCTSTR BUTTON_FONT; // 按钮字体颜色
		};
		LevelSelector level_selector; // 关卡选择器
		Grid grid; // 网格
		RectButton button_help; // 帮助按钮
		RectButton button_back; // 返回按钮
		bool _passed_levels_loaded = false; // 是否已加载通过的关卡集合
		/**
		* @brief 聚焦第一个关卡 
		*/
		void _focus_first();
		/**
		* @brief 聚焦下一个关卡 
		*/
		void _focus_next();
		/**
		* @brief 聚焦上一个关卡 
		*/
		void _focus_prev();
		/**
		* @brief 将焦点移动到下一行
		*/
		void _focus_next_line();
		/**
		* @brief 将焦点移动到上一行
		*/
		void _focus_prev_line();
		/**
		* @brief 监听选择事件
		*/
		void _listen_select(ExMessage& event);
		/**
		* @brief 进入关卡
		* @param level 关卡编号
		*/
		void _enter_playing(int level);
		/**
		* @brief 进入帮助页面
		*/
		void _enter_help();
		/**
		* @brief 加载通过的关卡集合
		*/
		void _load_passed_levels();
		/**
		* @brief 应用通过的关卡
		*/
		void _apply_passed_levels();
	};
}