﻿#pragma once

// pico 金币类声明
namespace picoloop
{
	/**
	* @brief  Pico 金币类
	*/
    class PicoCoinElement : public PicoElement
    {
    public:
        /**
        * @brief Pico 金币类构造函数
        * @param x x 坐标，默认 0
        * @param y y 坐标，默认 0
        * @param size 大小，默认 ELEMENT_INIT_SIZE
        */
        PicoCoinElement(int x = 0, int y = 0, int size = ELEMENT_INIT_SIZE);
        /**
        * @brief 绘制金币元素
        */
        void draw() const override;
        /**
        * @brief 绘制普通金币元素
        */
        void draw_normal() const;
        /**
        * @brief 绘制锁定金币元素
        */
        void draw_locked() const;
        /**
        * @brief 绘制旋转的金币元素
        * @param rotate_part 旋转部分 (0 - 19)
        */
        void draw_rotated(int rotate_part) const;
        /**
        * @brief 更新系统时钟
        */
        void update_clock() override;
        /**
        * @brief 更新金币旋转动画
        */
        void update_animation() override;
        /**
        * @brief 克隆金币元素
        * @return 克隆的金币元素指针，需要手动管理内存
        */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoCoinElement(*this); }
        /**
        * @brief 重置金币元素数据
        */
        void reset_data() override;
        /**
        * @brief 金币是否存在
        * @return 金币是否存在，存在 true，不存在 false
        */
        [[nodiscard]] bool exist() const { return _exist; }
        /**
        * @brief 金币是否被锁定
        * @return 金币是否被锁定
        */
        [[nodiscard]] bool locked() const { return _exist; }
    protected:
        /**
        * @brief 玩家碰到金币时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生了按下事件
        * @param first 是否是第一次按下
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 金币元素被踩时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 金币元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 金币元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 金币元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
    private:
        static constexpr double PI = 3.14159265358979323846;
        static const int ROTATE_SPEED; // 旋转速度
        static const int OFFSET; // 偏移量
        static const double ANIMATION_CYCLE; // 动画周期
        bool _exist = true; // 金币是否存在
        bool _locked = false; // 金币是否被锁定
        int _rotate_part = 0; // 旋转角度，单位为弧度
        std::clock_t _last_rotate_time = 0; // 上一次旋转的时间
        std::vector<int> _rotate_rx; // 旋转 x 坐标半径
        bool _pre_calculated = false; // 是否已经预计算旋转坐标点
        bool _drop_disabled = false; // 掉落是否禁用
        bool _move_left_disabled = false; // 向左移动是否禁用
        bool _move_right_disabled = false; // 向右移动是否禁用
        /**
        * @brief 绘制旋转的金币元素
        * @param rotate_part 旋转部分 (0 - 19)
        */
        void _draw_rotated(int rotate_part) const;
        /**
        * @brief 预计算旋转坐标点
        */
        void _pre_calculate();
    };
}