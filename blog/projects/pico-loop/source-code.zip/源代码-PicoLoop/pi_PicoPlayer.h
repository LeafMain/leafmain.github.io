﻿#pragma once

// Pico玩家类声明
namespace picoloop
{
	/**
	* @brief Pico玩家类
	* @note PicoPlayer 别名 PicoPlayerElement
	*/
	typedef class PicoPlayer : public PicoElement
	{
	public:
		static const int MOVE_STEP;  // 玩家移动步长
		static const int INIT_SIZE; // 玩家初始大小
		static const int MAX_DROP_SPEED; // 玩家最大掉落速度
		static const int NORMAL_MOVE_SPEED; // 玩家正常移动速度
		static const int NORMAL_JUMP_SPEED; // 玩家正常跳跃速度
		static const int NORMAL_GRAVITY; // 玩家正常重力
		enum class BUFF { NONE, SUPER, FLY, POISON }; // 玩家 buff 枚举
		/**
		* @brief PicoPlayer 构造函数
		* @param x 玩家左上角x坐标，默认为0
		* @param y 玩家左上角y坐标，默认为0
		* @param size 玩家大小，默认为INIT_SIZE
		* @param limit_left 限制区域左边界，默认为0
		* @param limit_top 限制区域上边界，默认为0
		* @param limit_right 限制区域右边界，默认为Window::WIDTH
		* @param limit_bottom 限制区域下边界，默认为Window::HEIGHT
		*/
		explicit PicoPlayer(int x = 0, int y = 0, int size = INIT_SIZE,
			int limit_left = 0, int limit_top = 0, 
			int limit_right = Window::WIDTH, 
			int limit_bottom = Window::HEIGHT) :
			PicoElement(x + size / 10, y + size / 10, size * 4 / 5), 
			limit_left(limit_left), limit_top(limit_top), 
			limit_right(limit_right), limit_bottom(limit_bottom) {}
		/**
		* @brief 设置限制区域
		* @param left 限制区域左边界
		* @param top 限制区域上边界
		* @param right 限制区域右边界
		* @param bottom 限制区域下边界
		*/
		void set_limit(int left, int top, int right, int bottom)
		{ limit_left = left; limit_top = top;
			limit_right = right; limit_bottom = bottom; };
		/**
		* @brief 获得限制区域
		* @return RECT 限制区域
		*/
		[[nodiscard]] RECT get_limit() const
		{ return { limit_left, limit_top, limit_right, limit_bottom }; }
		/**
		* @brief 绘制玩家
		*/
		void draw() const override;
		/**
		* @brief 绘制玩家，根据指定 buff 状态绘制
		* @param buff 玩家 buff 状态
		*/
		void draw(BUFF buff) const;
		/**
		* @brief 绘制玩家（无buff状态）
		*/
		void draw_buff_none() const;
		/**
		* @brief 绘制玩家（超级状态）
		*/
		void draw_buff_super() const;
		/**
		* @brief 绘制玩家（飞行状态）
		*/
		void draw_buff_fly() const;
		/**
		* @brief 绘制玩家（中毒状态）
		*/
		void draw_buff_poison() const;
		/**
		* @brief 绘制玩家（死亡状态）
		*/
		void draw_died() const;
		/**
		* @brief 设置玩家当前的 buff 状态
		* @param buff 玩家 buff 状态
		*/
		void set_buff(BUFF buff);
		/**
		* @brief 擦除玩家
		*/
		void erase() const override; 
		/**
		* @brief 监听键盘事件，不能与listen_condition同时使用
		* @param event 事件
		*/
		void listen_keyboard(ExMessage& event);
		/**
		* @brief 监听条件事件，不能与listen_keyboard同时使用
		* @param jump_if 满足条件时跳跃
		* @param left_if 满足条件时向左移动
		* @param right_if 满足条件时向右移动
		*/
		void listen_condition(bool jump_if, bool left_if, bool right_if);
		/**
		* @brief 同时监听键盘事件和条件事件
		* @param event 事件
		* @param jump_if 满足条件时跳跃
		* @param left_if 满足条件时向左移动
		* @param right_if 满足条件时向右移动
		*/
		void listen_keyboard_and_condition(ExMessage& event,
			bool jump_if, bool left_if, bool right_if);
		/**
		* @brief 更新系统时钟
		* @param clock_now 系统时钟
		*/
		void update_clock() override;
		/**
		* @brief 使玩家死亡
		*/
		void die();
		/**
		* @brief 重置玩家状态
		*/
		void reset_data() override;
		/**
		* @brief 使玩家胜利
		*/
		void win();
		/**
		* @brief 克隆玩家
		* @return PicoElement* 克隆的玩家
		*/
		[[nodiscard]] PicoElement* clone() const override;
		/**
		* @brief 判断元素是否为玩家
		* @return true 玩家元素始终为玩家
		*/
		[[nodiscard]] bool is_player() const override { return true; }
		/**
		* @brief 判断玩家是否存活
		* @return bool 是否存活
		*/
		[[nodiscard]] bool is_alive() const { return !_has_died; }
		/**
		* @brief 判断玩家是否死亡
		* @return bool 是否死亡
		*/
		[[nodiscard]] bool has_died() const { return _has_died; }
		/**
		* @brief 判断玩家是否胜利
		* @return bool 是否胜利
		*/
		[[nodiscard]] bool has_won() const { return _has_won; }
		/**
		* @brief 判断坐标是否在限制区域内
		* @param x 坐标x
		* @param y 坐标y
		* @return bool 是否在限制区域内
		*/
		[[nodiscard]] bool in_limit_area(int x, int y) const
		{ return x >= limit_left && x + size <= limit_right && 
			y >= limit_top && y + size <= limit_bottom; }
		/**
		* @brief 获得玩家当前的 buff 状态
		* @return BUFF 玩家 buff 状态
		*/
		[[nodiscard]] BUFF get_buff() const { return _buff; }
		/**
		* @brief 使玩家可以跳跃
		*/
		void enable_jump() { _jump_ability++; }
		/**
		* @brief 使玩家不能跳跃
		*/
		void disable_jump() { _jump_ability--; }
		/**
		* @brief 使玩家可以下落
		*/
		void enable_drop() { _drop_ability++; }
		/**
		* @brief 使玩家不能下落
		*/
		void disable_drop() { _drop_ability--; }
		/**
		* @brief 使玩家可以向左移动
		*/
		void enable_move_left() { _move_left_ability++; }
		/**
		* @brief 使玩家不能向左移动
		*/
		void disable_move_left() { _move_left_ability--; }
		/**
		* @brief 使玩家可以向右移动
		*/
		void enable_move_right() { _move_right_ability++; }
		/**
		* @brief 使玩家不能向右移动
		*/
		void disable_move_right() { _move_right_ability--; }
		/**
		* @brief 设置玩家速度的 x 分量
		* @param speed 速度，单位为像素/秒，负值表示向左
		*/
		void set_speed_x(int speed) { _speed_x = speed; }
		/**
		* @brief 设置玩家速度的 y 分量
		* @param speed 速度，单位为像素/秒，负值表示向上
		*/
		void set_speed_y(int speed) { _speed_y = speed; }
		/**
		* @brief 限制玩家速度的 x 分量，防止其绝对值超过参数
		* @param abs_speed 速度的绝对值，单位为像素/秒，非负
		*/
		void limit_speed_x(int abs_speed) { if (std::abs(_speed_x) > abs_speed)
			_speed_x = (_speed_x > 0 ? abs_speed : -abs_speed); }
		/**
		* @brief 限制玩家速度的 y 分量，防止其绝对值超过参数
		* @param abs_speed 速度的绝对值，单位为像素/秒，非负
		*/
		void limit_speed_y(int abs_speed) { if (std::abs(_speed_y) > abs_speed)
			_speed_y = (_speed_y > 0 ? abs_speed : -abs_speed); }
		/**
		* @brief 使玩家使用临时指定的移动速度
		* @param speed 速度，单位为像素/秒，负值表示向左
		*/
		void use_move_speed(int speed) { _max_speed_x = (std::min)
			(_max_speed_x, speed); _max_speed_x_set_count++; }
		/**
		* @brief 恢复玩家的移动速度
		*/
		void recover_move_speed() {
			if (_max_speed_x_set_count > 0 &&
				--_max_speed_x_set_count <= 0) _max_speed_x = _max_speed_x_copy;
		}
		/**
		* @brief 使玩家使用临时指定的跳跃速度
		* @param speed 速度，单位为像素/秒，负值表示向上
		*/
		void use_jump_speed(int speed) { _max_speed_y = (std::min)
			(_max_speed_y, speed); _max_speed_y_set_count++; }
		/**
		* @brief 恢复玩家的跳跃速度
		*/
		void recover_jump_speed() {
			if (_max_speed_y_set_count > 0 &&
				--_max_speed_y_set_count == 0) _max_speed_y = _max_speed_y_copy;
		}
		/**
		* @brief 使玩家使用临时指定的重力加速度
		* @param gravity 重力加速度，单位为像素/秒^2
		*/
		void use_gravity(int gravity) 
		{ _gravity = gravity; _gravity_set_count++; }
		/**
		* @brief 恢复玩家重力加速度
		*/
		void recover_gravity() {
			if (_gravity_set_count > 0 &&
				--_gravity_set_count == 0) _gravity = _gravity_copy;
		}
		/**
		* @brief 使玩家使用临时指定的被动移动速度
		* @param speed 速度，单位为像素/秒，负值表示向左
		*/
		void use_passive_move_speed(int speed)
		{ _passive_move_speed = speed; _passive_move_set_count++; }
		/**
		* @brief 恢复玩家的被动移动速度
		*/
		void recover_passive_move_speed() {
			if (_passive_move_set_count > 0 &&
				--_passive_move_set_count == 0) _passive_move_speed = 0;
		}
		/**
		* @brief 使玩家使用临时指定的固定跳跃速度
		* @param abs_speed 速度，单位为像素/秒，非负
		*/
		void use_fixed_jump_speed(int abs_speed)
		{ _fixed_jump_speed = std::abs(abs_speed); _fixed_jump_set_count++; }
		/**
		* @brief 恢复玩家的固定跳跃速度
		*/
		void recover_fixed_jump_speed() { if (_fixed_jump_set_count > 0 && 
			--_fixed_jump_set_count == 0) _fixed_jump_speed = 0; }
		/**
		* @brief 停止玩家在 x 方向上的移动
		*/
		void stop_x() { _speed_x = 0; }
		/**
		* @brief 停止玩家在 y 方向上的移动
		*/
		void stop_y() { _speed_y = 0; }
		/**
		* @brief 停止玩家上升
		*/
		void stop_shift();
		/**
		* @brief 阻止玩家控制跳跃，静止或掉落时自动恢复
		*/
		void prevent_control_jump() { _can_control_jump = false; }
		/**
		* @brief 使玩家获得一把钥匙
		*/
		void find_a_key() { _keys_count++; }
		/**
		* @brief 使玩家获得一枚金币
		*/
		void find_a_coin() { _coins_count++; }
		/**
		* @brief 设置玩家需要的钥匙数量
		* @param count 钥匙数量
		*/
		void set_keys_required(int count) { _keys_required = count; }
		/**
		* @brief 设置是否已经传送过
		* @param tr 传送过 true，未传送过 false
		*/
		void set_transferred(bool tr) { _transferred = tr; }
		/**
		* @brief 锁住场上所有金币
		*/
		void lock_all_coins() { _coins_locked = true; }
		/**
		* @brief 解锁场上所有金币
		*/
		void unlock_all_coins() { _coins_locked = false; }
		/*
		* @brief 将玩家传送至下一个传送门
		* @param now_x 当前的传送门 x 坐标
		* @param now_x 当前的传送门 y 坐标
		* @param off_x 传送偏移量 x
		* @param off_y 传送偏移量 y
		*/
		void transfer_to_next(int now_x, int now_y, int off_x, int off_y);
		/*
		* @brief 添加传送门坐标
		* @param tr 传送门坐标
		*/
		void add_transferables(std::pair<int, int> tr) { _transferables.insert(tr); }
		/**
		* @brief 判断玩家是否可以跳跃
		* @return bool 是否可以跳跃
		*/
		[[nodiscard]] bool can_jump() const { return _jump_ability > 0; }
		/**
		* @brief 判断玩家是否可以下落
		* @return bool 是否可以下落
		*/
		[[nodiscard]] bool can_drop() const { return _drop_ability > 0; }
		/**
		* @brief 判断玩家是否可以向左移动
		* @return bool 是否可以向左移动
		*/
		[[nodiscard]] bool can_move_left() const { return _move_left_ability > 0; }
		/**
		* @brief 判断玩家是否可以向右移动
		* @return bool 是否可以向右移动
		*/
		[[nodiscard]] bool can_move_right() const { return _move_right_ability > 0; }
		/**
		* @brief 判断玩家是否可以控制跳跃
		* @return bool 是否可以控制跳跃
		*/
		[[nodiscard]] bool can_control_jump() const { return _can_control_jump; }
		/**
		* @brief 判断玩家是否有被动的移动速度
		* @return bool 是否有被动的移动速度
		*/
		[[nodiscard]] bool has_passive_move_speed() const 
		{ return _passive_move_set_count > 0; }
		/**
		* @brief 判断玩家是否有固定跳跃速度
		* @return bool 是否有固定跳跃速度
		*/
		[[nodiscard]] bool has_fixed_jump_speed() const 
		{ return _fixed_jump_set_count > 0; }
		/**
		* @brief 判断玩家是否已经传送过
		* @return bool 是否已经传送过
		*/
		[[nodiscard]] bool has_transferred() const { return _transferred; }
		/**
		* @brief 判断玩家是否锁住了金币
		* @return bool 是否锁住了金币
		*/
		[[nodiscard]] bool coins_locked() const { return _coins_locked; }
		/**
		* @brief 获得玩家获得的钥匙数量
		* @return int 钥匙数量
		*/
		[[nodiscard]] int keys_count() const { return _keys_count; }
		/**
		* @brief 获得玩家获得的金币数量
		* @return int 金币数量
		*/
		[[nodiscard]] int coins_count() const { return _coins_count; }
		/**
		* @brief 获得玩家需要的钥匙数量
		* @return int 钥匙数量
		*/
		[[nodiscard]] int keys_required() const { return _keys_required; }
		/**
		* @brief 获得玩家当前的 x 方向速度
		* @return int 速度，单位为像素/秒，负值表示向左
		*/
		[[nodiscard]] int get_speed_x() const { return _speed_x; }
		/**
		* @brief 获得玩家当前的 y 方向速度
		* @return int 速度，单位为像素/秒，负值表示向上
		*/
		[[nodiscard]] int get_speed_y() const { return _speed_y; }
		/**
		* @brief 获得玩家的移动速度
		* @return int 速度，单位为像素/秒
		*/
		[[nodiscard]] int get_move_speed() const { return _max_speed_x; }
		/**
		* @brief 获得玩家的跳跃速度
		* @return int 速度，单位为像素/秒
		*/
		[[nodiscard]] int get_jump_speed() const { return _max_speed_y; }
		/**
		* @brief 获得玩家的被动移动速度
		* @return int 速度，单位为像素/秒
		*/
		[[nodiscard]] int get_gravity() const { return _gravity; }
		/**
		* @brief 获得玩家的被动移动速度
		* @return int 速度，单位为像素/秒
		*/
		[[nodiscard]] int get_passive_move_speed() const { return _passive_move_speed; }
		/**
		* @brief 获得玩家的固定跳跃速度
		* @return int 速度，单位为像素/秒
		*/
		[[nodiscard]] int get_fixed_jump_speed() const { return _fixed_jump_speed; }
	protected:
		/**
		* @brief 向左移动玩家
		* @param clock_now 系统时钟
		*/
		void move_left(std::clock_t clock_now);
		/**
		* @brief 向右移动玩家
		* @param clock_now 系统时钟
		*/
		void move_right(std::clock_t clock_now);
		/**
		* @brief 使玩家下落
		* @param clock_now 系统时钟
		*/
		void drop(std::clock_t clock_now);
		/**
		* @brief 使玩家跳跃
		* @param clock_now 系统时钟
		*/
		void jump(std::clock_t clock_now);
	private:
		struct SPEED // 速度结构体
		{
			struct MOVE // 移动速度结构体
			{
				static const int BUFF_NONE; // 无 buff 状态
				static const int BUFF_SUPER; // 超级 buff 状态
				static const int BUFF_FLY; // 飞行 buff 状态
				static const int BUFF_POISON; // 中毒 buff 状态
			};
			struct JUMP // 跳跃速度结构体
			{
				static const int BUFF_NONE; // 无 buff 状态
				static const int BUFF_SUPER; // 超级 buff 状态
				static const int BUFF_FLY; // 飞行 buff 状态
				static const int BUFF_POISON; // 中毒 buff 状态
			};
		};
		struct GRAVITY // 重力结构体
		{
			static const int BUFF_NONE;  // 无 buff 状态
			static const int BUFF_SUPER;  // 超级 buff 状态
			static const int BUFF_FLY;  // 飞行 buff 状态
			static const int BUFF_POISON;  // 中毒 buff 状态
		};
		int limit_left;  // 限制玩家移动的左边界，默认为0
		int limit_top;  // 限制玩家移动的上边界，默认为0
		int limit_right;  // 限制玩家移动的右边界，默认为窗口宽度
		int limit_bottom;  // 限制玩家移动的下边界，默认为窗口高度
		int _speed_x = 0; // 玩家速度的 x 分量，单位为像素/秒，负值表示向左
		int _speed_y = 0; // 玩家速度的 y 分量，单位为像素/秒，负值表示向上
		int _max_speed_x = SPEED::MOVE::BUFF_NONE; // 玩家最大速度的 x 分量
		int _max_speed_y = SPEED::JUMP::BUFF_NONE; // 玩家最大速度的 y 分量
		int _gravity = GRAVITY::BUFF_NONE; // 玩家重力加速度，单位为像素/秒^2
		int _keys_count = 0; // 玩家获得的钥匙数量
		int _coins_count = 0; // 玩家获得的金币数量
		int _keys_required = 0; // 玩家需要的钥匙数量
		long _jump_ability = 0; // 玩家跳跃的能力
		long _drop_ability = 1; // 玩家下落的能力
		long _move_left_ability = 1; // 玩家向左移动的能力
		long _move_right_ability = 1; // 玩家向右移动的能力
		int _max_speed_x_copy = SPEED::MOVE::BUFF_NONE; // 玩家最大速度的 x 分量的备份
		int _max_speed_y_copy = SPEED::JUMP::BUFF_NONE; // 玩家最大速度的 y 分量的备份
		int _gravity_copy = GRAVITY::BUFF_NONE; // 玩家重力加速度的备份
		int _passive_move_speed = 0; // 玩家被动移动速度
		int _fixed_jump_speed = 0; // 玩家固定跳跃速度
		long _max_speed_x_set_count = 0; // 玩家最大速度的 x 分量设置次数
		long _max_speed_y_set_count = 0; // 玩家最大速度的 y 分量设置次数
		long _gravity_set_count = 0; // 玩家重力加速度设置次数
		long _passive_move_set_count = 0; // 玩家静态移动速度设置次数
		long _fixed_jump_set_count = 0; // 玩家固定跳跃速度设置次数
		bool _has_died = false; // 玩家人物是否已经死亡
		bool _has_won = false; // 玩家是否已经胜利
		bool _can_control_jump = true; // 玩家是否可以控制跳跃
		bool _player_jumped = false; // 玩家是否已经跳跃
		bool _coins_locked = false; // 是否已经锁住了金币
		bool _transferred = false; // 是否已经传送过
		BUFF _buff = BUFF::NONE; // 玩家当前的buff
		std::clock_t last_jump = 0; // 上一次跳跃的时间
		std::clock_t last_move_x = 0; // 上一次向左或向右移动的时间
		std::clock_t last_move_y = 0; // 上一次向下移动的时间
		std::set<std::pair<int, int>> _transferables; // 传送门队列
		/**
		* @brief 玩家停止的辅助函数
		*/
		void _player_stop();
		/**
		* @brief 移动玩家的辅助函数
		* @param clock_now 系统时钟
		*/
		void _move(std::clock_t clock_now);
	} PicoPlayerElement;
}
