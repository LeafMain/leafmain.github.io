﻿#include "picoloop.h"

// Pico 火元素实现
namespace picoloop
{
	// 绘制火元素
	void PicoFireElement::draw() const
	{
		if (!_swing_right)
		{
			draw_left_swing();
		}
		else
		{
			draw_right_swing();
		}
	}

	// 绘制火元素向左摆动的动画
	void PicoFireElement::draw_left_swing() const
	{
		_get_bk_image();
		_draw_left();
	}

	// 绘制火元素向右摆动的动画
	void PicoFireElement::draw_right_swing() const
	{
		_get_bk_image();
		_draw_right();
	}

	// 绘制火元素向左摆动
	void PicoFireElement::_draw_left() const
	{
		// 绘制火焰根部
		setfillcolor(0x0040ff);
		solidrectangle(_40x(0), _40y(4), _40x(39), _40y(39));
		// 绘制火焰顶部
		POINT fire_points[11] = { 0 };
		setfillcolor(0x002fff);
		for (int i = 0; i < 10; i++)
		{
			fire_points[i] = { _40x(i << 2), _40y((i & 1) ? 0 : 5)};
		}
		fire_points[10] = { _40x(39), _40y(5) };
		solidpolygon(fire_points, 11);
	}

	// 绘制火元素向右摆动
	void PicoFireElement::_draw_right() const
	{
		// 绘制火焰根部
		setfillcolor(0x0035ff);
		solidrectangle(_40x(0), _40y(4), _40x(39), _40y(39));
		// 绘制火焰顶部
		POINT fire_points[13] = { 0 };
		setfillcolor(0x002fff);
		for (int i = 0; i < 10; i++)
		{
			fire_points[i] = { _40x(i << 2), _40y((i & 1) ? 5 : 0) };
		}
		fire_points[10] = { _40x(39), _40y(0) };
		fire_points[11] = { _40x(39), _40y(5) };
		fire_points[12] = { _40x(0), _40y(5) };
		solidpolygon(fire_points, 13);
	}

	// 更新系统时钟
	void PicoFireElement::update_clock()
	{
		clock_now = std::clock(); // 获取系统时钟
		_last_animate_time = clock_now; // 记录上一次动画时间
	}

	// 重置火元素数据
	void PicoFireElement::reset_data()
	{
		base_reset(); // 调用基类的重置方法
		_swing_right = false;
		update_clock(); // 更新时钟
	}

	// 更新火元素动画
	void PicoFireElement::update_animation()
	{
		// 每 0.2 秒更新一次火元素动画
		clock_now = std::clock();
		double elapsed = double(clock_now - _last_animate_time)
			/ CLOCKS_PER_SEC;
		if (elapsed >= 0.2)
		{
			// 切换摆动方向
			if (_swing_right)
			{
				_swing_right = false;
				erase();
				_draw_left();
				FlushBatchDraw();
			}
			else
			{
				_swing_right = true;
				erase();
				_draw_right();
				FlushBatchDraw();
			}
			// 更新时钟
			_last_animate_time = clock_now;
		}
	}

	// 玩家碰到元素时触发的事件
	void PicoFireElement::on_bump(PicoPlayer& player, bool occurred, bool first)
	{
		// 玩家碰到火元素，直接死亡
		if (occurred)
		{
			if (first)
			{
				// 玩家人物死亡
				player.die();
			}
		}
		else
		{
			if (DISABLE_ANIMATION) return;
			update_animation();
		}
	}
}