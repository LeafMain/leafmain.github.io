﻿#pragma once

// 对石头元素类的声明
namespace picoloop
{
    /**
     * @brief 石头元素类
     */
    class PicoStoneElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制石头元素
        */
        void draw() const override;
        /**
         * @brief 克隆石头元素
         * @return 克隆出的 PicoStoneElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoStoneElement(*this); }
    protected:
        /**
        * @brief 擦除石头元素的具体实现
        */
        void _erase_func() const;
        /**
        * @brief 绘制石头元素的具体实现
        */
        void _draw_func() const;
        /**
        * @brief 石头元素被踩时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 石头元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 石头元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 石头元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 重置石头元素的数据
        */
        void reset_data() override;
        /**
        * @brief 绘制石头元素
        */
        virtual void draw_stone() const;
    private:
        mutable COLORREF _bk = 0x111111;  // 石头元素的背景色缓存
        static const int OFFSET;  // 石头元素的绘制偏移量
        int _offset_top = 0; // 石头元素的顶部偏移量
        int _offset_left = 0;  // 石头元素的左侧偏移量
        int _offset_right = 0;  // 石头元素的右侧偏移量
        int _offset_bottom = 0;  // 石头元素的底部偏移量
    };

    /**
     * @brief 红色石头元素类
     */
    class PicoRedStoneElement : public PicoStoneElement
    {
    public:
        using PicoStoneElement::PicoStoneElement;
        /**
        * @brief 绘制红色石头元素
        */
        void draw_stone() const override;
        /**
         * @brief 克隆红色石头元素
         * @return 克隆出的 PicoRedStoneElement 实例
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoRedStoneElement(*this); }
    };

    /**
     * @brief 橙色石头元素类
     */
    class PicoOrangeStoneElement : public PicoStoneElement
    {
    public:
        using PicoStoneElement::PicoStoneElement;
        
        /**
         * @brief 克隆橙色石头元素
         * @return 克隆出的 PicoOrangeStoneElement 实例
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoOrangeStoneElement(*this); }
    protected:
        /**
        * @brief 绘制橙色石头元素
        */
        void draw_stone() const override;
    };

    /**
     * @brief 黄色石头元素类
     */
    class PicoYellowStoneElement : public PicoStoneElement
    {
    public:
        using PicoStoneElement::PicoStoneElement;
        /**
         * @brief 克隆黄色石头元素
         * @return 克隆出的 PicoYellowStoneElement 实例
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoYellowStoneElement(*this); }
    protected:
        /**
        * @brief 绘制黄色石头元素
        */
        void draw_stone() const override;
    };

    /**
     * @brief 绿色石头元素类
     */
    class PicoGreenStoneElement : public PicoStoneElement
    {
    public:
        using PicoStoneElement::PicoStoneElement;
        /**
         * @brief 克隆绿色石头元素
         * @return 克隆出的 PicoGreenStoneElement 实例
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoGreenStoneElement(*this); }
    protected:
        /**
        * @brief 绘制绿色石头元素
        */
        void draw_stone() const override;
    };

    /**
     * @brief 青色石头元素类
     */
    class PicoCyanStoneElement : public PicoStoneElement
    {
    public:
        using PicoStoneElement::PicoStoneElement;
        /**
         * @brief 克隆青色石头元素
         * @return 克隆出的 PicoCyanStoneElement 实例
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoCyanStoneElement(*this); }
    protected:
        /**
        * @brief 绘制青色石头元素
        */
        void draw_stone() const override;
    };

    /**
     * @brief 蓝色石头元素类
     */
    class PicoBlueStoneElement : public PicoStoneElement
    {
    public:
        using PicoStoneElement::PicoStoneElement;
        /**
         * @brief 克隆蓝色石头元素
         * @return 克隆出的 PicoBlueStoneElement 实例
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoBlueStoneElement(*this); }
    protected:
        /**
        * @brief 绘制蓝色石头元素
        */
        void draw_stone() const override;
    };

    /**
     * @brief 紫色石头元素类
     */
    class PicoPurpleStoneElement : public PicoStoneElement
    {
    public:
        using PicoStoneElement::PicoStoneElement;
        /**
         * @brief 克隆紫色石头元素
         * @return 克隆出的 PicoPurpleStoneElement 实例
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoPurpleStoneElement(*this); }
    protected:
        /**
        * @brief 绘制紫色石头元素
        */
        void draw_stone() const override;
    };

    /**
     * @brief 白色石头元素类
     */
    class PicoWhiteStoneElement : public PicoStoneElement
    {
    public:
        using PicoStoneElement::PicoStoneElement;
        /**
         * @brief 克隆白色石头元素
         * @return 克隆出的 PicoWhiteStoneElement 实例
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoWhiteStoneElement(*this); }
    protected:
        /**
        * @brief 绘制白色石头元素
        */
        void draw_stone() const override;
    };

    /**
     * @brief 粉色石头元素类
     */
    class PicoPinkStoneElement : public PicoStoneElement
    {
    public:
        using PicoStoneElement::PicoStoneElement;
        /**
         * @brief 克隆粉色石头元素
         * @return 克隆出的 PicoPinkStoneElement 实例
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoPinkStoneElement(*this); }\
    protected:
        /**
        * @brief 绘制粉色石头元素
        */
        void draw_stone() const override;
    };
}