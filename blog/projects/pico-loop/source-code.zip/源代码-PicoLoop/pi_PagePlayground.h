﻿#pragma once

// 游戏广场页面类声明
namespace picoloop
{
	/**
	* @brief 游戏广场页面类
	*/
	class PagePlayground : public Page
	{
	public:
		friend class PageGameCreate;
		/**
		* @brief 游戏广场页面类构造函数
		* @param game 游戏对象
		*/
		PagePlayground(Game& game);
		/**
		* @brief 游戏广场页面类析构函数
		*/
		~PagePlayground() override;
		/**
		* @brief 监听页面事件
		* @param event 事件
		*/
		void listen_event(ExMessage& event);
		/**
		* @brief 设置上一页面
		* @param prev_page 上一页面
		*/
		void set_previous_page(Page* prev_page) { _prev_page = prev_page; }
	protected:
		/**
		* @brief 绘制页面
		*/
		void draw_page() const override;
		/**
		* @brief 进入页面时调用
		*/
		void on_enter()  override;
		/**
		* @brief 离开页面时调用
		*/
		void on_leave() override;
		/**
		* @brief 返回元素编辑页面
		*/
		void exit_page();
		/**
		* @brief 切换暂停和继续状态
		*/
		void toggle_pause();
		/**
		* @brief 重玩游戏
		*/
		void replay();
		/**
		* @brief 截图
		*/
		void print_screen();
		/**
		* @brief 进入帮助页面
		*/
		void enter_help();
		/**
		* @brief 阻止一次自动开始游戏
		* @note 只能阻止一次，下次进入页面仍然会自动开始游戏
		*/
		void prevent_auto_play_once() { _auto_play = false; }
		/**
		* @brief 设置关卡名称
		* @param name 关卡名称
		*/
		void set_level_name(LPCTSTR name);
		/**
		* @brief 设置关卡序号
		* @param name 关卡序号
		*/
		void set_level_number(int number) { _level_number = number; }
	private:
		struct COLOR // 颜色常量结构
		{
			static const COLORREF BORDER; // 边框颜色
			static const COLORREF BACKGROUND; // 背景颜色
			static const COLORREF BUTTON_BACK; // 返回按钮颜色
			static const COLORREF BUTTON_BACK_HOVER; // 返回按钮鼠标悬停颜色
			static const COLORREF BUTTON_PAUSE; // 暂停按钮颜色
			static const COLORREF BUTTON_PAUSE_HOVER; // 暂停按钮鼠标悬停颜色
			static const COLORREF BUTTON_REPLAY; // 重玩按钮颜色
			static const COLORREF BUTTON_REPLAY_HOVER; // 重玩按钮鼠标悬停颜色
			static const COLORREF BUTTON_PRINT_SCREEN; // 截图按钮颜色
			static const COLORREF BUTTON_PRINT_SCREEN_HOVER; // 截图按钮鼠标悬停颜色
			static const COLORREF BUTTON_HELP; // 帮助按钮颜色
			static const COLORREF BUTTON_HELP_HOVER; // 帮助按钮鼠标悬停颜色
			static const COLORREF BUTTON_OPERATE; // 操作按钮颜色
			static const COLORREF BUTTON_OPERATE_HOVER; // 操作按钮鼠标悬停颜色
			static const COLORREF SHORTCUTS; // 快捷键提示颜色
			static const COLORREF STATUS_TEXT; // 状态文字颜色
			static const COLORREF LEVEL_NAME; // 关卡名称颜色
			static const COLORREF RUN_TIME; // 游戏时间颜色
			static const COLORREF REST_LIVES; // 玩家生命值颜色
			static const COLORREF KEYS_COUNT; // 钥匙数量颜色
			static const COLORREF COINS_COUNT; // 金币数量颜色
			static const COLORREF LEFT_SIDE_BORDER; // 左侧边框颜色
		};
		struct FONT // 字体常量结构
		{
			static const LPCTSTR BUTTON_FONT; // 按钮字体
			static const LPCTSTR SHORTCUTS_FONT; // 快捷键提示字体
			static const LPCTSTR STATUS_FONT; // 状态文字字体
			static const LPCTSTR LEFT_SIDE_FONT; // 左侧文字字体
			static const LPCTSTR OPERATE_FONT; // 操作按钮字体
		};
		struct COUNT // 数量结构
		{
			[[deprecated]] static const int PLAYER_LIVES; // 玩家生命数量
		};
		PicoPlayground playground; // 游戏广场
		GameTitle title_left; // 左侧标题
		GameTitle title_right; // 右侧标题
		RectButton button_back; // 返回按钮
		RectButton button_pause; // 暂停按钮
		RectButton button_replay; // 重玩按钮
		RectButton button_print_screen; // 截图按钮
		RectButton button_help; // 帮助按钮
		PicoPlayerElement player_icon; // 玩家图标
		RectButton button_player_jump; // 玩家跳跃按钮
		RectButton button_player_left; // 玩家左移按钮
		RectButton button_player_right; // 玩家右移按钮
		bool _auto_play = true; // 是否自动开始游戏
		bool _player_will_win = false; // 玩家即将胜利
		bool _player_won = false; // 玩家是否胜利
		bool _player_will_die = false; // 玩家即将死亡
		bool _player_died = false; // 玩家是否死亡
		bool _screen_will_be_printed = false; // 是否已截图
		bool _screen_printed = false; // 是否已截图
		int _run_time_minutes = 0; // 游戏时间分钟
		int _run_time_seconds = 0; // 游戏时间秒数
		int _keys_count = 0; // 钥匙数量
		int _coins_count = 0; // 金币数量
		LPTSTR _level_name_text = _tcsdup(_T("Level")); // 关卡名称文本
		LPTSTR _rest_lives_text = _tcsdup(_T("Lives: INF")); // 玩家生命值文本
		std::clock_t _player_win_clock = 0; // 玩家人物胜利计时器
		std::clock_t _player_die_clock = 0; // 玩家人物死亡计时器
		std::clock_t _run_time_clock = 0; // 运行时间计时器
		std::clock_t _screen_print_clock = 0; // 截图计时器
		Page* _prev_page = nullptr; // 上一页面
		int _level_number = 0; // 关卡序号
		/**
		* @brief 重置页面参数
		*/
		void _reset();
		/**
		* @brief 绘制边框
		*/
		void _draw_border() const;
		/**
		* @brief 绘制状态文字
		* @param text 状态文字
		*/
		void _draw_status_text(LPCTSTR text) const;
		/**
		* @brief 绘制快捷键提示
		*/
		void _draw_shortcuts() const;
		/**
		* @brief 绘制关卡名称
		*/
		void _draw_level_name() const;
		/**
		* @brief 绘制游戏时间
		* @param minutes 游戏时间字符串
		*/
		void _draw_run_time(LPCTSTR time) const;
		/**
		* @brief 绘制玩家生命值
		*/
		void _draw_rest_lives() const;
		/**
		* @brief 绘制钥匙数量
		*/
		void _draw_keys_count() const;
		/**
		* @brief 绘制金币数量
		*/
		void _draw_coins_count() const;
		/**
		* @brief 更新游戏时间
		*/
		void _update_run_time();
		/**
		* @brief 更新物资数量
		*/
		void _update_items_count();
		/**
		* @brief 保存已通过的关卡
		*/
		void _save_passed_levels() const;
		/**
		* @brief 监听鼠标事件
		* @param event 事件
		*/
		void _listen_mouse(ExMessage& event);
		/**
		* @brief 监听键盘事件
		* @param event 事件
		*/
		void _listen_keyboard(ExMessage& event);
		/**
		* @brief 监听移动事件
		* @param event 事件
		*/
		void _listen_move(ExMessage& event);
		/**
		* @brief 监听玩家事件
		* @param event 事件
		*/
		void _listen_player(std::clock_t ev_clock);
		/**
		* @brief 监听截图事件
		* @param event 事件
		*/
		void _listen_screen_print(std::clock_t ev_clock);
	};
}