﻿#include "picoloop.h"

// 对石头元素类的实现
namespace picoloop
{
    const int PicoStoneElement::OFFSET = 1;  // 石头元素的绘制偏移量

    // 绘制石头元素
    void PicoStoneElement::draw() const
    {
        // 获取中心坐标的像素颜色
        _bk = getpixel(x + size / 2, y + size / 2);
        _get_bk_image();
        draw_stone();
    }

    // 绘制石头元素
    void PicoStoneElement::draw_stone() const
    {
        setfillcolor(0x909090);
        _draw_func();
    }

    // 擦除石头元素的具体实现
    void PicoStoneElement::_erase_func() const
    {
        setfillcolor(_bk);
        solidrectangle(_40x(0), _40y(0), _40x(39), _40y(39));
    }

    // 绘制石头元素的具体实现
    void PicoStoneElement::_draw_func() const
    {
        solidroundrect(
            _40x(0) + _offset_left, _40y(0) + _offset_top,
            _40x(39) - _offset_right, _40y(39) - _offset_bottom,
            _40x(2) - _40x(0), _40y(2) - _40y(0));
    }

    // 绘制红色石头元素
    void PicoRedStoneElement::draw_stone() const
    {
        setfillcolor(0x2020cc);
        _draw_func();
    }

    // 绘制橙色石头元素
    void PicoOrangeStoneElement::draw_stone() const
    {
        setfillcolor(0x0083ff);
        _draw_func();
    }

    // 绘制黄色石头元素
    void PicoYellowStoneElement::draw_stone() const
    {
        setfillcolor(0x00e7f2);
        _draw_func();
    }

    // 绘制绿色石头元素
    void PicoGreenStoneElement::draw_stone() const
    {
        setfillcolor(0x00af00);
        _draw_func();
    }

    // 绘制青色石头元素
    void PicoCyanStoneElement::draw_stone() const
    {
        setfillcolor(0xbbbb00);
        _draw_func();
    }

    // 绘制蓝色石头元素
    void PicoBlueStoneElement::draw_stone() const
    {
        setfillcolor(0xff9b00);
        _draw_func();
    }

    // 绘制紫色石头元素
    void PicoPurpleStoneElement::draw_stone() const
    {
        setfillcolor(0xff6699);
        _draw_func();
    }

    // 绘制白色石头元素
    void PicoWhiteStoneElement::draw_stone() const
    {
        setfillcolor(0xfdfdfd);
        _draw_func();
    }

    // 绘制粉色石头元素
    void PicoPinkStoneElement::draw_stone() const
    {
        setfillcolor(0xff99ff);
        _draw_func();
    }

    // 石头元素被踩时触发的事件
    void PicoStoneElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_drop();
                player.enable_jump();
                _offset_left = 0;
                _offset_top = OFFSET;
                _offset_right = 0;
                _offset_bottom = 0;
                _erase_func();
                draw_stone();
                FlushBatchDraw();
            }
        }
        else
        {
            if (first)
            {
                player.enable_drop();
                player.disable_jump();
                _offset_left = 0;
                _offset_top = 0;
                _offset_right = 0;
                _offset_bottom = 0;
                _erase_func();
                draw_stone();
                FlushBatchDraw();
            }
        }
    }

    // 石头元素被顶起时触发的事件
    void PicoStoneElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.stop_shift();
                _offset_left = 0;
                _offset_top = 0;
                _offset_right = 0;
                _offset_bottom = OFFSET;
                _erase_func();
                draw_stone();
                FlushBatchDraw();
            }
        }
        else
        {
            if (first)
            {
                _offset_left = 0;
                _offset_top = 0;
                _offset_right = 0;
                _offset_bottom = 0;
                _erase_func();
                draw_stone();
                FlushBatchDraw();
            }
        }
    }

    // 石头元素向左推动时触发的事件
    void PicoStoneElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
                _offset_left = 0;
                _offset_top = 0;
                _offset_right = OFFSET;
                _offset_bottom = 0;
                _erase_func();
                draw_stone();
                FlushBatchDraw();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
                _offset_left = 0;
                _offset_top = 0;
                _offset_right = 0;
                _offset_bottom = 0;
                _erase_func();
                draw_stone();
                FlushBatchDraw();
            }
        }
    }

    // 石头元素向右推动时触发的事件
    void PicoStoneElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_right();
                _offset_left = OFFSET;
                _offset_top = 0;
                _offset_right = 0;
                _offset_bottom = 0;
                _erase_func();
                draw_stone();
                FlushBatchDraw();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_right();
                _offset_left = 0;
                _offset_top = 0;
                _offset_right = 0;
                _offset_bottom = 0;
                _erase_func();
                draw_stone();
                FlushBatchDraw();
            }
        }
    }

    // 重置石头元素的数据
    void PicoStoneElement::reset_data()
    {
        base_reset();  // 调用基类的重置数据函数
        _offset_left = 0;
        _offset_top = 0;
        _offset_right = 0;
        _offset_bottom = 0;
    }
}