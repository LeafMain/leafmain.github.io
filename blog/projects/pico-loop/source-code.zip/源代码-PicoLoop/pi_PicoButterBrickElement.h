﻿#pragma once

// 对向上黄油砖块元素类的声明
namespace picoloop
{
    /**
     * @brief 向上黄油砖块元素类
     */
    class PicoUpButterBrickElement : public PicoBrickElement
    {
    public:
        using PicoBrickElement::PicoBrickElement;
        /**
        * @brief 绘制向上黄油砖块元素
        */
        void draw() const override;
        /**
         * @brief 克隆向上黄油砖块元素
         * @return 克隆出的 PicoUpButterBrickElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override
        {
            return new PicoUpButterBrickElement(*this);
        }
        /**
         * @brief 重置向上黄油砖块元素数据
         */
        void reset_data() override;
    protected:
        static const int STICKINESS; // 向上黄油粘性
        /**
        * @brief 向上黄油砖块元素被踩时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
    private:
        PicoPlayer::BUFF _buff = PicoPlayer::BUFF::NONE; // 玩家的buff
        bool _jump_disabled = false; // 是否禁用了跳跃
        bool _jump_enabled = false; // 是否启用了跳跃
    };

    /**
     * @brief 向下黄油砖块元素类
     */
    class PicoDownButterBrickElement : public PicoBrickElement
    {
    public:
        using PicoBrickElement::PicoBrickElement;
        /**
        * @brief 绘制向下黄油砖块元素
        */
        void draw() const override;
        /**
         * @brief 克隆向下黄油砖块元素
         * @return 克隆出的 PicoDownButterBrickElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override
        {
            return new PicoDownButterBrickElement(*this);
        }
        /**
        * @brief 重置向下黄油砖块元素数据
        */
        void reset_data() override;
    protected:
        static const int STICKINESS; // 向下黄油粘性
        /**
        * @brief 向下黄油砖块元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向下黄油砖块元素向左推时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 向下黄油砖块元素向右推时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
    private:
        bool _stuck = false; // 是否被粘住
        bool _left_opened = false; // 是否打开了左边
        bool _right_opened = false; // 是否打开了右边
    };
}