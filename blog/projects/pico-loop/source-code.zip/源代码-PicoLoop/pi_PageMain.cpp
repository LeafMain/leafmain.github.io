﻿#include "picoloop.h"

// 主页类静态变量定义
namespace picoloop
{
	const COLORREF PageMain::COLOR::BACKGROUND = 0x111111; // 背景颜色
	const COLORREF PageMain::COLOR::PLAY_BUTTON = GREEN; // 开始游戏按钮颜色
	const COLORREF PageMain::COLOR::PLAY_BUTTON_BACKGROUD = BLACK; // 开始游戏按钮背景颜色
	const COLORREF PageMain::COLOR::PLAY_BUTTON_HOVER = LIGHTGREEN; // 开始游戏按钮悬停颜色
	const COLORREF PageMain::COLOR::MAKE_BUTTON = CYAN; // 制作游戏按钮颜色
	const COLORREF PageMain::COLOR::MAKE_BUTTON_BACKGROUD = BLACK; // 制作游戏按钮背景颜色
	const COLORREF PageMain::COLOR::MAKE_BUTTON_HOVER = LIGHTCYAN; // 制作游戏按钮悬停颜色
	const COLORREF PageMain::COLOR::EXIT_BUTTON = DARKGRAY; // 制作游戏按钮颜色
	const COLORREF PageMain::COLOR::EXIT_BUTTON_HOVER = LIGHTGRAY; // 制作游戏按钮悬停颜色
	const COLORREF PageMain::COLOR::AUTHOR_TEXT = DARKGRAY; // 作者信息颜色
	const LPCTSTR PageMain::FONT::BUTTON_FONT = _T("Arial Rounded MT Bold"); // 按钮字体
	const LPCTSTR PageMain::FONT::AUTHOR_FONT = _T("Arial Black"); // 作者信息字体颜色
}

// 主页类实现
namespace picoloop
{
	// PageMain 构造函数
	PageMain::PageMain(Game& game) : Page(game),
		game_title{ 280, 75, 1.5 },
		play_button{
			200, 650, 320, 100, 10, 10, 70, 3, PS_SOLID,
			_T("PLAY"), FONT::BUTTON_FONT, COLOR::PLAY_BUTTON_BACKGROUD,
			COLOR::PLAY_BUTTON, COLOR::PLAY_BUTTON, COLOR::PLAY_BUTTON_BACKGROUD,
			COLOR::PLAY_BUTTON_HOVER, COLOR::PLAY_BUTTON_HOVER
		},
		make_button{
			680, 650, 320, 100, 10, 10, 70, 3, PS_SOLID,
			_T("MAKE"), FONT::BUTTON_FONT, COLOR::MAKE_BUTTON_BACKGROUD,
			COLOR::MAKE_BUTTON, COLOR::MAKE_BUTTON, COLOR::MAKE_BUTTON_BACKGROUD,
			COLOR::MAKE_BUTTON_HOVER, COLOR::MAKE_BUTTON_HOVER
		},
		exit_button{
			1125, 755, 60, 30, 2, 2, 18, 1, PS_SOLID,
			_T("EXIT"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::EXIT_BUTTON, COLOR::EXIT_BUTTON, COLOR::BACKGROUND,
			COLOR::EXIT_BUTTON_HOVER, COLOR::EXIT_BUTTON_HOVER
		},
		editor{165, 195, 11, 22},
		playground{ editor }
	{}

	// 绘制页面
	void PageMain::draw_page() const
	{
		// 绘制背景
		setbkcolor(COLOR::BACKGROUND);
		cleardevice();
		// 绘制按钮
		game_title.draw();
		play_button.draw();
		make_button.draw();
		exit_button.draw();
		// 绘制作者信息
		_draw_author_text();
	}

	// 页面进入时调用
	void PageMain::on_enter()
	{
		game.set_sleep_time(0);
	}

	// 页面进入绘制后调用
	void PageMain::on_after_enter()
	{
		if (_playground_loaded)
		{
			playground.replay();
			_reset_clock();
		}
		else
		{
			_playground_loaded = true;
			_create_playground();
			_reset_clock();
		}
	}

	// 页面离开时调用
	void PageMain::on_leave()
	{
		game.set_sleep_time(Game::DEFUALT_SLEEP_TIME);
	}

	// 绘制作者信息
	void PageMain::_draw_author_text() const
	{
		settextcolor(COLOR::AUTHOR_TEXT);
		settextstyle(18, 0, FONT::AUTHOR_FONT);
		RECT rect = { 2, 765, 162, 795 };
		drawtext(_T("Made by LeafMain"), &rect, 
			DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}

	// 创建游戏展示区
	void PageMain::_create_playground()
	{
		// ROW: 10; COLUMN: 20;
		using TYPE = PicoElementCollection::TYPE;
		PicoElementCollection::Data data;
		std::stringstream data_stream{
			R"(0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
			0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0  
			0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
			0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
			0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 
			0 0 0 0 0 0 0 0 0 9 0 0 10 0 0 0 0 0 0 0 0 0  
			0 0 0 0 0 0 6 0 0 14 0 0 20 0 0 2 0 0 0 0 0 0  
			0 0 0 7 0 0 16 0 0 14 2 2 20 0 0 17 0 0 8 0 0 0 
			1 0 0 15 0 0 16 0 0 14 35 35 20 0 0 17 0 0 18 0 0 2 
			3 0 0 15 0 0 16 0 0 14 34 34 20 0 0 17 0 0 18 0 0 20  
			12 0 0 15 0 0 16 0 0 14 5 5 20 0 0 17 0 0 18 0 0 20 )"
		};
		for (int row = 0; row < editor.GRID_ROW; row++)
		{
			data.push_back(std::vector<TYPE>());
			for (int column = 0; column < editor.GRID_COLUMN; column++)
			{
				int type;
				if (data_stream >> type)
				{
					TYPE type_enum = static_cast<TYPE>(type);
					data[row].push_back(type_enum);
				}
				else
				{
					throw std::runtime_error(
						"Cannot load data with incorrenct format."
					);
				}
			}
		}
		// 应用样式
		playground.transfer(editor, &data, true);
	}

	// 重置时钟
	void PageMain::_reset_clock()
	{
		_enter_clock = std::clock();
	}

	// 监听事件
	void PageMain::listen_event(ExMessage& event)
	{
		play_button.listen_hover(event);
		make_button.listen_hover(event);
		exit_button.listen_hover(event);
		_listen_playground(event);
		_listen_operate_event(event);
	}

	// 监听展示区事件
	void PageMain::_listen_playground(ExMessage& event)
	{
		// 计算时间差
		std::clock_t now = std::clock();
		double diff = double(now - _enter_clock) / CLOCKS_PER_SEC;
		// 监听展示区事件
		playground.listen_event(event,
			_player_up_if(diff), _player_left_if(diff), 
			_player_right_if(diff), true);
		// 人物胜利或死亡时，立即重来
		if (playground.player_won() || playground.player_died())
		{
			playground.replay();
			_reset_clock();
		}
		// 窗口离开时，暂停并重置展示区
		if (event.message != WM_MOVE &&(
			event.wParam == Window::MINIMIZE ||
			event.wParam == Window::KILL_FOCUS))
		{
			// 窗口激活后，才重新开始计时
			if (_has_activated)
			{
				_reset_clock();
				if (!playground.paused())
				{
					playground.pause();
				}
				if (game.sleep_time() == 0) // 切换至能效模式
				{
					game.set_sleep_time(Game::DEFUALT_SLEEP_TIME);
				}
			}
		}
		// 窗口重新激活时，恢复展示动画
		else if (event.message == WM_ACTIVATE && playground.paused())
		{
			if (game.sleep_time() != 0) // 切换至性能模式
			{
				game.set_sleep_time(0);
			}
			_reset_clock();
			playground.resume();
			playground.replay();
		}
		else if (!_has_activated && event.message == WM_ACTIVATE)
		{
			_has_activated = true;
		}
	}

	// 监听操作事件
	void PageMain::_listen_operate_event(ExMessage& event)
	{
		// 监听按钮事件
		if (event.message == WM_LBUTTONDOWN)
		{
			// 如果开始游戏按钮被点击
			if (play_button.clicked(event))
			{
				game.page_level_select.enter();
			}
			// 如果制作游戏按钮被点击
			else if (make_button.clicked(event))
			{
				game.page_make_select.enter();
			}
			// 如果退出按钮被点击
			else if (exit_button.clicked(event))
			{
				game.exit();
			}
		}

		// 监听快捷键事件
		if (event.message == WM_KEYDOWN && !event.prevdown)
		{
			switch (event.vkcode)
			{
			case 'p': // 按下 P 键进入游戏
			case 'P':
				game.page_level_select.enter();
				break;
			case 'm': // 按下 M 键进入制作游戏页面
			case 'M':
				game.page_make_select.enter();
				break;
			case VK_ESCAPE: // 按下 ESC 键退出游戏
				game.exit();
				break;
			}
		}
	}

	// 玩家向左运动的条件
	bool PageMain::_player_left_if(double diff)
	{
		return diff >= 11.50 && diff < 14.50;
	}

	// 玩家向右运动的条件
	bool PageMain::_player_right_if(double diff)
	{
		return diff >= 0.50 && diff < 1.18 ||
			diff >= 1.65 && diff < 2.28 ||
			diff >= 2.55 && diff < 3.22 ||
			diff >= 4.05 && diff < 4.68 ||
			diff >= 6.40 && diff < 6.80 ||
			diff >= 7.20 && diff < 7.85 ||
			diff >= 8.80 && diff < 9.45 ||
			diff >= 10.40 && diff < 10.85;
	}

	// 玩家向上运动的条件
	bool PageMain::_player_up_if(double diff)
	{
		return diff >= 0.50 && diff < 0.84 ||
			diff >= 1.65 && diff < 1.81 ||
			diff >= 2.55 && diff < 2.89 ||
			diff >= 4.05 && diff < 4.20 ||
			diff >= 5.20 && diff < 5.67 ||
			diff >= 5.77 && diff < 6.60 ||
			diff >= 7.20 && diff < 7.55 ||
			diff >= 8.80 && diff < 9.15 ||
			diff >= 10.40 && diff < 10.50 ||
			diff >= 11.50 && diff < 14.50;
	}
}