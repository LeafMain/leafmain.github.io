﻿#include "picoloop.h"

// 对向上黄油砖块元素类的实现
namespace picoloop
{
    const int PicoUpButterBrickElement::STICKINESS = 4; // 向上黄油粘性
    // 绘制向上黄油砖块元素
    void PicoUpButterBrickElement::draw() const
    {
        PicoBrickElement::draw();
        setlinestyle(PS_SOLID, 1);
        setlinecolor(0x08a4ff);
        setfillcolor(0x08c8ff);
        for (int i = 0; i < 5; i++)
        {
            fillcircle(_40x(4 + i * 8), _40y(4), _40x(3) - _40x(0));
        }
        setlinecolor(0x08c8ff);
        setfillcolor(0x66ddff);
        fillrectangle(_40x(1), _40y(0), _40x(39), _40y(4));
    }

    // 重置向上黄油砖块元素数据
    void PicoUpButterBrickElement::reset_data()
    {
        base_reset();
        _buff = PicoPlayer::BUFF::NONE; // 玩家的buff
        _jump_disabled = false; // 是否禁用了跳跃
        _jump_enabled = false; // 是否启用了跳跃
    }

    // 向上黄油砖块元素被踩时触发的事件
    void PicoUpButterBrickElement::on_pedal(PicoPlayer& player, 
        bool occurred, bool first)
    {
        if (occurred)
        {
            if (_buff != player.get_buff())
            {
                if (player.get_speed_y() == 0 && 
                    (_buff == PicoPlayer::BUFF::SUPER ||
                    player.get_buff() == PicoPlayer::BUFF::SUPER))
                {
                    // 触发玩家轻微跳跃，强制触发离开事件
                    player.erase();
                    player.y -= PicoPlayer::MOVE_STEP;
                    player.draw();
                }
                // 修改当前 buff
                _buff = player.get_buff();
            }
            if (first)
            {
                player.disable_drop();
                // 将速度削减成一半
                switch (player.get_buff())
                {
                case PicoPlayer::BUFF::POISON:
                    player.use_move_speed(PicoPlayer::NORMAL_MOVE_SPEED / 4);
                    break;
                case PicoPlayer::BUFF::FLY:
                    player.use_move_speed(PicoPlayer::NORMAL_MOVE_SPEED);
                    break;
                default:
                    player.use_move_speed(PicoPlayer::NORMAL_MOVE_SPEED / 2);
                    break;
                }
                // 如果是超级状态，则启用跳跃
                if (player.get_buff() == PicoPlayer::BUFF::SUPER)
                {
                    _jump_enabled = true;
                    player.enable_jump();
                    player.use_jump_speed(PicoPlayer::NORMAL_JUMP_SPEED / 2);
                }
                // 如果不能攀爬，则禁用跳跃
                else if (!player.has_fixed_jump_speed())
                {
                    _jump_disabled = true;
                    for (int i = 0; i < STICKINESS; i++)
                        player.disable_jump();
                }
            }
        }
        else
        {
            if (first)
            {
                player.enable_drop();
                player.recover_move_speed();
                // 如果禁用了跳跃则恢复
                if (_jump_disabled)
                {
                    _jump_disabled = false;
                    for (int i = 0; i < STICKINESS; i++)
                    {
                        player.enable_jump();
                    }
                }
                // 如果启用了跳跃则恢复
                if (_jump_enabled)
                {
                    _jump_enabled = false;
                    player.disable_jump();
                    player.recover_jump_speed();
                }
            }
        }
    }
}

namespace picoloop
{
    const int PicoDownButterBrickElement::STICKINESS = 1; // 向下黄油粘性
    // 绘制向下黄油砖块元素
    void PicoDownButterBrickElement::draw() const
    {
        PicoBrickElement::draw();
        setlinestyle(PS_SOLID, 1);
        setlinecolor(0x08a4ff);
        setfillcolor(0x08c8ff);
        for (int i = 0; i < 5; i++)
        {
            fillcircle(_40x(4 + i * 8), _40y(36), _40x(3) - _40x(0));
        }
        setlinecolor(0x08c8ff);
        setfillcolor(0x66ddff);
        fillrectangle(_40x(1), _40y(36), _40x(39), _40y(40));
    }

    // 重置向下黄油砖块元素数据
    void PicoDownButterBrickElement::reset_data()
    {
        base_reset();
        _stuck = false;
        _left_opened = false;
        _right_opened = false;
    }

    // 向下黄油砖块元素被顶起时触发的事件
    void PicoDownButterBrickElement::on_jump(PicoPlayer& player, 
        bool occurred, bool first)
    {
        if (occurred)
        {
            // 玩家离开黄油即释放
            if (_stuck && (!player.can_move_left() ||
                !player.can_move_right()))
            {
                player.stop_shift();
            }
            if (first)
            {
                player.stop_y();
                // 将速度削减成一半
                switch (player.get_buff())
                {
                case PicoPlayer::BUFF::POISON:
                    player.use_move_speed(PicoPlayer::NORMAL_MOVE_SPEED / 4);
                    break;
                case PicoPlayer::BUFF::FLY:
                    player.use_move_speed(PicoPlayer::NORMAL_MOVE_SPEED);
                    break;
                default:
                    player.use_move_speed(PicoPlayer::NORMAL_MOVE_SPEED / 2);
                    break;
                }
                for (int i = 0; i < STICKINESS; i++)
                {
                    player.disable_drop();
                }
                _stuck = true;
            }
        }
        else
        {
            if (first)
            {
                player.recover_move_speed();
                // 防止玩家穿透黄油
                if (player.y < y + size)
                {
                    player.stop_shift();
                }
                for (int i = 0; i < STICKINESS; i++)
                {
                    player.enable_drop();
                }
                _stuck = false;
            }
        }
    }

    // 向下黄油砖块元素向左推时触发的事件
    void PicoDownButterBrickElement::on_push_left(PicoPlayer& player, 
        bool occurred, bool first)
    {
        if (occurred)
        {
            if (first && (player.y != y + size ||
                player.get_speed_y() != 0))
            {
                player.disable_move_left();
                _left_opened = true;
            }
        }
        else
        {
            if (first && _left_opened)
            {
                player.enable_move_left();
                _left_opened = false;
            }
        }
    }

    // 向下黄油砖块元素向右推时触发的事件
    void PicoDownButterBrickElement::on_push_right(PicoPlayer& player, 
        bool occurred, bool first)
    {
        if (occurred)
        {
            if (first && (player.y != y + size || 
                player.get_speed_y() != 0))
            {
                player.disable_move_right();
                _right_opened = true;
            }
        }
        else
        {
            if (first && _right_opened)
            {
                player.enable_move_right();
                _right_opened = false;
            }
        }
    }
}