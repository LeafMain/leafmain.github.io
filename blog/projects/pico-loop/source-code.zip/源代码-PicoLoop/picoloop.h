﻿#pragma once

// 包含系统头文件
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <deque>
#include <direct.h>
#include <fstream>
#include <graphics.h>
#include <iostream>
#include <memory>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <stdexcept>
#include <string>
#include <typeinfo>
#include <vector>

// 包含自定义头文件
#include "pi_Window.h"
#include "pi_Direction.h"
#include "pi_GameTitle.h"
#include "pi_Button.h"
#include "pi_RectButton.h"
#include "pi_Grid.h"
// Pico Element
#include "pi_PicoElement.h"
#include "pi_PicoPlayer.h"
#include "pi_PicoEmptyElement.h"
#include "pi_PicoKeyElement.h"
#include "pi_PicoFlagElement.h"
#include "pi_PicoBrickElement.h"
#include "pi_PicoFireElement.h"
#include "pi_PicoCoinElement.h"
#include "pi_PicoSuperShoeElement.h"
#include "pi_PicoWingsElement.h"
#include "pi_PicoPoisonElement.h"
#include "pi_PicoAntidoteElement.h"
#include "pi_PicoStoneElement.h"
#include "pi_PicoOneUsedDoorElement.h"
#include "pi_PicoTubeElement.h"
#include "pi_PicoSoilElement.h"
#include "pi_PicoWaterElement.h"
#include "pi_PicoLadderElement.h"
#include "pi_PicoTransparentBrickElement.h"
#include "pi_PicoConveyorElement.h"
#include "pi_PicoBounceBedElement.h"
#include "pi_PicoBrickThrustElement.h"
#include "pi_PicoCoinLockerElement.h"
#include "pi_PicoDownLiftElement.h"
#include "pi_PicoButterBrickElement.h"
#include "pi_PicoTeleportGateElement.h"

// Element Operation
#include "pi_PicoElementCollection.h"
#include "pi_PicoElementSelectPanel.h"
#include "pi_PicoElementEditor.h"
#include "pi_PicoElementShowcase.h"
#include "pi_PicoPlayground.h"
// Levels
#include "pi_LevelCollection.h"
#include "pi_LevelSelector.h"
// Pages
#include "pi_Page.h"
#include "pi_PageMain.h"
#include "pi_PageLevelSelect.h"
#include "pi_PageMakeSelect.h"
#include "pi_PageGameCreate.h"
#include "pi_PagePlayground.h"
#include "pi_PageHandbook.h"

// 包含游戏头文件
#include "pi_Game.h"

