﻿#include "picoloop.h"

// Pico 旗帜元素类实现
namespace picoloop
{
    // 绘制旗帜元素
    void PicoFlagElement::draw() const
    {
        if (!_is_locked)
        {
            draw_unlocked();
        }
        else
        {
            draw_locked();
        }
    }

    // 绘制旗帜元素，已经解锁
    void PicoFlagElement::draw_unlocked() const
    {
        _get_bk_image(); // 获取背景图片
        setlinecolor(LIGHTRED);
        setlinestyle(PS_SOLID, 1);
        setfillcolor(RED); 
        POINT flag_points[5] = {
            _40x(1), _40y(1), _40x(39), _40y(1), _40x(25), _40y(16),
            _40x(39), _40y(31), _40x(1), _40y(31) };
        // 绘制旗面形状
        fillpolygon(flag_points, 5);
        // 绘制旗杆
        setlinecolor(LIGHTRED);
        setfillcolor(BROWN); 
        fillrectangle(_40x(1), _40y(1), _40x(7), _40y(39));
    }

    // 绘制旗帜元素，未解锁
    void PicoFlagElement::draw_locked() const
    {
        _get_bk_image(); // 获取背景图片
        setlinecolor(LIGHTGRAY);
        setlinestyle(PS_SOLID, 1);
        setfillcolor(DARKGRAY); 
        POINT flag_points[5] = {
            _40x(1), _40y(1), _40x(39), _40y(1), _40x(25), _40y(16),
            _40x(39), _40y(31), _40x(1), _40y(31) };
        // 绘制旗面形状
        fillpolygon(flag_points, 5);
        // 绘制旗杆
        setlinecolor(0x777777);
        setfillcolor(DARKGRAY);
        fillrectangle(_40x(1), _40y(1), _40x(7), _40y(39));
    }

    // 旗帜元素被碰到时触发的事件
    void PicoFlagElement::on_bump(PicoPlayer& player, bool occurred, bool first)
    {
        // 当旗帜元素被碰到时，根据是否解锁判断是否触发胜利事件
        if (occurred)
        {
            if (first && !_is_locked)
            {
                player.win();
            }
        }
        // 当没有碰到时，根据钥匙数量判断是否解锁
        else
        {
            if (player.keys_count() < player.keys_required())
            {
                // 玩家未收集足够的钥匙，旗帜元素变为锁定状态
                if (!_is_locked)
                {
                    _is_locked = true;
                    erase();
                    draw_locked();
                }
            }
            else
            {
                // 玩家收集了足够的钥匙，旗帜元素变为解锁状态
                if (_is_locked)
                {
                    _is_locked = false;
                    erase();
                    draw_unlocked();
                }
            }
        }
    }

    // 旗帜元素被踩时触发的事件
    void PicoFlagElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first && _is_locked)
            {
                player.disable_drop();
                player.enable_jump();
                _drop_disabled = true;
            }
            else if (!_is_locked && _drop_disabled)
            {
                player.enable_drop();
                player.disable_jump();
                _drop_disabled = false;
            }
        }
        else
        {
            if (first && _drop_disabled)
            {
                player.enable_drop();
                player.disable_jump();
                _drop_disabled = false;
            }
        }
    }

    // 旗帜元素被顶起时触发的事件
    void PicoFlagElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first && _is_locked)
            {
                player.stop_shift();
            }
        }
    }

    // 旗帜元素向左推动时触发的事件
    void PicoFlagElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first && _is_locked)
            {
                player.disable_move_left();
                _move_left_disabled = true;
            }
            else if (!_is_locked && _move_left_disabled)
            {
                player.enable_move_left();
                _move_left_disabled = false;
            }
        }
        else
        {
            if (first && _move_left_disabled)
            {
                player.enable_move_left();
                _move_left_disabled = false;
            }
        }
    }

    // 旗帜元素向右推动时触发的事件
    void PicoFlagElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first && _is_locked)
            {
                player.disable_move_right();
                _move_right_disabled = true;
            }
            else if (!_is_locked && _move_right_disabled)
            {
                player.enable_move_right();
                _move_right_disabled = false;
            }
        }
        else
        {
            if (first && _move_right_disabled)
            {
                player.enable_move_right();
                _move_right_disabled = false;
            }
        }
    }

    // 重置旗帜元素的数据
    void PicoFlagElement::reset_data()
    {
        base_reset(); // 调用基类的重置方法
        _is_locked = false;
        _drop_disabled = false; // 掉落是否禁用
        _move_left_disabled = false; // 向左推动是否禁用
        _move_right_disabled = false; // 向右推动是否禁用
    }
}