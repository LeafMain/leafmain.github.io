﻿#include "picoloop.h"
// Pico 元素集合类实现
namespace picoloop
{
	// 根据元素实例获取元素类型
	PicoElementCollection::TYPE PicoElementCollection::get_type(
		const PicoElement* element)
	{
		if (element == nullptr) return LENGTH;
		// 利用 typeid 运算符获取元素类型
		if (typeid(*element) == typeid(PicoEmptyElement))
			return EMPTY;
		if (typeid(*element) == typeid(PicoPlayerElement))
			return PLAYER;
		if (typeid(*element) == typeid(PicoKeyElement))
			return KEY;
		if (typeid(*element) == typeid(PicoFlagElement))
			return FLAG;
		if (typeid(*element) == typeid(PicoBrickElement))
			return BRICK;
		if (typeid(*element) == typeid(PicoFireElement))
			return FIRE;
		if (typeid(*element) == typeid(PicoCoinElement))
			return COIN;
		if (typeid(*element) == typeid(PicoSuperShoeElement))
			return SUPER_SHOE;
		if (typeid(*element) == typeid(PicoWingsElement))
			return WINGS;
		if (typeid(*element) == typeid(PicoPoisonElement))
			return POISON;
		if (typeid(*element) == typeid(PicoAntidoteElement))
			return ANTIDOTE;
		if (typeid(*element) == typeid(PicoStoneElement))
			return STONE;
		if (typeid(*element) == typeid(PicoRedStoneElement))
			return RED_STONE;
		if (typeid(*element) == typeid(PicoOrangeStoneElement))
			return ORANGE_STONE;
		if (typeid(*element) == typeid(PicoYellowStoneElement))
			return YELLOW_STONE;
		if (typeid(*element) == typeid(PicoGreenStoneElement))
			return GREEN_STONE;
		if (typeid(*element) == typeid(PicoCyanStoneElement))
			return CYAN_STONE;
		if (typeid(*element) == typeid(PicoBlueStoneElement))
			return BLUE_STONE;
		if (typeid(*element) == typeid(PicoPurpleStoneElement))
			return PURPLE_STONE;
		if (typeid(*element) == typeid(PicoWhiteStoneElement))
			return WHITE_STONE;
		if (typeid(*element) == typeid(PicoPinkStoneElement))
			return PINK_STONE;
		if (typeid(*element) == typeid(PicoOneUsedDoorElement))
			return ONE_USED_DOOR;
		if (typeid(*element) == typeid(PicoUpRightTubeElement))
			return UP_RIGHT_TUBE;
		if (typeid(*element) == typeid(PicoNoUpTubeElement))
			return NO_UP_TUBE;
		if (typeid(*element) == typeid(PicoUpLeftTubeElement))
			return UP_LEFT_TUBE;
		if (typeid(*element) == typeid(PicoNoLeftTubeElement))
			return NO_LEFT_TUBE;
		if (typeid(*element) == typeid(PicoIntersectTubeElement))
			return INTERSECT_TUBE;
		if (typeid(*element) == typeid(PicoNoRightTubeElement))
			return NO_RIGHT_TUBE;
		if (typeid(*element) == typeid(PicoDownRightTubeElement))
			return DOWN_RIGHT_TUBE;
		if (typeid(*element) == typeid(PicoNoDownTubeElement))
			return NO_DOWN_TUBE;
		if (typeid(*element) == typeid(PicoDownLeftTubeElement))
			return DOWN_LEFT_TUBE;
		if (typeid(*element) == typeid(PicoHorizontalTubeElement))
			return HORIZONTAL_TUBE;
		if (typeid(*element) == typeid(PicoVerticalTubeElement))
			return VERTICAL_TUBE;
		if (typeid(*element) == typeid(PicoSoilElement))
			return SOIL;
		if (typeid(*element) == typeid(PicoWaterElement))
			return WATER;
		if (typeid(*element) == typeid(PicoLadderElement))
			return LADDER;
		if (typeid(*element) == typeid(PicoTransparentBrickElement))
			return TRANSPARENT_BRICK;
		if (typeid(*element) == typeid(PicoLeftConveyorElement))
			return LEFT_CONVEYOR;
		if (typeid(*element) == typeid(PicoRightConveyorElement))
			return RIGHT_CONVEYOR;
		if (typeid(*element) == typeid(PicoBounceBedElement))
			return BOUNCE_BED;
		if (typeid(*element) == typeid(PicoUpBrickThrustElement))
			return UP_BRICK_THRUST;
		if (typeid(*element) == typeid(PicoDownBrickThrustElement))
			return DOWN_BRICK_THRUST;
		if (typeid(*element) == typeid(PicoLeftBrickThrustElement))
			return LEFT_BRICK_THRUST;
		if (typeid(*element) == typeid(PicoRightBrickThrustElement))
			return RIGHT_BRICK_THRUST;
		if (typeid(*element) == typeid(PicoCoinLockerElement))
			return COIN_LOCKER;
		if (typeid(*element) == typeid(PicoDownLiftElement))
			return DOWN_LIFT;
		if (typeid(*element) == typeid(PicoUpButterBrickElement))
			return UP_BUTTER_BRICK;
		if (typeid(*element) == typeid(PicoDownButterBrickElement))
			return DOWN_BUTTER_BRICK;
		if (typeid(*element) == typeid(PicoTeleportGateElement))
			return TELEPORT_GATE;
		return LENGTH; // 未知类型，用长度代替
	}

	// 根据元素类型创建元素实例
	PicoElement* PicoElementCollection::create(
		TYPE element_type, int x, int y, int size)
	{
		switch (element_type)
		{
		case EMPTY:
			return new PicoEmptyElement(x, y, size);
		case PLAYER:
			return new PicoPlayerElement(x, y, size);
		case KEY:
			return new PicoKeyElement(x, y, size);
		case FLAG:
			return new PicoFlagElement(x, y, size);
		case BRICK:
			return new PicoBrickElement(x, y, size);
		case FIRE:
			return new PicoFireElement(x, y, size);
		case COIN:
			return new PicoCoinElement(x, y, size);
		case SUPER_SHOE:
			return new PicoSuperShoeElement(x, y, size);
		case WINGS:
			return new PicoWingsElement(x, y, size);
		case POISON:
			return new PicoPoisonElement(x, y, size);
		case ANTIDOTE:
			return new PicoAntidoteElement(x, y, size);
		case STONE:
			return new PicoStoneElement(x, y, size);
		case RED_STONE:
			return new PicoRedStoneElement(x, y, size);
		case ORANGE_STONE:
			return new PicoOrangeStoneElement(x, y, size);
		case YELLOW_STONE:
			return new PicoYellowStoneElement(x, y, size);
		case GREEN_STONE:
			return new PicoGreenStoneElement(x, y, size);
		case CYAN_STONE:
			return new PicoCyanStoneElement(x, y, size);
		case BLUE_STONE:
			return new PicoBlueStoneElement(x, y, size);
		case PURPLE_STONE:
			return new PicoPurpleStoneElement(x, y, size);
		case WHITE_STONE:
			return new PicoWhiteStoneElement(x, y, size);
		case PINK_STONE:
			return new PicoPinkStoneElement(x, y, size);
		case ONE_USED_DOOR:
			return new PicoOneUsedDoorElement(x, y, size);
		case UP_RIGHT_TUBE:
			return new PicoUpRightTubeElement(x, y, size);
		case NO_UP_TUBE:
			return new PicoNoUpTubeElement(x, y, size);
		case UP_LEFT_TUBE:
			return new PicoUpLeftTubeElement(x, y, size);
		case NO_LEFT_TUBE:
			return new PicoNoLeftTubeElement(x, y, size);
		case INTERSECT_TUBE:
			return new PicoIntersectTubeElement(x, y, size);
		case NO_RIGHT_TUBE:
			return new PicoNoRightTubeElement(x, y, size);
		case DOWN_RIGHT_TUBE:
			return new PicoDownRightTubeElement(x, y, size);
		case NO_DOWN_TUBE:
			return new PicoNoDownTubeElement(x, y, size);
		case DOWN_LEFT_TUBE:
			return new PicoDownLeftTubeElement(x, y, size);
		case HORIZONTAL_TUBE:
			return new PicoHorizontalTubeElement(x, y, size);
		case VERTICAL_TUBE:
			return new PicoVerticalTubeElement(x, y, size);
		case SOIL:
			return new PicoSoilElement(x, y, size);
		case WATER:
			return new PicoWaterElement(x, y, size);
		case LADDER:
			return new PicoLadderElement(x, y, size);
		case TRANSPARENT_BRICK:
			return new PicoTransparentBrickElement(x, y, size);
		case LEFT_CONVEYOR:
			return new PicoLeftConveyorElement(x, y, size);
		case RIGHT_CONVEYOR:
			return new PicoRightConveyorElement(x, y, size);
		case BOUNCE_BED:
			return new PicoBounceBedElement(x, y, size);
		case UP_BRICK_THRUST:
			return new PicoUpBrickThrustElement(x, y, size);
		case DOWN_BRICK_THRUST:
			return new PicoDownBrickThrustElement(x, y, size);
		case LEFT_BRICK_THRUST:
			return new PicoLeftBrickThrustElement(x, y, size);
		case RIGHT_BRICK_THRUST:
			return new PicoRightBrickThrustElement(x, y, size);
		case COIN_LOCKER:
			return new PicoCoinLockerElement(x, y, size);
		case DOWN_LIFT:
			return new PicoDownLiftElement(x, y, size);
		case UP_BUTTER_BRICK:
			return new PicoUpButterBrickElement(x, y, size);
		case DOWN_BUTTER_BRICK:
			return new PicoDownButterBrickElement(x, y, size);
		case TELEPORT_GATE:
			return new PicoTeleportGateElement(x, y, size);
		default:
			return nullptr;
		}
	}

	// 判断元素是否为指定类型
	bool PicoElementCollection::same_type(
		const PicoElement* element, TYPE element_type)
	{
		return get_type(element) == element_type;
	}

	// 判断元素是否不是空元素
	bool PicoElementCollection::not_empty(const PicoElement* element)
	{ 
		return not_empty(get_type(element)); 
	}
}