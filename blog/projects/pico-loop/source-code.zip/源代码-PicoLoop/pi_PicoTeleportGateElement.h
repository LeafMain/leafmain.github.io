﻿#pragma once

// 对传送门元素类的声明
namespace picoloop
{
    /**
     * @brief 传送门元素类
     */
    class PicoTeleportGateElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制传送门元素
        */
        void draw() const override;
        /**
         * @brief 克隆传送门元素
         * @return 克隆出的 PicoTeleportGateElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override
        {
            return new PicoTeleportGateElement(*this);
        }
    protected:
        /**
        * @brief 传送门元素通过时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_through(PicoPlayer& player, bool occurred, bool first) override;
    };
}