﻿#pragma once

// Pico 元素展示类声明
namespace picoloop
{
	/**
	* @brief Pico 元素展示类
	*/
	class PicoElementShowcase
	{
	public:
		int x; // 展示框的 x 坐标
		int y; // 展示框的 y 坐标
		int size; // 展示框的大小
		int padding; // 展示框的内边距
		COLORREF border_color; // 展示框的边框颜色
		int border_width; // 展示框的边框宽度
		int border_type; // 展示框的边框类型
		/**
		* @brief Pico 元素展示类构造函数
		* @param x 展示框的 x 坐标，默认为 0
		* @param y 展示框的 y 坐标，默认为 0
		* @param size 展示框的大小，默认为 60
		* @param element_type 展示框的元素类型，默认为空元素
		* @param padding 展示框的内边距，默认为 10
		* @param border_color 展示框的边框颜色，默认为 WHITE
		* @param border_width 展示框的边框宽度，默认为 1
		* @param border_type 展示框的边框类型，默认为 PS_SOLID
		*/
		PicoElementShowcase(int x = 0, int y = 0, int size = 60, int padding = 10, 
			PicoElementCollection::TYPE element_type = PicoElementCollection::EMPTY,
			COLORREF border_color = WHITE, int border_width = 1, int border_type = PS_SOLID);
		/**
		* @brief Pico 元素展示类析构函数
		*/
		~PicoElementShowcase();
		/**
		* @brief Pico 元素展示类拷贝构造函数
		* @param other 要拷贝的 Pico 元素展示类
		*/
		PicoElementShowcase(const PicoElementShowcase& other);
		/**
		* @brief Pico 元素展示类赋值运算符
		* @param other 要赋值的 Pico 元素展示类
		*/
		PicoElementShowcase& operator=(const PicoElementShowcase& other);
		/**
		* @brief 绘制展示框及其元素
		*/
		void draw() const;
		/**
		* @brief 设置展示框的元素
		* @param element_type 要设置的元素类型
		* @param need_draw 是否立即绘制
		*/
		void set_element(PicoElementCollection::TYPE element_type, 
			bool need_draw = true);
		/**
		* @brief 获取展示框的元素类型
		* @return 展示框的元素类型
		*/
		[[nodiscard]] PicoElementCollection::TYPE element_type() const
		{ return _element_type; }
		/**
		* @brief 返回展示框的元素指针
		* @return 展示框的元素指针
		*/
		[[nodiscard]] PicoElement* get_element() const { return element; }
	private:
		PicoElement* element;
		PicoElementCollection::TYPE _element_type;
	};
}