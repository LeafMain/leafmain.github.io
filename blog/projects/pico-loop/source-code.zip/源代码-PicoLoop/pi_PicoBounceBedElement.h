﻿#pragma once

// 对蹦床类的声明
namespace picoloop
{
    /**
     * @brief 蹦床类
     */
    class PicoBounceBedElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制蹦床
        */
        void draw() const override;
        /**
        * @brief 绘制蹦床正常状态
        */
        void draw_normal() const;
        /**
        * @brief 绘制蹦床按压状态
        */
        void draw_pressed() const;
        /**
         * @brief 克隆蹦床
         * @return 克隆出的 PicoBounceBedElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoBounceBedElement(*this); }
    protected:
        /**
        * @brief 蹦床被踩时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 蹦床被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 蹦床向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 蹦床向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
    private:
        bool _is_pressed = false; // 蹦床是否被按压
    };
}