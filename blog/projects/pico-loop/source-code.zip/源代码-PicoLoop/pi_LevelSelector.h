﻿#pragma once

// 关卡选择器类声明
namespace picoloop
{
	/**
	* @brief 关卡选择器类
	*/
	class LevelSelector
	{
	public:
		/**
		* @brief 关卡选择器类构造函数
		* @param x 选择器左上角 x 坐标
		* @param y 选择器左上角 y 坐标
		* @param button_size 按钮大小
		* @param cr 按钮圆角半径
		* @param button_gap 按钮间隔
		* @param level_limit 关卡数量限制
		* @param button_background_color 按钮颜色
		* @param button_border_color 按钮边框颜色
		* @param button_text_color 按钮文字颜色
		* @param button_hover_color 按钮悬停颜色
		* @param button_select_color 按钮选中颜色
		*/
		LevelSelector(int x = 0, int y = 0, int button_size = 80,
			int cr = 5, int button_gap = 20, int level_limit = LEVEL_COUNT,
			COLORREF button_background_color = 0xFFFF00,
			COLORREF button_border_color = 0x00FFFF,
			COLORREF button_text_color = 0x000000,
			COLORREF button_hover_color = 0x00FF00,
			COLORREF button_select_color = 0x00FFFF,
			COLORREF level_passed_color = 0x0000FF);

		static constexpr int ROW = 7;  // 行数
		static constexpr int COLUMN = 12;  // 列数
		static constexpr int LEVEL_COUNT = ROW * COLUMN;  // 关卡数量
		int x; // 选择器左上角 x 坐标
		int y; // 选择器左上角 y 坐标
		int cr; // 按钮圆角半径
		int button_size; // 按钮大小
		int button_gap; // 按钮间隔
		COLORREF button_background_color; // 按钮颜色
		COLORREF button_text_color; // 按钮文字颜色
		COLORREF button_border_color; // 按钮边框颜色
		COLORREF button_hover_color; // 按钮悬停颜色
		COLORREF button_select_color; // 按钮选中颜色
		COLORREF level_passed_color; // 已通过关卡颜色
		/**
		* @brief 获取选择器宽度
		*/
		[[nodiscard]] int get_width() const
		{ return x + button_size * COLUMN + button_gap * (COLUMN - 1); }
		/**
		* @brief 获取选择器高度
		*/
		[[nodiscard]] int get_height() const
		{ return y + button_size * ROW + button_gap * (ROW - 1); }
		/**
		* @brief 绘制关卡选择器
		*/
		void draw() const;
		/**
		* @brief 判断是否选中了某个关卡
		* @param level 关卡编号
		*/
		[[nodiscard]] bool selected(int level, ExMessage& event) const;
		/**
		* @brief 监听鼠标悬停事件
		* @param event 事件
		*/
		void listen_hover(ExMessage& event);
		/**
		* @brief 监听鼠标选中事件
		* @param event 事件
		*/
		void listen_select(ExMessage& event);
		/**
		* @brief 设置关卡数量限制
		* @param limit 关卡数量限制
		*/
		void set_level_limit(int limit) { _level_limit = limit; }
		/**
		* @brief 获取关卡数量限制
		*/
		[[nodiscard]] int level_limit() const { return _level_limit; }
		/**
		* @brief 设置某个关卡是否通过
		* @param level 关卡编号
		* @param passed 是否通过， 默认为 true
		* @param redraw 是否重绘， 默认为 true
		*/
		void set_passed(int level, bool passed = true, bool redraw = true);
	private:
		using LevelButton = RectButton;
		LevelButton levels[ROW][COLUMN];
		int _level_limit; // 关卡数量限制
	};
}