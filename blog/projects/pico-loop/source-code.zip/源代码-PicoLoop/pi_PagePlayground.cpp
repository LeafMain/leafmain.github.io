﻿#include "picoloop.h"

// 游戏广场页面类静态常量定义
namespace picoloop
{
	const COLORREF PagePlayground::COLOR::BORDER = LIGHTGRAY; // 边框颜色
	const COLORREF PagePlayground::COLOR::BACKGROUND = 0x111111; // 背景颜色
	const COLORREF PagePlayground::COLOR::BUTTON_BACK = LIGHTGRAY; // 返回按钮颜色
	const COLORREF PagePlayground::COLOR::BUTTON_BACK_HOVER = DARKGRAY; // 返回按钮鼠标悬停颜色
	const COLORREF PagePlayground::COLOR::BUTTON_PAUSE = LIGHTCYAN; // 暂停按钮颜色
	const COLORREF PagePlayground::COLOR::BUTTON_PAUSE_HOVER = 0x888800; // 暂停按钮鼠标悬停颜色
	const COLORREF PagePlayground::COLOR::BUTTON_REPLAY = 0x00DD00; // 重玩按钮颜色
	const COLORREF PagePlayground::COLOR::BUTTON_REPLAY_HOVER = 0x008000; // 重玩按钮鼠标悬停颜色
	const COLORREF PagePlayground::COLOR::BUTTON_PRINT_SCREEN = 0x0000DD; // 截图按钮颜色
	const COLORREF PagePlayground::COLOR::BUTTON_PRINT_SCREEN_HOVER = 0x000080; // 截图按钮鼠标悬停颜色
	const COLORREF PagePlayground::COLOR::BUTTON_HELP = 0x008080; // 帮助按钮颜色
	const COLORREF PagePlayground::COLOR::BUTTON_HELP_HOVER = 0x006060; // 帮助按钮鼠标悬停颜色
	const COLORREF PagePlayground::COLOR::BUTTON_OPERATE = 0xCCCCCC; // 操作按钮颜色
	const COLORREF PagePlayground::COLOR::BUTTON_OPERATE_HOVER = 0xAAAAAA; // 操作按钮鼠标悬停颜色
	const COLORREF PagePlayground::COLOR::SHORTCUTS = LIGHTGRAY; // 快捷键提示颜色
	const COLORREF PagePlayground::COLOR::STATUS_TEXT = 0xFFFF00; // 状态文字颜色
	const COLORREF PagePlayground::COLOR::LEVEL_NAME = 0xFFFFFF; // 关卡名称颜色
	const COLORREF PagePlayground::COLOR::RUN_TIME = LIGHTRED; // 游戏时间颜色
	const COLORREF PagePlayground::COLOR::REST_LIVES = GREEN; // 玩家生命值颜色
	const COLORREF PagePlayground::COLOR::KEYS_COUNT = YELLOW; // 钥匙数量颜色
	const COLORREF PagePlayground::COLOR::COINS_COUNT = YELLOW; // 金币数量颜色
	const COLORREF PagePlayground::COLOR::LEFT_SIDE_BORDER = LIGHTGRAY; // 左侧边框颜色
	const LPCTSTR PagePlayground::FONT::BUTTON_FONT = _T("Arial Rounded MT Bold"); // 按钮字体
	const LPCTSTR PagePlayground::FONT::SHORTCUTS_FONT = _T("Arial"); // 快捷键提示字体
	const LPCTSTR PagePlayground::FONT::STATUS_FONT = BUTTON_FONT; // 状态文字字体
	const LPCTSTR PagePlayground::FONT::LEFT_SIDE_FONT = _T("Arial"); // 关卡名称字体
	const LPCTSTR PagePlayground::FONT::OPERATE_FONT = _T("Arial"); // 操作按钮字体
	const int PagePlayground::COUNT::PLAYER_LIVES = 5; // 玩家生命数量
}

// 游戏广场页面类实现
namespace picoloop
{
	// 游戏广场页面类构造函数
	PagePlayground::PagePlayground(Game& game) :
		Page(game),
		playground(game.page_game_create.get_element_editor()),
		title_left(6, 20, 0.2),
		title_right(1107, 30, 0.2),
		player_icon(1122, 285, 56),
		button_back{ // 开始按钮
			1110, 75, 80, 50, 2, 2, 31, 1, PS_SOLID,
			_T("Back"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_BACK, COLOR::BUTTON_BACK, COLOR::BACKGROUND,
			COLOR::BUTTON_BACK_HOVER, COLOR::BUTTON_BACK_HOVER
		}, button_pause{ // 暂停按钮
			1110, 135, 80, 50, 2, 2, 28, 1, PS_SOLID,
			_T("Pause"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_PAUSE, COLOR::BUTTON_PAUSE, COLOR::BACKGROUND,
			COLOR::BUTTON_PAUSE_HOVER, COLOR::BUTTON_PAUSE_HOVER
		}, button_replay{ // 重玩按钮
			1110, 195, 80, 50, 2, 2, 26, 1, PS_SOLID,
			_T("Replay"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_REPLAY, COLOR::BUTTON_REPLAY, COLOR::BACKGROUND,
			COLOR::BUTTON_REPLAY_HOVER, COLOR::BUTTON_REPLAY_HOVER
		}, button_print_screen{ // 截图按钮
			1110, 675, 80, 50, 2, 2, 26, 1, PS_SOLID,
			_T("Prt Sc"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_PRINT_SCREEN, COLOR::BUTTON_PRINT_SCREEN, COLOR::BACKGROUND,
			COLOR::BUTTON_PRINT_SCREEN_HOVER, COLOR::BUTTON_PRINT_SCREEN_HOVER
		}, button_help{ // 帮助按钮
			1110, 735, 80, 50, 2, 2, 31, 1, PS_SOLID,
			_T("Help"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_HELP, COLOR::BUTTON_HELP, COLOR::BACKGROUND,
			COLOR::BUTTON_HELP_HOVER, COLOR::BUTTON_HELP_HOVER
		}, button_player_jump{ // 玩家跳跃按钮
			5, 580, 90, 90, 2, 2, 32, 1, PS_SOLID,
			_T("Jump"), FONT::OPERATE_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_OPERATE, COLOR::BUTTON_OPERATE, COLOR::BACKGROUND,
			COLOR::BUTTON_OPERATE_HOVER, COLOR::BUTTON_OPERATE_HOVER
		}, button_player_left{ // 玩家左移按钮
			5, 470, 90, 90, 2, 2, 32, 1, PS_SOLID,
			_T("Left"), FONT::OPERATE_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_OPERATE, COLOR::BUTTON_OPERATE, COLOR::BACKGROUND,
			COLOR::BUTTON_OPERATE_HOVER, COLOR::BUTTON_OPERATE_HOVER
		}, button_player_right{ // 玩家右移按钮
			5, 690, 90, 90, 2, 2, 32, 1, PS_SOLID,
			_T("Right"), FONT::OPERATE_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_OPERATE, COLOR::BUTTON_OPERATE, COLOR::BACKGROUND,
			COLOR::BUTTON_OPERATE_HOVER, COLOR::BUTTON_OPERATE_HOVER
		}
	{}

	// 游戏广场页面类析构函数
	PagePlayground::~PagePlayground()
	{
		// 必须释放由 _tcsdup 申请的内存
		std::free(_level_name_text);
		std::free(_rest_lives_text);
	}

	// 绘制页面
	void PagePlayground::draw_page() const
	{
		_draw_border(); // 绘制边框
		_draw_shortcuts(); // 绘制快捷键提示
		_draw_level_name(); // 绘制关卡名称
		_draw_rest_lives(); // 绘制玩家生命值
		_draw_keys_count(); // 绘制钥匙数量
		_draw_coins_count(); // 绘制金币数量
		playground.draw();
		// 绘制标题
		title_left.draw();
		title_right.draw();
		// 绘制按钮
		button_back.draw();
		button_pause.draw();
		button_replay.draw();
		button_print_screen.draw();
		button_help.draw();
		button_player_jump.draw();
		button_player_left.draw();
		button_player_right.draw();
		// 绘制玩家图标
		player_icon.draw();
	}

	// 进入页面时调用
	void PagePlayground::on_enter()
	{
		// 取消系统休眠
		game.set_sleep_time(0);
		// 如果自动开始游戏，则开始游戏
		if (_auto_play)
		{
			playground.reload_editor_data();
			_reset(); // 重置页面参数
			playground.play();
		}
		else
		{
			playground.resume(); // 恢复游戏
			playground.play();
			// 下次进入才自动开始游戏
			_auto_play = true; 
		}
	}

	// 离开页面时调用
	void PagePlayground::on_leave()
	{
		// 恢复系统休眠
		game.set_sleep_time(Game::DEFUALT_SLEEP_TIME);
		playground.stop();
	}

	// 退出页面
	void PagePlayground::exit_page()
	{
		playground.resume(); // 恢复游戏
		// 如果没有设置上一页面，则正常退出
		if (_prev_page == nullptr)
		{
			enter(previous_page());
		}
		// 否则，返回设置的上一页面
		else
		{
			enter(_prev_page);
			_prev_page = nullptr;
		}
	}

	// 切换暂停和继续状态
	void PagePlayground::toggle_pause()
	{
		// 如果游戏已经结束，则不允许切换状态
		if (playground.player_died() || playground.player_won())
		{
			return;
		}
		// 如果游戏暂停，则继续游戏，否则暂停游戏
		if (playground.paused())
		{
			playground.resume();
			_draw_status_text(_T(""));
			if (game.sleep_time() != 0) // 切换至性能模式
			{
				game.set_sleep_time(0);
			}
		}
		else
		{
			playground.pause();
			_draw_status_text(_T("Paused"));
			// 切换至能效模式
			if (game.sleep_time() == 0)
			{
				game.set_sleep_time(Game::DEFUALT_SLEEP_TIME);
			}
		}
	}

	// 重玩游戏
	void PagePlayground::replay()
	{
		_reset(); // 重置页面参数
		playground.replay();
	}

	// 截图
	void PagePlayground::print_screen()
	{
		int x = playground.get_x();
		int y = playground.get_y();
		int width = playground.get_width();
		int height = playground.get_height();
		// 创建图像对象
		IMAGE image;
		// 获得图像数据
		getimage(&image, x, y, width, height);
		// 获得当前时间戳和毫秒，经处理后作为文件名
		int time_stamp = static_cast<int>(time(nullptr) % 1000000);
		int milli = static_cast<int>(std::clock() % 1000);
		TCHAR dir_name[96]{}; // 目录路径
		TCHAR file_name[96]{}; // 文件路径
		TCHAR dir_format[] = _T("%s\\PrtSc\\"); // 目录格式
		TCHAR file_format[] = _T("%s\\PrtSc\\%06d%03d.bmp"); // 文件格式
		// 获得目录路径字符串
		_stprintf_s(dir_name, _countof(dir_name), dir_format, 
			game.parent_path_t());
		// 获取目录属性
		auto attr = GetFileAttributes(dir_name);
		// 如果目录不存在，则创建
		if (attr == INVALID_FILE_ATTRIBUTES || 
			!(attr & FILE_ATTRIBUTE_DIRECTORY))
		{
			game.create_directories();
		}
		// 获得文件路径字符串
		_stprintf_s(file_name, _countof(file_name), file_format,
			game.parent_path_t(), time_stamp, milli);
		// 保存图像数据
		saveimage(file_name, &image);
		_screen_will_be_printed = true;
	}

	// 进入帮助页面
	void PagePlayground::enter_help()
	{
		// 如果游戏已经结束，则不允许进入帮助页面
		if (playground.player_died() || playground.player_won())
		{
			return;
		}
		playground.pause(); // 暂停游戏
		prevent_auto_play_once();
		// 切换到帮助页面
		game.page_handbook.enter();
	}

	// 设置关卡名称
	void PagePlayground::set_level_name(LPCTSTR name)
	{
		free(_level_name_text);
		_level_name_text = _tcsdup(name);
		if (current_page() == this)
		{
			_draw_level_name();
		}
	}

	// 重置页面参数
	void PagePlayground::_reset()
	{
		// 重置游戏参数
		_player_died = false;
		_player_will_die = false;
		_player_won = false;
		_player_will_win = false;
		_screen_will_be_printed = false;
		_screen_printed = false;
		_keys_count = 0;
		_coins_count = 0;
		_run_time_clock = std::clock();
		_player_win_clock = _run_time_clock;
		_player_die_clock = _run_time_clock;
		_screen_print_clock = _run_time_clock;
		_run_time_minutes = 0;
		_run_time_seconds = 0;
		_draw_status_text(_T(""));
		_draw_run_time(_T("00:00"));
		_draw_keys_count();
		_draw_coins_count();
		player_icon.reset_data();
		player_icon.draw_buff_none();
	}

	// 绘制边框
	void PagePlayground::_draw_border() const
	{
		setlinecolor(COLOR::BORDER);
		setlinestyle(PS_SOLID, 1);
		line(99, 0, 99, Window::HEIGHT);
		line(1101, 0, 1101, Window::HEIGHT);
	}

	// 绘制状态文字
	void PagePlayground::_draw_status_text(LPCTSTR text) const
	{
		RECT rect = { 1110, 250, 1195, 290 };
		setbkmode(TRANSPARENT);
		setfillcolor(COLOR::BACKGROUND);
		solidrectangle(rect.left, rect.top, rect.right, rect.bottom);
		settextcolor(COLOR::STATUS_TEXT);
		settextstyle(25, 0, FONT::STATUS_FONT);
		drawtext(text, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}

	// 绘制快捷键提示
	void PagePlayground::_draw_shortcuts() const
	{
		settextcolor(COLOR::SHORTCUTS);
		settextstyle(17, 0, FONT::SHORTCUTS_FONT);
		RECT rect = { 1110, 350, 1195, 670 };
		LPCTSTR text = _T(
			"Esc: Back\n\n"
			"Space: Pause\n"
			"R: Replay\n\n"
			"LeftArrow: Move Left\n\n"
			"RightArrow: Move Right\n\n"
			"UpArrow: Jump\n\n"
			"H: Help\n\n"
			"P: Print Scr\n\n"
		);
		drawtext(text, &rect, DT_CENTER | DT_WORDBREAK);
	}

	// 绘制关卡名称
	void PagePlayground::_draw_level_name() const
	{
		settextcolor(COLOR::LEVEL_NAME);
		settextstyle(25, 0, FONT::LEFT_SIDE_FONT);
		RECT rect = { 2, 50, 98, 150 };
		setlinecolor(COLOR::LEFT_SIDE_BORDER);
		setlinestyle(PS_SOLID, 1);
		rectangle(rect.left, rect.top, rect.right, rect.bottom);
		drawtext(_level_name_text, &rect, DT_CENTER | DT_WORDBREAK);
	}

	// 绘制游戏时间
	void PagePlayground::_draw_run_time(LPCTSTR time) const
	{
		settextcolor(COLOR::RUN_TIME);
		settextstyle(33, 0, FONT::LEFT_SIDE_FONT);
		RECT rect = { 2, 150, 98, 200 };
		setlinecolor(COLOR::RUN_TIME);
		setlinestyle(PS_SOLID, 1);
		setfillcolor(COLOR::BACKGROUND);
		solidrectangle(rect.left + 4, rect.top + 4, 
			rect.right - 4, rect.bottom - 4);
		rectangle(rect.left, rect.top, rect.right, rect.bottom);
		drawtext(time, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}

	// 绘制玩家生命值
	void PagePlayground::_draw_rest_lives() const
	{
		settextcolor(COLOR::REST_LIVES);
		settextstyle(30, 0, FONT::LEFT_SIDE_FONT);
		RECT rect = { 2, 200, 98, 260 };
		setlinecolor(COLOR::REST_LIVES);
		setlinestyle(PS_SOLID, 1);
		rectangle(rect.left, rect.top, rect.right, rect.bottom);
		drawtext(_rest_lives_text, &rect, DT_CENTER | DT_WORDBREAK);
	}

	// 绘制钥匙数量
	void PagePlayground::_draw_keys_count() const
	{
		settextcolor(COLOR::KEYS_COUNT);
		settextstyle(23, 0, FONT::LEFT_SIDE_FONT);
		RECT rect = { 5, 270, 95, 320 };
		// 擦除原来的数字
		setfillcolor(COLOR::BACKGROUND);
		solidrectangle(rect.left + 2, rect.top + 2, 
			rect.right - 2, rect.bottom - 2);
		// 绘制新的数字
		TCHAR count[12] = _T("");
		TCHAR text[20] = _T("Keys: ");
		_itot_s(_keys_count, count, _countof(count), 10);
		_tcsncat_s(text, _countof(text), count, 10);
		drawtext(text, &rect, DT_VCENTER | DT_SINGLELINE);
	}

	//  绘制金币数量
	void PagePlayground::_draw_coins_count() const
	{
		settextcolor(COLOR::COINS_COUNT);
		settextstyle(21, 0, FONT::LEFT_SIDE_FONT);
		RECT rect = { 5, 320, 95, 370 };
		// 擦除原来的数字
		setfillcolor(COLOR::BACKGROUND);
		solidrectangle(rect.left + 2, rect.top + 2,
			rect.right - 2, rect.bottom - 2);
		// 绘制新的数字
		TCHAR count[12] = _T("");
		TCHAR text[20] = _T("Coins: ");
		_itot_s(_coins_count, count, _countof(count), 10);
		_tcsncat_s(text, _countof(text), count, 10);
		drawtext(text, &rect, DT_VCENTER | DT_SINGLELINE);
	}

	// 更新游戏时间
	void PagePlayground::_update_run_time()
	{
		// 暂停时不更新游戏时间
		if (playground.paused()) return;
		// 页面不在前台时不更新游戏时间
		if (current_page() != this) return;
		std::clock_t now = std::clock();
		// 每秒更新一次游戏时间
		if (double(now - _run_time_clock) / CLOCKS_PER_SEC >= 1.0)
		{
			_run_time_seconds++;
			if (_run_time_seconds >= 60)
			{
				_run_time_seconds = 0;
				_run_time_minutes++;
			}
			// 时间超出 99 分钟，游戏结束
			if (_run_time_minutes > 99)
			{
				_run_time_minutes = 0;
				_run_time_seconds = 0;
				replay();
			}
			// 将时间转换为字符串
			TCHAR m_text[5] = _T("");
			TCHAR s_text[5] = _T("");
			TCHAR time_str[12] = _T("");
			// 将分钟和秒转换为字符串
			_itot_s(_run_time_minutes, m_text, _countof(m_text), 10);
			_itot_s(_run_time_seconds, s_text, _countof(s_text), 10);
			// 如果时间小于 10 分钟，前面补 0
			if (_run_time_minutes < 10)
			{
				_tcsncat_s(time_str, _countof(time_str), _T("0"), 10);
			}
			_tcsncat_s(time_str, _countof(time_str), m_text, 10);
			_tcsncat_s(time_str, _countof(time_str), _T(":"), 10);
			// 如果时间小于 10 秒，前面补 0
			if (_run_time_seconds < 10)
			{
				_tcsncat_s(time_str, _countof(time_str), _T("0"), 10);
			}
			_tcsncat_s(time_str, _countof(time_str), s_text, 10);
			_draw_run_time(time_str); // 绘制游戏时间
			_run_time_clock = now;
		}
	}

	// 更新物资数量
	void PagePlayground::_update_items_count()
	{
		// 页面不在前台时不更新物资数量
		if (current_page() != this) return;
		int keys = playground.player_keys_count();
		int coins = playground.player_coins_count();
		// 如果钥匙数量变化，更新钥匙数量
		if (keys != _keys_count)
		{
			_keys_count = keys;
			_draw_keys_count();
		}
		// 如果金币数量变化，更新金币数量
		if (coins != _coins_count)
		{
			_coins_count = coins;
			_draw_coins_count();
		}
	}

	// 保存已通过的关卡
	void PagePlayground::_save_passed_levels() const
	{
		// 关卡不在范围内，不保存
		if (_level_number < 1 || 
			_level_number > LevelCollection::LEVEL_LIMIT)
		{
			return;
		}
		// 关卡重复通过时不保存
		if (LevelCollection::passed_levels().count(_level_number))
		{
			return;
		}
		// 将关卡保存到文件
		LevelCollection::set_passed(_level_number);
		std::string path = std::string(game.parent_path()) + 
			std::string("\\Data\\Levels");
		std::ofstream file(path);
		if (!file)
		{
			// 创建目录
			game.create_directories();
			return;
		}
		for (int level : LevelCollection::passed_levels())
		{
			file << level << ' ';
		}
		file.close();
	}

	// 监听鼠标事件
	void PagePlayground::_listen_mouse(ExMessage& event)
	{
		// 当鼠标移动到按钮区域时，监听按钮悬停事件
		if (event.x >= 1100)
		{
			button_back.listen_hover(event);
			button_pause.listen_hover(event);
			button_replay.listen_hover(event);
			button_print_screen.listen_hover(event);
			button_help.listen_hover(event);
		}
		else if (event.x <= 100)
		{
			button_player_jump.listen_hover(event);
			button_player_left.listen_hover(event);
			button_player_right.listen_hover(event);
		}
		// 当按下鼠标左键时
		if (event.message == WM_LBUTTONDOWN)
		{
			// 点击返回按钮
			if (button_back.clicked(event))
			{
				exit_page();
			}
			// 点击暂停按钮
			else if (button_pause.clicked(event))
			{
				toggle_pause();
				button_pause.listen_hover(event);
			}
			// 点击重玩按钮
			else if (button_replay.clicked(event))
			{
				replay();
			}
			// 点击截图按钮
			else if (button_print_screen.clicked(event))
			{
				print_screen();
			}
			// 点击帮助按钮
			else if (button_help.clicked(event))
			{
				enter_help();
			}
			event.message = WM_KEYDOWN; // 处理完事件，转为键盘事件
		}
		else if (event.message == WM_RBUTTONDOWN)
		{
			// 右击截图按钮，打开截图保存的目录
			if (button_print_screen.in_area(event.x, event.y))
			{
				// 暂停游戏
				if (!playground.paused())
				{
					toggle_pause();
				}
				TCHAR dir[128] = _T("");
				_tcsncat_s(dir, _countof(dir), game.parent_path_t(), 128);
				_tcsncat_s(dir, _countof(dir), _T("\\PrtSc"), 128);
				auto ins = ShellExecute(GetHWnd(), _T("open"), 
					dir, NULL, NULL, SW_SHOW);
				// 目录不存在，创建目录
				if (INT_PTR(ins) <= 32)
				{
					game.create_directories();
				}
			}
			event.message = WM_KEYDOWN; // 处理完事件，转为键盘事件
		}
	}

	// 监听键盘事件
	void PagePlayground::_listen_keyboard(ExMessage& event)
	{
		// 监听键盘事件
		if (event.message == WM_KEYDOWN)
		{
			if (!event.prevdown)
			{
				switch (event.vkcode)
				{
					// 按下 Esc 键返回上一页
				case VK_ESCAPE:
					exit_page();
					break;
					// 按下空格键暂停游戏
				case VK_SPACE:
					toggle_pause();
					break;
					// 按下 R 键或 backspace 重玩游戏
				case 'r':
				case 'R':
				case VK_BACK:
					replay();
					break;
					// 按下 P 键截图
				case 'p':
				case 'P':
					print_screen();
					break;
					// 按下 H 键进入帮助页面
				case 'h':
				case 'H':
					enter_help();
					break;
					// 暂停时，按下三个方向键中的任意一个继续
				case VK_LEFT:
				case VK_RIGHT:
				case VK_UP:
					if (playground.paused())
					{
						toggle_pause();
					}
					break;
				}
				event.message = WM_MOUSEMOVE; // 处理完事件
			}
		}
	}

	// 监听移动事件
	void PagePlayground::_listen_move(ExMessage& event)
	{
		// 当窗口失去焦点或最小化时不监听
		if (event.wParam == Window::KILL_FOCUS ||
			event.wParam == Window::MINIMIZE)
		{
			if (!playground.paused())
			{
				toggle_pause();
			}
			return;
		}
		// 否则当非暂停并且进入效能模式时，切换至性能模式
		else if (game.sleep_time() != 0 && !playground.paused())
		{
			game.set_sleep_time(0);
		}
		// 如果鼠标在左侧栏，则同时监听移动按钮按下事件
		if (event.x <= 100)
		{
			playground.listen_event(event,
				button_player_jump.pressed(event),
				button_player_left.pressed(event),
				button_player_right.pressed(event)
			);
		}
		// 如果鼠标在右侧栏，则只监听游戏键盘事件
		else
		{
			playground.listen_event(event);
		}
	}

	// 监听玩家事件
	void PagePlayground::_listen_player(std::clock_t ev_clock)
	{
		// 监听玩家人物死亡
		if (playground.player_died())
		{
			// 玩家人物死亡，1 秒后重新开始游戏
			if (!_player_died)
			{
				if (!_player_will_die)
				{
					_draw_status_text(_T("Died"));
					playground.pause();
					_player_will_die = true;
					player_icon.draw_died();
				}
				std::clock_t now = std::clock();
				if (now - _player_die_clock >= 1000)
				{
					_player_died = true;
					_player_die_clock = now;
					replay();
				}
			}
		}
		else
		{
			_player_die_clock = ev_clock; // 玩家存活，重置计时器
			if (player_icon.get_buff() != playground.player_buff())
			{
				player_icon.set_buff(playground.player_buff());
			}
		}
		// 监听玩家胜利
		if (playground.player_won())
		{
			// 玩家胜利，2 秒后退出页面
			if (!_player_died)
			{
				if (!_player_will_win)
				{
					_draw_status_text(_T("Won!"));
					playground.pause();
					_player_will_win = true;
					// 保存数据
					_save_passed_levels();
				}
				std::clock_t now = std::clock();
				if (now - _player_win_clock >= 2000)
				{
					_player_won = true;
					_player_win_clock = now;
					// 退出页面
					exit_page();
				}
			}
		}
		else
		{
			_player_win_clock = ev_clock; // 玩家存活，重置计时器
		}
	}

	// 监听截图事件
	void PagePlayground::_listen_screen_print(std::clock_t ev_clock)
	{
		if (_screen_will_be_printed)
		{
			if (!_screen_printed)
			{
				_draw_status_text(_T("Printed")); // 绘制状态文字
				_screen_printed = true; // 已经绘制
			}
			std::clock_t now = std::clock(); // 重置计时器
			// 1.5 秒后，清除状态文字
			if (now - _screen_print_clock >= 1500)
			{
				// 如果暂停了，则继续暂停
				if (playground.paused())
				{
					_draw_status_text(_T("Paused"));
				}
				// 否则，清除状态文字
				else
				{
					_draw_status_text(_T(""));
				}
				_screen_printed = true; // 截图结束
				_screen_print_clock = now; // 重置计时器
			}
		}
		else
		{
			_screen_print_clock = ev_clock; // 不断更新计时器
		}
	}

	// 监听页面事件
	void PagePlayground::listen_event(ExMessage& event)
	{
		clock_t ev_clock = std::clock(); // 记录事件发生时间
		_listen_move(event);
		 // 监听游戏事件
		_listen_mouse(event); // 监听鼠标事件
		_listen_keyboard(event); // 监听键盘事件
		_listen_player(ev_clock); // 监听玩家事件
		_listen_screen_print(ev_clock); // 监听截图事件
		_update_run_time(); // 更新游戏时间
		_update_items_count(); // 更新物资数量
	}
}