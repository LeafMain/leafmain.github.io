﻿#pragma once

// Pico 空元素类声明
namespace picoloop
{
	/**
	 * @brief Pico 空元素类
	 * @note 空元素类，用于表示空白位置，不占用任何空间，仅用于占位。
	 */
	class PicoEmptyElement : public PicoElement
	{
	public:
		using PicoElement::PicoElement;
		/**
		 * @brief 绘制空元素
		 */
		void draw() const override;

		/**
		 * @brief 判断是否为空元素
		 * @return true，PicoEmptyElement 为空元素，始终返回 true；
		 */
		bool is_empty() const override { return true; }

		/**
		 * @brief 克隆空元素
		 * @return 克隆出的 PicoEmptyElement 实例
		 */
		[[nodiscard]] PicoElement* clone() const override
		{ return new PicoEmptyElement(*this); }
	};
}