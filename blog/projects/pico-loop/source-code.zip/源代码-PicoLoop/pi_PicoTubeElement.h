﻿#pragma once

// 对管道元素类的声明
namespace picoloop
{
    /**
    * @brief 管道元素抽象类
    * @brief 子类必须实现 PicoElement 需要实现的方法
    * @note 该类前加下划线是为了避免误将其当作具体的管道元素类使用
    */
    class _PicoTubeElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
    protected:
        static const COLORREF BACKGROUND_COLOR; // 背景色
        static const COLORREF RECTANGLE_COLOR; // 矩形色
        static const int RECTANGLE_WIDTH; // 矩形宽度
        /**
        * @brief 绘制管道元素的背景
        */
        void draw_background() const;
        /**
        * @brief 绘制管道元素左上角的矩形
        */
        void draw_up_left_rect() const;
        /**
        * @brief 绘制管道元素右上角的矩形
        */
        void draw_up_right_rect() const;
        /**
        * @brief 绘制管道元素左下角的矩形
        */
        void draw_down_left_rect() const;
        /**
        * @brief 绘制管道元素右下角的矩形
        */
        void draw_down_right_rect() const;
        /**
        * @brief 绘制管道元素上部的矩形
        */
        void draw_up_rect() const;
        /**
        * @brief 绘制管道元素下部的矩形
        */
        void draw_down_rect() const;
        /**
        * @brief 绘制管道元素左侧的矩形
        */
        void draw_left_rect() const;
        /**
        * @brief 绘制管道元素右侧的矩形
        */
        void draw_right_rect() const;
        /**
        * @brief 处理踩事件
        */
        void handle_pedal(PicoPlayer& player, bool occurred, bool first);
        /**
        * @brief 处理顶起事件
        */
        void handle_jump(PicoPlayer& player, bool occurred, bool first);
        /**
        * @brief 处理向左推动事件
        */
        void handle_push_left(PicoPlayer& player, bool occurred, bool first);
        /**
        * @brief 处理向右推动事件
        */
        void handle_push_right(PicoPlayer& player, bool occurred, bool first);
    };

    /**
    * @brief 左上角管道元素类
    */
    class PicoUpRightTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制左上角管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆左上角管道元素
         * @return 克隆出的 PicoUpLeftTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoUpRightTubeElement(*this); }
    protected:
        /**
        * @brief 左上角管道元素被踩时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 左上角管道元素被顶起且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 左上角管道元素向左推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 左上角管道元素向右推动且未对齐
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 左上角管道元素左侧内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 左上角管道元素顶部内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_top(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
    * @brief 无向上管道元素类
    */
    class PicoNoUpTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制无向上管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆无向上管道元素
         * @return 克隆出的 PicoNoUpTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoNoUpTubeElement(*this); }
    protected:
        /**
        * @brief 无向上管道元素被踩时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向上管道元素被顶起且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向上管道元素向左推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向上管道元素向右推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向上管道元素左侧内壁被触碰且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_touch_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向上管道元素顶部内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_top(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
    * @brief 右上角管道元素类
    */
    class PicoUpLeftTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制右上角管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆右上角管道元素
         * @return 克隆出的 PicoUpRightTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoUpLeftTubeElement(*this); }
    protected:
        /**
        * @brief 右上角管道元素被踩时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 右上角管道元素被顶起且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 右上角管道元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 右上角管道元素向右推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 右上角管道元素顶部内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_top(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 右上角管道元素右侧内壁被触碰触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_right(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
    * @brief 无向左管道元素类
    */
    class PicoNoLeftTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制无向左管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆无向左管道元素
         * @return 克隆出的 PicoNoLeftTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoNoLeftTubeElement(*this); }
    protected:
        /**
        * @brief 无向左管道元素被踩且未对齐时触发的事件
        * @param player 玩家对象
        */
        void on_unaligned_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向左管道元素被顶起且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向左管道元素向左推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向左管道元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向左管道元素左侧内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_left(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
     * @brief 十字管道元素类
     */
    class PicoIntersectTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制十字管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆十字管道元素
         * @return 克隆出的 PicoIntersectTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoIntersectTubeElement(*this); }
    protected:
        /**
        * @brief 十字管道元素被踩且未对齐时触发的事件
        * @param player 玩家对象
        */
        void on_unaligned_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 十字管道元素被顶起且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 十字管道元素向左推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 十字管道元素向右推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
    * @brief 无向右管道元素类
    */
    class PicoNoRightTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制无向右管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆无向右管道元素
         * @return 克隆出的 PicoNoRightTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoNoRightTubeElement(*this); }
    protected:
        /**
        * @brief 无向右管道元素被踩且未对齐时触发的事件
        * @param player 玩家对象
        */
        void on_unaligned_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向右管道元素被顶起且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向右管道元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向右管道元素向右推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向右管道元素右侧内壁被触碰触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_right(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
    * @brief 左下角管道元素类
    */
    class PicoDownRightTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制左下角管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆左下角管道元素
         * @return 克隆出的 PicoDownLeftTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoDownRightTubeElement(*this); }
    protected:
        /**
        * @brief 左下角管道元素被踩且未对齐时触发的事件
        * @param player 玩家对象
        */
        void on_unaligned_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 左下角管道元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 左下角管道元素向左推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 左下角管道元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 左下角管道元素左侧内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 左下角管道元素底部内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_bottom(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
    * @brief 无向下管道元素类
    */
    class PicoNoDownTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制无向下管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆无向下管道元素
         * @return 克隆出的 PicoNoDownTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoNoDownTubeElement(*this); }
    protected:
        /**
        * @brief 无向下管道元素被踩且未对齐时触发的事件
        * @param player 玩家对象
        */
        void on_unaligned_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向下管道元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向下管道元素向左推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向下管道元素向右推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 无向下管道元素底部内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_bottom(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
    * @brief 右下角管道元素类
    */
    class PicoDownLeftTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制右下角管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆右下角管道元素
         * @return 克隆出的 PicoDownRightTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoDownLeftTubeElement(*this); }
    protected:
        /**
        * @brief 右下角管道元素被踩且未对齐时触发的事件
        * @param player 玩家对象
        */
        void on_unaligned_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 右下角管道元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 右下角管道元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 右下角管道元素向右推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 右下角管道元素右侧内壁被触碰且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 右下角管道元素底部内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_bottom(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
    * @brief 水平管道元素类
    */
    class PicoHorizontalTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制水平管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆水平管道元素
         * @return 克隆出的 PicoHorizontalTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoHorizontalTubeElement(*this); }
    protected:
        /**
        * @brief 水平管道元素被踩时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 水平管道元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 水平管道元素顶部内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_top(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 水平管道元素底部内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_bottom(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 水平管道元素向左推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 水平管道元素向右推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first) override;
    };

    /**
    * @brief 垂直管道元素类
    */
    class PicoVerticalTubeElement : public _PicoTubeElement
    {
    public:
        using _PicoTubeElement::_PicoTubeElement;
        /**
        * @brief 绘制垂直管道元素
        */
        void draw() const override;
        /**
         * @brief 克隆垂直管道元素
         * @return 克隆出的 PicoVerticalTubeElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoVerticalTubeElement(*this); }
    protected:
        /**
        * @brief 垂直管道元素向左推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 垂直管道元素向右推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 垂直管道元素左侧内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 垂直管道元素右侧内壁被触碰时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 垂直管道元素被踩且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 垂直管道元素被顶起且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_jump(PicoPlayer& player, bool occurred, bool first) override;
    };
}