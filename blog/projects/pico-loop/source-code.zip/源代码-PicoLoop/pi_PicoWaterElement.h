﻿#pragma once

// 对水元素类的声明
namespace picoloop
{
    /**
     * @brief 水元素类
     */
    class PicoWaterElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制水元素
        */
        void draw() const override;
        /**
         * @brief 克隆水元素
         * @return 克隆出的 PicoWaterElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoWaterElement(*this); }
    protected:
        /**
        * @brief 水元素被碰到时触发的事件
        * @param player 玩家对象
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
    private:
        static const int GRAVITY; // 玩家在水中的重力加速度
        static const int MOVE_SPEED; // 玩家在水中的移动速度
        static const int JUMP_SPEED; // 玩家在水中的跳跃速度
    };
}