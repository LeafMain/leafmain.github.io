﻿#pragma once

// 游戏类声明
namespace picoloop
{
	// 游戏类
	class Game
	{
	public:
		static const int DEFUALT_SLEEP_TIME; // 默认休眠时间
		const LPCTSTR NAME = _T("PicoLoop"); // 游戏名称
		const double VERSION = 1.0; // 游戏版本
		/**
		* @brief 运行游戏，游戏的主循环
		* @note 该函数不会返回，直到游戏退出
		*/
		void run();
		/**
		* @brief 退出游戏
		*/
		void exit() noexcept;
		/**
		* @brief 判断游戏是否正在运行
		* @return true 游戏正在运行
		* @return false 游戏已退出
		*/
		[[nodiscard]] bool is_running() const;
		/**
		* @brief 休眠一段时间
		*/
		void sleep() const;
		/**
		* @brief 设置休眠时间
		*/
		void set_sleep_time(int time);
		/**
		* @brief 获取休眠时间
		* @return 休眠时间
		*/
		[[nodiscard]] int sleep_time() const;
		/**
		* @brief 创建必要的目录
		*/
		void create_directories();
		/**
		* @brief 获取游戏目录路径，以 const char* 类型返回
		* @return 目录路径
		*/
		[[nodiscard]] const char* parent_path() { return "C:\\LeafMain\\PicoLoop"; }
		/**
		* @brief 获取游戏目录路径，以 LPCTSTR 类型返回
		* @return 目录路径
		*/
		[[nodiscard]] LPCTSTR parent_path_t() { return _T("C:\\LeafMain\\PicoLoop"); }
		/**
		* @brief 报告异常
		* @param e 异常
		*/
		void report_exception(const std::exception& e) const noexcept;
	public:
		PageMain page_main{ *this }; // 主页面
		PageLevelSelect page_level_select{ *this }; // 关卡选择页面
		PageMakeSelect page_make_select{ *this }; // 制作选择页面
		PageGameCreate page_game_create{ *this }; // 游戏创建页面
		PagePlayground page_playground{ *this }; // 游戏页面
		PageHandbook page_handbook{ *this }; // 图鉴页面
	private:
		bool _running = false; // 游戏是否正在运行
		int _sleep_time = DEFUALT_SLEEP_TIME; // 休眠时间
		Window window; // 游戏窗口
		/**
		* @brief 处理事件
		* @param event 事件
		*/
		void _handle_events(ExMessage& event);
	};
}