﻿#include "picoloop.h"

// 元素编辑器类实现
namespace picoloop
{
	const int PicoElementEditor::MAX_HISTORY = 65535; // 最大历史长度

	// 元素选择面板类构造函数
	PicoElementEditor::PicoElementEditor(int x, int y, int grid_row,
		int grid_column, int grid_size,
		COLORREF line_color, COLORREF hover_color, COLORREF select_color) :
		PicoElementSelectPanel(true, x, y, grid_row, grid_column, grid_size,
			line_color, hover_color, select_color), hover_color(hover_color)
	{
		elements = new PicoElement * *[GRID_ROW];
		for (int row = 0; row < GRID_ROW; row++)
		{
			elements[row] = new PicoElement * [GRID_COLUMN];
			for (int col = 0; col < GRID_COLUMN; col++)
			{
				// 获取元素坐标
				int x = grid.abs_x(col);
				int y = grid.abs_y(row);
				int size = GRID_SIZE; // 元素大小为网格大小
				// 将所有元素设为空元素
				elements[row][col] = new PicoEmptyElement(x, y, size);
			}
		}
	}

	// 设置元素
	void PicoElementEditor::set_element(PicoElementCollection::TYPE element_type,
		int row, int column, bool need_draw)
	{
		if (grid.in_range(row, column))
		{
			// 只允许一个玩家存在
			if (element_type == PicoElementCollection::PLAYER)
			{
				if (has_player())
				{
					grid.remove_hover();
					return;
				}
				_player_row = row;
				_player_column = column;
			}
			// 如果元素为空，则将原来的元素添加到删除栈中
			else if (element_type == PicoElementCollection::EMPTY)
			{
				// 如果移除了玩家，则允许再次放置玩家
				if (elements[row][column]->is_player())
				{
					_player_row = -1;
					_player_column = -1;
				}
				auto type = PicoElementCollection::get_type(elements[row][column]);
				if (type == PicoElementCollection::LENGTH)
				{
					throw std::runtime_error{
						"Cannot set an empty element to a length element.\n"
					};
				}
				if (!_move_drag && need_draw)
				{
					_delete_stack.push(DoType(row, column, type));
				}
			} 
			// 取消操作标记
			_prev_move = false;
			_prev_clear = false;
			int x = grid.abs_x(column);
			int y = grid.abs_y(row);
			if (need_draw)
			{
				elements[row][column]->erase();
			}
			delete elements[row][column]; // 删除原有元素
			elements[row][column] = PicoElementCollection::create(
				element_type, x, y, GRID_SIZE); // 创建元素
			// 创建失败，抛出异常
			if (elements[row][column] == nullptr)
			{
				throw std::runtime_error{
					"Failed to create an unknown element type.\n"
				};
			}
			if (need_draw)
			{
				elements[row][column]->draw(); // 绘制元素
				grid.supple_grid(row, column); // 更新网格
			}
			// 添加到撤销栈中
			if (!_move_drag && need_draw)
			{
				_undo_stack.push(DoType(row, column, element_type));
			}
			// 记录太多时清空历史记录
			if (_history_overflow())
			{
				clear_history();
			}
		}
		else
		{
			throw std::runtime_error(
				"Try to set an element out of range"
			);
		}
	}

	// 删除元素
	void PicoElementEditor::remove_element(int row, int column, bool need_draw)
	{
		if (grid.in_range(row, column))
		{
			// 将元素设置为空元素即可
			set_element(PicoElementCollection::EMPTY, row, column, need_draw);
		}
		else
		{
			throw std::runtime_error(
				"Try to remove an element out of range"
			);
		}
	}

	// 删除选中元素
	void PicoElementEditor::remove_selected_element()
	{
		// 如果选中了元素则删除
		if (grid.has_active() && !_move_drag)
		{
			remove_element(grid.active_row(), grid.active_column());
			grid.remove_hover();
			grid.remove_active();
		}
	}

	// 清空元素
	void PicoElementEditor::clear_elements(bool need_draw)
	{
		// 如果元素正在拖动，则不操作，防止出错
		if (_move_drag)
		{
			return;
		}
		// 如果上一次操作是清空操作，则不再重复操作
		if (_prev_clear) return; 
		remove_select(); // 先取消所有选择
		clear_history(); // 清空历史记录
		BeginBatchDraw();
		for (int row = 0; row < GRID_ROW; row++)
		{
			for (int col = 0; col < GRID_COLUMN; col++)
			{
				// 只有非空元素才需要删除
				if (!elements[row][col]->is_empty())
				{
					remove_element(row, col, need_draw);
				}
			}
		}
		EndBatchDraw();
		_prev_move = false; // 取消移动操作标记
		_prev_clear = true; // 标记清空操作
	}

	// 移除选中元素
	void PicoElementEditor::remove_select()
	{
		if (_move_drag)
		{
			return;
		}
		grid.remove_hover(); // 移除悬停状态
		grid.remove_active(); // 移除选中元素
	}

	// 撤销方法辅助函数
	void PicoElementEditor::_undo_func()
	{
		// 如果撤销栈为空，则返回
		if (_undo_stack.empty()) return;
		DoType undo_type = _undo_stack.top();
		remove_select();
		if (PicoElementCollection::not_empty(undo_type.type))
		{
			// 移除原来的元素
			remove_element(undo_type.row, undo_type.column);
			_history_pop(_delete_stack);
			_redo_stack.push(undo_type); // 向重做栈中添加元素
			// 由于 remove_element 还会再次往撤销栈中添加元素，因此一共需要弹出两次
			_history_pop(_undo_stack);
			_history_pop(_undo_stack);
		}
		else
		{
			// 如果删除栈为空，则抛出逻辑错误
			if (_delete_stack.empty())
			{
				throw std::logic_error{
					"Failed to undo!\n"
					"There is delete element in the undo stack."
					"but the delete stack is empty.\n"
					"in PicoElementEditor.cpp\n"
				};
			}
			DoType delete_type = _delete_stack.top();
			// 添加之前删除的元素
			set_element(delete_type.type, delete_type.row, delete_type.column);
			_history_pop(_delete_stack);
			_redo_stack.push(undo_type); // 向重做栈中添加元素
			// 由于 set_element 还会再次往撤销栈中添加元素，因此一共需要弹出两次
			_history_pop(_undo_stack);
			_history_pop(_undo_stack);
		}
	}

	// 弹出历史记录
	void PicoElementEditor::_history_pop(std::stack<DoType>& h_stack)
	{
		if (h_stack.empty())
		{
			throw std::underflow_error(
				"One of the history stacks is unexpectedly empty. "
				"There may be some logic error in 'undo' process. \n"
				"in PicoElementEditor.cpp"
			);
		}
		h_stack.pop();
	}

	// 停止元素移动时拖动
	void PicoElementEditor::_stop_move_drag()
	{
		// 如果元素正在拖动
		if (_move_drag && grid.has_active() && selected_not_empty())
		{
			// 取消拖动，补上元素拖动最终位置的记录
			_undo_stack.push(DoType(grid.active_row(),
				grid.active_column(), selected_type()));
			remove_select();
			_move_drag = false;
			_prev_move = true;
			return;
		}
	}

	// 失去元素选择面板和编辑器的焦点
	void PicoElementEditor::blur(PicoElementSelectPanel& panel)
	{
		if (!_move_drag)
		{
			panel.remove_select();
			this->remove_select();
		}
	}

	// 撤销上一次操作
	void PicoElementEditor::undo()
	{
		// 拖动时禁用撤销，防止出错
		if (_move_drag)
		{
			return;
		}
		// 如果上一次操作是移动操作，则撤销两次
		if (_prev_move)
		{
			for (int i = 0; i < 2; i++)
			{
				_undo_func();
			}
		}
		// 如果上一次是清空操作，则撤销所有操作
		else if (_prev_clear)
		{
			BeginBatchDraw();
			while (!_undo_stack.empty())
			{
				_undo_func();
			}
			EndBatchDraw();
		}
		// 否则只撤销一次
		else
		{
			_undo_func();
		}
	}

	// 重做上一次操作
	void PicoElementEditor::redo()
	{
		// 拖动时禁用重做，防止出错
		if (_move_drag)
		{
			return;
		}
		// 如果重做栈为空，则返回
		if (_redo_stack.empty()) return;
		DoType redo_type = _redo_stack.top();
		remove_select();
		// 设置元素
		set_element(redo_type.type, redo_type.row, redo_type.column);
		// 无需再次向撤销栈中添加元素，因为 set_element 已经添加过一次了
		_history_pop(_redo_stack);
	}

	// 清空操作历史
	void PicoElementEditor::clear_history()
	{
		_prev_move = false; // 取消移动操作标记
		_prev_clear = false; // 取消清空操作标记
		_move_drag = false; // 取消移动拖动标记
		// 清空撤销栈
		while (!_undo_stack.empty())
		{
			_undo_stack.pop();
		}
		// 清空重做栈
		while (!_redo_stack.empty())
		{
			_redo_stack.pop();
		}
		// 清空删除栈
		while (!_delete_stack.empty())
		{
			_delete_stack.pop();
		}
	}

	// 判断操作历史是否溢出
	bool PicoElementEditor::_history_overflow()
	{
		return _undo_stack.size() > MAX_HISTORY ||
			_redo_stack.size() > MAX_HISTORY ||
			_delete_stack.size() > MAX_HISTORY;
	}

	// 绘制元素编辑器
	void PicoElementEditor::draw() const
	{
		// 调用基类绘制函数
		PicoElementSelectPanel::draw();
	}

	// 监听鼠标悬停事件
	void PicoElementEditor::listen_hover(ExMessage& event,
		PicoElementSelectPanel& panel)
	{
		// 当鼠标移动事件发生时
		if (event.message == WM_MOUSEMOVE)
		{
			int row = grid.to_row(event.y); // 获取鼠标所在行
			int col = grid.to_column(event.x); // 获取鼠标所在列
			if (!grid.in_range(row, col))
			{
				// 清除网格悬停
				grid.remove_hover();
				return;
			}
			// 悬浮格子没有变化返回
			if (grid.hover_row() == row && grid.hover_column() == col)
			{
				return;
			}
			// 当面板选中了元素，在空网格上绘制悬停颜色
			if (panel.selected_not_empty())
			{
				if (elements[row][col]->is_empty() && !_move_drag)
				{
					// 鼠标拖动时连续绘制
					if (event.lbutton)
					{
						if (grid.has_active())
						{
							remove_select();
						}
						set_element(panel.selected_type(), row, col);
					}
					// 再次设置悬停
					if (!has_player() || panel.selected_type() != 
						PicoElementCollection::PLAYER)
					{
						if (grid.has_active())
						{
							remove_select();
						}
						grid.set_hover(row, col);
					}
				}
			}
			// 否则如果编辑器选中了元素，在网格非空元素上绘制悬停颜色
			else if (this->selected_not_empty())
			{
				if (!elements[row][col]->is_empty())
				{
					return;
				}
				// 如果悬浮矩形和选中矩形相连，则绘制激活颜色
				if (grid.active_adjacent(grid.hover_row(), 
					grid.hover_column()))
				{
					grid.remove_hover();
					grid.set_active(grid.active_row(), 
						grid.active_column(), true);
				}
				// 拖动时，移动元素，否则设置悬浮
				if (event.lbutton && !event.ctrl)
				{
					auto type = selected_type();
					remove_element(grid.active_row(), grid.active_column());
					_move_drag = true; // 标记为拖动操作
					set_element(type, row, col);
					remove_select();
					if (!elements[row][col]->is_empty())
					{
						grid.set_active(row, col);
					}
				}
				else if (event.lbutton && event.ctrl)
				{
					if (selected_type() != 
						PicoElementCollection::PLAYER)
					{
						_stop_move_drag();
						set_element(selected_type(), row, col);
						grid.set_active(row, col);
					}
				}
				else if (!_move_drag)
				{
					grid.set_hover(row, col);
				}
				// 如果悬浮矩形和选中矩形相连，则绘制激活颜色
				if (grid.active_adjacent(row, col))
				{
					grid.set_active(grid.active_row(), 
						grid.active_column(), true);
				}
			}
			// 按住鼠标右键时，批量删除元素
			if (event.rbutton && !_move_drag)
			{
				if (!elements[row][col]->is_empty())
				{
					remove_element(row, col);
				}
			}
		}
	}

	// 监听元素选中事件
	void PicoElementEditor::listen_select(ExMessage& event,
		PicoElementSelectPanel& panel)
	{ 
		// 左键添加元素
		if (event.message == WM_LBUTTONDOWN)
		{
			int row = grid.to_row(event.y); // 获取点击行
			int col = grid.to_column(event.x); // 获取点击列
			if (!grid.in_range(row, col)) return;
			// 移动时不添加元素
			if (_move_drag)
			{
				return;
			}
			// 当选中的元素为空时，将面板选中的元素设置到当前位置
			if (elements[row][col]->is_empty())
			{
				// 设置元素
				if (panel.selected_not_empty())
				{
					set_element(panel.selected_type(), row, col);
				}
				// 已经选中了元素，则移动元素
				else if (this->selected_not_empty())
				{
					int from_row = grid.active_row();
					int from_col = grid.active_column();
					// 位置变化时才移动
					if (row != from_row || col != from_col)
					{
						auto type = this->selected_type();
						remove_element(from_row, from_col);
						set_element(type, row, col);
						remove_select();
						_prev_move = true; // 标记为移动操作
					}
				}
				// 否则，不做任何操作
				else
				{
					return;
				}
			}
			// 当选中的元素不为空时，将编辑器选中的元素设置为当前位置
			else 
			{
				if (row != grid.active_row() || col != grid.active_column())
				{
					grid.remove_hover();
					panel.remove_select();
					grid.set_active(row, col);
				}
				else if (grid.active_adjacent(grid.hover_row(),
					grid.hover_column()))
				{
					remove_select();
				}
			}
			// 清空重做栈
			while (!_redo_stack.empty())
			{
				_redo_stack.pop();
			}
			_modified = true; // 标记为已修改
		}
		// 左键松开取消
		else if (event.message == WM_LBUTTONUP)
		{
			// 如果元素正在拖动，停止拖动
			_stop_move_drag();
		}
		// 右键删除元素
		else if (event.message == WM_RBUTTONDOWN)
		{
			int row = grid.to_row(event.y); // 获取点击行
			int col = grid.to_column(event.x); // 获取点击列
			if (!grid.in_range(row, col)) return;
			// 如果正在拖动，禁用删除，防止栈意外为空
			if (_move_drag)
			{
				return;
			}
			// 当选中的元素不为空时，删除元素
			if (!elements[row][col]->is_empty())
			{
				remove_element(row, col);
				grid.remove_hover();
				// 重绘选中区域
				if (grid.has_active() && (grid.active_row() != 
					row || grid.active_column() != col))
				{
					grid.set_active(grid.active_row(), 
						grid.active_column(), true);
				}
			}
			// 当选中的元素为空时，取消面板选择
			else
			{
				this->remove_select();
				panel.remove_select();
			}
			_modified = true; // 标记为已修改
		}
		// 中键清空元素
		else if (event.message == WM_MBUTTONDOWN)
		{
			// 如果正在拖动，则不操作，防止出错
			if (_move_drag)
			{
				return;
			}
			clear_elements();
			_modified = true; // 标记为已修改
		}
	}

	// 监听元素选择面板事件
	void PicoElementEditor::listen_panel_event(ExMessage& event,
		PicoElementSelectPanel& panel)
	{
		listen_hover(event, panel);
		listen_select(event, panel);
	}
	// 返回编辑器元素指针
	PicoElement*** const PicoElementEditor::get_elements() const
	{
		return elements;
	}

	// 返回元素类型数据
	PicoElementCollection::Data PicoElementEditor::
		get_elements_data() const
	{
		PicoElementCollection::Data data; // 类型为二维 std::vector
		for (int row = 0; row < GRID_ROW; row++)
		{
			data.push_back(std::vector<PicoElementCollection::TYPE>());
			for (int col = 0; col < GRID_COLUMN; col++)
			{
				data[row].push_back(
					PicoElementCollection::get_type(elements[row][col])
				);
			}
		}
		return data;
	}

	// 根据元素类型数据设置元素
	void PicoElementEditor::set_elements_from_data(
		const PicoElementCollection::Data& data, bool need_draw)
	{
		// 如果数据为空，则不做任何操作
		if (data.empty()) return;
		clear_elements(need_draw); // 清空元素
		// 逐个设置元素
		int player_count = 0; // 玩家数量统计
		int player_row = -1; // 玩家行坐标
		int player_column = -1; // 玩家列坐标
		for (int row = 0; row < GRID_ROW; row++)
		{
			for (int col = 0; col < GRID_COLUMN; col++)
			{
				if (data.at(row).at(col) == PicoElementCollection::PLAYER)
				{
					player_count++;
					player_row = row;
					player_column = col;
				}
			}
		}
		// 如果玩家数量多于 1，则抛出异常
		if (player_count > 1)
		{
			throw std::runtime_error{
				"Failed to set elements from data.\n"
				"There should be at most one player in the data.\n"
			};
		}
		BeginBatchDraw();
		for (int row = 0; row < GRID_ROW; row++)
		{
			for (int col = 0; col < GRID_COLUMN; col++)
			{
				// 重置玩家位置
				_player_row = _player_column = -1;
				set_element(data.at(row).at(col), row, col, need_draw);
			}
		}
		EndBatchDraw();
		_player_row = player_row; // 设置玩家位置
		_player_column = player_column; // 设置玩家位置
		clear_history(); // 清空历史记录
	}
}