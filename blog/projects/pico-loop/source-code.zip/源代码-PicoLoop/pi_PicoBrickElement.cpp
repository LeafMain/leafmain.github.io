﻿#include "picoloop.h"

// 对砖块元素类的实现
namespace picoloop
{
    // 绘制砖块元素
    void PicoBrickElement::draw() const
    {
        _get_bk_image();
        setlinecolor(0x222233);
        setlinestyle(PS_SOLID, 1);
        // 绘制棕色砖块
        setfillcolor(0x0055cc);
        for (int y = 0; y < 40; y += 10)
        {
            for (int x = 0; x < 40; x += 10)
            {
                fillrectangle(_40x(x), _40y(y), _40x(x + 10), _40y(y + 5));
            }
        }
        // 绘制红色砖块
        setfillcolor(0x1e3cab);
        for (int y = 5; y < 40; y += 10)
        {
            for (int x = 0; x < 40; x += 35)
            {
                fillrectangle(_40x(x), _40y(y), _40x(x + 5), _40y(y + 5));
            }
            for (int x = 5; x < 35; x += 10)
            {
                fillrectangle(_40x(x), _40y(y), _40x(x + 10), _40y(y + 5));
            }
        }
    }

    // 砖块元素被踩时触发的事件
    void PicoBrickElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first) 
            {
                player.disable_drop();
                player.enable_jump();
            }
        }
        else
        {
            if (first)
            {
                player.enable_drop();
                player.disable_jump();
            }
        }
    }

    // 砖块元素被顶起时触发的事件
    void PicoBrickElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.stop_shift();
            }
        }
    }

    // 砖块元素向左推动时触发的事件
    void PicoBrickElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
            }
        }
    }

    // 砖块元素向右推动时触发的事件
    void PicoBrickElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_right();
            }
        }
        else
        {
            if (first) 
            {
                player.enable_move_right();
            }
        }
    }
}