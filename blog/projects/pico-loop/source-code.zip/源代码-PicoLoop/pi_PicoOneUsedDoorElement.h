﻿#pragma once

// 对单次门元素类的声明
namespace picoloop
{
    /**
     * @brief 单次门元素类
     */
    class PicoOneUsedDoorElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制单次门元素
        */
        void draw() const override;
        /**
        * @brief 绘制单次门元素的打开状态
        */
        void draw_opened() const;
        /**
        * @brief 绘制单次门元素的关闭状态
        */
        void draw_closed() const;
        /**
        * @brief 重置单次门元素数据
        */
        void reset_data() override;
        /**
         * @brief 克隆单次门元素
         * @return 克隆出的 PicoOneUsedDoorElement 实例
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoOneUsedDoorElement(*this); }
    protected:
        /**
        * @brief 单次门元素被踩时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 单次门元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 单次门元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 单次门元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 单次门元素向左推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 单次门元素向右推动且未对齐时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 单次门元素被通过时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_through(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 单次门元素被触碰到顶部时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_top(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 单次门元素被触碰到底部时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_touch_bottom(PicoPlayer& player, bool occurred, bool first) override;
    private:
        static const COLORREF DOOR_COLOR; // 门颜色
        static constexpr int QUEUE_MAX_SIZE = 6; // 事件队列最大长度
        static const std::vector<PLAYER_EVENT> _expect_events_1; // 期望的事件 1
        static const std::vector<PLAYER_EVENT> _expect_events_2; // 期望的事件 2
        bool _closed = false; // 门是否关闭
        std::deque<PLAYER_EVENT> _event_queue{ QUEUE_MAX_SIZE }; // 事件队列
        /**
        * @brief 推入事件到事件队列
        * @param player_event 玩家事件
        */
        void _push_event_queue(PLAYER_EVENT player_event);
        /**
        * @brief 检查门是否应该关闭
        * @param player 玩家对象
        */
        void _check_close_condition(PicoPlayer& player);
    };
}