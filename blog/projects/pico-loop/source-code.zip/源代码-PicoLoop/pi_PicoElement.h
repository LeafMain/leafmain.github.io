﻿#pragma once

// Pico元素抽象类声明
namespace picoloop
{
	class PicoPlayer; // 声明PicoPlayer类
	/**
	* @brief Pico元素抽象类
	* @brief 子类必须实现 public void draw() const 方法
	*  - 该方法内部需要调用 _get_bk_image() 获取背景缓存；
	* @brief 子类必须实现 public PicoElement* clone() const 方法;
	*/
	class PicoElement
	{
	public:
		static const int ELEMENT_INIT_SIZE; // 元素初始大小
		static const bool DISABLE_ANIMATION;  // 禁用动画
		int x; // 元素x坐标
		int y; // 元素y坐标
		int size; // 元素大小
		/**
		* @brief 构造函数
		* @param x 元素x坐标，默认为 0
		* @param y 元素y坐标，默认为 0
		* @param size 元素大小，默认为 40
		*/
		explicit PicoElement(int x = 0, int y = 0, int size = ELEMENT_INIT_SIZE);
		/**
		* @brief 判断元素是否被点击
		* @param event 事件消息
		* @return true 元素被点击
		* @return false 元素未被点击
		*/
		[[nodiscard]] bool clicked(ExMessage& event) const;
		/**
		* @brief 判断坐标是否在元素范围内
		* @param x 坐标x
		* @param y 坐标y
		* @return true 坐标在元素范围内
		* @return false 坐标不在元素范围内
		*/
		[[nodiscard]] virtual bool in_area(int x, int y) const
		{ return x >= this->x && x <= this->x + size && 
			y >= this->y && y <= this->y + size; }
		/**
		* @brief 判断元素是否为空元素
		* @return true 元素为空元素
		* @return false 元素不为空元素
		*/
		[[nodiscard]] virtual bool is_empty() const { return false; }
		/**
		* @brief 判断元素是否为玩家
		* @return true 元素为玩家
		* @return false 元素不为玩家
		*/
		[[nodiscard]] virtual bool is_player() const { return false; }
		/**
		* @brief 绘制元素
		*/
		virtual void draw() const = 0;
		/**
		* @brief 擦除元素
		*/
		virtual void erase() const;
		/**
		* @brief 监听玩家事件
		* @param element 元素
		* @param player 玩家
		*/
		void listen_player(PicoPlayer& player);
		/**
		* @brief 更新系统时钟
		*/
		virtual void update_clock();
		/**
		* @brief 更新动画
		*/
		virtual void update_animation();
		/**
		* @brief 重置元素数据
		*/
		virtual void reset_data();
		/**
		* @brief 克隆元素
		* @return 克隆后的元素指针
		*/
		[[nodiscard]] virtual PicoElement* clone() const = 0;
	protected:
		enum class PLAYER_EVENT // 玩家事件枚举
		{
			NONE, // 无事件
			BUMP_BEGIN, // 开始碰撞
			BUMP_END, // 结束碰撞
			PEDAL_BEGIN, // 开始踩踏
			PEDAL_END, // 结束踩踏
			JUMP_BEGIN, // 开始跳跃
			JUMP_END, // 结束跳跃
			PUSH_LEFT_BEGIN, // 开始向左推
			PUSH_LEFT_END, // 结束向左推
			PUSH_RIGHT_BEGIN, // 开始向右推
			PUSH_RIGHT_END, // 结束向右推
			THROUGH_BEGIN, // 开始穿过
			THROUGH_END, // 结束穿过
			TOUCH_LEFT_BEGIN, // 开始触碰左侧
			TOUCH_LEFT_END, // 结束触碰左侧
			TOUCH_TOP_BEGIN, // 开始触碰顶部
			TOUCH_TOP_END, // 结束触碰顶部
			TOUCH_RIGHT_BEGIN, // 开始触碰右侧
			TOUCH_RIGHT_END, // 结束触碰右侧
			TOUCH_BOTTOM_BEGIN, // 开始触碰底部
			TOUCH_BOTTOM_END, // 结束触碰底部
			LENGTH, // 事件数量，用于数组大小
			UNALIGNED_TOUCH_LEFT_BEGIN, // 开始触碰左侧且不对齐
			UNALIGNED_TOUCH_LEFT_END, // 结束触碰左侧且不对齐
			UNALIGNED_TOUCH_TOP_BEGIN, // 开始触碰顶部且不对齐
			UNALIGNED_TOUCH_TOP_END, // 结束触碰顶部且不对齐
			UNALIGNED_TOUCH_RIGHT_BEGIN, // 开始触碰右侧且不对齐
			UNALIGNED_TOUCH_RIGHT_END, // 结束触碰右侧且不对齐
			UNALIGNED_TOUCH_BOTTOM_BEGIN, // 开始触碰底部且不对齐
			UNALIGNED_TOUCH_BOTTOM_END, // 结束触碰底部且不对齐
		};
		std::clock_t clock_now = 0; // 系统时钟
		/**
		* @brief 将元素后面的背景缓存
		*/
		void _get_bk_image() const;
		/**
		* @brief 将元素后面的背景缓存绘制到屏幕上
		*/
		void _put_bk_image() const;
		/**
		* @brief 重置基础元素数据，子类需在 reset_data() 调用
		*/
		void base_reset();
		/**
		* @brief 将相对于 40 的 x 坐标转换为绝对 x 坐标
		* @param rx 相对于 40 的 x 坐标，范围 0 - 40
		* @return 绝对 x 坐标
		*/
		[[nodiscard]] int _40x(int rx) const 
		{ return x + _pre_40x.at(rx); }
		/**
		* @brief 将相对于 40 的 y 坐标转换为绝对 y 坐标
		* @param ry 相对于 40 的 y 坐标，范围 0 - 40
		* @return 绝对 y 坐标
		*/
		[[nodiscard]] int _40y(int ry) const 
		{ return y + _pre_40y.at(ry); }
		/**
		* @brief 元素被碰撞时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_bump(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被踩时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_pedal(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被顶起时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_jump(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素向左推动时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_push_left(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素向右推动时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_push_right(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被玩家通过时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_through(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被玩家触碰到内壁左侧时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_touch_left(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被玩家触碰到内壁顶部时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_touch_top(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被玩家触碰到内壁右侧时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_touch_right(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被玩家触碰到内壁底部时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_touch_bottom(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被踩且不对齐时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_unaligned_pedal(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被顶起且不对齐时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_unaligned_jump(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被向左推且不对齐时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_unaligned_push_left(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被向右推且不对齐时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_unaligned_push_right(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被玩家触碰到内壁左侧且不对齐时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_unaligned_touch_left(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被玩家触碰到内壁顶部且不对齐时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_unaligned_touch_top(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被玩家触碰到内壁右侧且不对齐时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_unaligned_touch_right(PicoPlayer& player, bool occurred, bool first);
		/**
		* @brief 元素被玩家触碰到内壁底部且不对齐时调用
		* @param player 玩家
		* @param occurred 是否发生事件
		* @param first 是否第一次发生事件
		*/
		virtual void on_unaligned_touch_bottom(PicoPlayer& player, bool occurred, bool first);
	private:
		mutable IMAGE _bk_image_; // 绘制前的背景缓存
		bool _bumped = false; // 记录玩家是否碰到元素
		bool _pedaled = false; // 记录玩家是否踩到元素
		bool _jumped = false; // 记录玩家是否顶起元素
		bool _left_pushed = false; // 记录玩家是否左推元素
		bool _right_pushed = false; // 记录玩家是否右推元素
		bool _through = false; // 记录玩家是否通过元素
		bool _touched_left = false; // 记录玩家是否触碰到元素左侧
		bool _touched_top = false; // 记录玩家是否触碰到元素顶部
		bool _touched_right = false; // 记录玩家是否触碰到元素右侧
		bool _touched_bottom = false; // 记录玩家是否触碰到元素底部
		bool _init_pre_calc_40 = false; // 预计算 40x 坐标和 40y 坐标是否完成
		bool _unaligned_pedaled = false; // 记录玩家是否踩且不对齐元素
		bool _unaligned_jumped = false; // 记录玩家是否顶起且不对齐元素
		bool _unaligned_left_pushed = false; // 记录玩家是否左推且不对齐元素
		bool _unaligned_right_pushed = false; // 记录玩家是否右推且不对齐元素
		bool _unaligned_touched_left = false; // 记录玩家是否触碰到元素左侧且不对齐
		bool _unaligned_touched_top = false; // 记录玩家是否触碰到元素顶部且不对齐
		bool _unaligned_touched_right = false; // 记录玩家是否触碰到元素右侧且不对齐
		bool _unaligned_touched_bottom = false; // 记录玩家是否触碰到元素底部且不对齐
		std::vector<int> _pre_40x; // 预计算 40x 坐标
		std::vector<int> _pre_40y; // 预计算 40y 坐标
		/**
		* @brief 判断元素是否与玩家在 x 轴对齐
		* @param player 玩家
		* @param offset 偏移量
		* @return true 元素与玩家 x 轴对齐
		* @return false 元素与玩家 x 轴不对齐
		*/
		[[nodiscard]] bool _aligned_x(const PicoPlayer& player, int offset = 0) const;
		/**
		* @brief 判断元素是否与玩家在 y 轴对齐
		* @param player 玩家
		* @param offset 偏移量
		* @return true 元素与玩家 y 轴对齐
		* @return false 元素与玩家 y 轴不对齐
		*/
		[[nodiscard]] bool _aligned_y(const PicoPlayer& player, int offset = 0) const;
		/**
		* @brief 判断元素是否被玩家碰到
		* @param player 玩家
		* @return true 元素被玩家碰到
		* @return false 元素未被玩家碰到
		*/
		[[nodiscard]] bool bumped_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家踩到
		* @param player 玩家
		* @return true 元素被玩家踩到
		* @return false 元素未被玩家踩到
		*/
		[[nodiscard]] bool pedaled_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家顶起
		* @param player 玩家
		* @return true 元素被玩家顶起
		* @return false 元素未被玩家顶起
		*/
		[[nodiscard]] bool jumped_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家向左推
		* @param player 玩家
		* @return true 被玩家向左推
		* @return false 未被玩家向左推
		*/
		[[nodiscard]] bool pushed_left_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家向右推
		* @param player 玩家
		* @return true 被玩家向右推
		* @return false 未被玩家向右推
		*/
		[[nodiscard]] bool pushed_right_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家通过
		* @param player 玩家
		* @return true 元素被玩家通过
		* @return false 元素未被玩家通过
		*/
		[[nodiscard]] bool through_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家触碰到内壁左侧
		* @param player 玩家
		* @return true 元素被玩家触碰到内壁左侧
		* @return false 元素未被玩家触碰到内壁左侧
		*/
		[[nodiscard]] bool touched_left_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家触碰到内壁顶部
		* @param player 玩家
		* @return true 元素被玩家触碰到内壁顶部
		* @return false 元素未被玩家触碰到内壁顶部
		*/
		[[nodiscard]] bool touched_top_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家触碰到内壁右侧
		* @param player 玩家
		* @return true 元素被玩家触碰到内壁右侧
		* @return false 元素未被玩家触碰到内壁右侧
		*/
		[[nodiscard]] bool touched_right_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家触碰到内壁底部
		* @param player 玩家
		* @return true 元素被玩家触碰到内壁底部
		* @return false 元素未被玩家触碰到内壁底部
		*/
		[[nodiscard]] bool touched_bottom_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家踩且不对齐
		* @param player 玩家
		* @return true 元素被玩家踩且不对齐
		* @return false 元素未被玩家踩且不对齐
		*/
		[[nodiscard]] bool unaligned_pedaled_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家顶起且不对齐
		* @param player 玩家
		* @return true 元素被玩家顶起且不对齐
		* @return false 元素未被玩家顶起且不对齐
		*/
		[[nodiscard]] bool unaligned_jumped_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家向左推且不对齐
		* @param player 玩家
		* @return true 元素被玩家向左推且不对齐
		* @return false 元素未被玩家向左推且不对齐
		*/
		[[nodiscard]] bool unaligned_pushed_left_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家向右推且不对齐
		* @param player 玩家
		* @return true 元素被玩家向右推且不对齐
		* @return false 元素未被玩家向右推且不对齐
		*/
		[[nodiscard]] bool unaligned_pushed_right_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家触碰到内壁左侧且不对齐
		* @param player 玩家
		* @return true 元素被玩家触碰到内壁左侧且不对齐
		* @return false 元素未被玩家触碰到内壁左侧且不对齐
		*/
		[[nodiscard]] bool unaligned_touched_left_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家触碰到内壁顶部且不对齐
		* @param player 玩家
		* @return true 元素被玩家触碰到内壁顶部且不对齐
		* @return false 元素未被玩家触碰到内壁顶部且不对齐
		*/
		[[nodiscard]] bool unaligned_touched_top_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家触碰到内壁右侧且不对齐
		* @param player 玩家
		* @return true 元素被玩家触碰到内壁右侧且不对齐
		* @return false 元素未被玩家触碰到内壁右侧且不对齐
		*/
		[[nodiscard]] bool unaligned_touched_right_by(const PicoPlayer& player) const;
		/**
		* @brief 判断元素是否被玩家触碰到内壁底部且不对齐
		* @param player 玩家
		* @return true 元素被玩家触碰到内壁底部且不对齐
		* @return false 元素未被玩家触碰到内壁底部且不对齐
		*/
		[[nodiscard]] bool unaligned_touched_bottom_by(const PicoPlayer& player) const;
		/**
		* @brief 预计算 40x 坐标和 40y 坐标
		*/
		void _pre_calc_40();
	};
}