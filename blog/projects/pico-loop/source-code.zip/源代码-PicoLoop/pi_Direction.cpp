﻿#include "pi_Direction.h"

// 方向类实现
namespace picoloop
{
    // 判断两个方向是否相反
    bool Direction::is_opposite(TYPE dir1, TYPE dir2)
    {
        return dir1 == to_opposite(dir2);
    }

    // 获得相反方向
    Direction::TYPE Direction::to_opposite(TYPE dir)
    {
        return static_cast<TYPE>((dir + LENGTH / 2) % LENGTH);
    }
}