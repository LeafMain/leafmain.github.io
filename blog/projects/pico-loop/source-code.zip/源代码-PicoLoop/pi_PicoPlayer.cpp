﻿#include "picoloop.h"

// Pico玩家类静态常量定义
namespace picoloop
{
	const int PicoPlayer::MOVE_STEP = 2;  // 玩家移动步长
	const int PicoPlayer::INIT_SIZE = 32;  // 玩家初始大小
	const int PicoPlayer::SPEED::MOVE::BUFF_NONE = 200; // 无 buff 状态的移动速度
	const int PicoPlayer::SPEED::MOVE::BUFF_SUPER = 200; // 超级 buff 状态的移动速度
	const int PicoPlayer::SPEED::MOVE::BUFF_FLY = 300; // 飞行 buff 状态的移动速度
	const int PicoPlayer::SPEED::MOVE::BUFF_POISON = 100; // 中毒 buff 状态的移动速度
	const int PicoPlayer::SPEED::JUMP::BUFF_NONE = 400; // 无 buff 状态的跳跃速度
	const int PicoPlayer::SPEED::JUMP::BUFF_SUPER = 500; // 超级 buff 状态的跳跃速度
	const int PicoPlayer::SPEED::JUMP::BUFF_FLY = 300; // 飞行 buff 状态的跳跃速度
	const int PicoPlayer::SPEED::JUMP::BUFF_POISON = 300; // 中毒 buff 状态的跳跃速度
	const int PicoPlayer::GRAVITY::BUFF_NONE = 400; // 无 buff 状态的重力加速度
	const int PicoPlayer::GRAVITY::BUFF_SUPER = 400; // 超级 buff 状态
	const int PicoPlayer::GRAVITY::BUFF_FLY = 200; // 飞行 buff 状态的重力加速度
	const int PicoPlayer::GRAVITY::BUFF_POISON = 400; // 中毒 buff 状态的重力加速度
	const int PicoPlayer::MAX_DROP_SPEED = 850; // 玩家最大掉落速度
	const int PicoPlayer::NORMAL_MOVE_SPEED = SPEED::MOVE::BUFF_NONE; // 玩家正常移动速度
	const int PicoPlayer::NORMAL_JUMP_SPEED = SPEED::JUMP::BUFF_NONE; // 玩家正常跳跃速度
	const int PicoPlayer::NORMAL_GRAVITY = GRAVITY::BUFF_NONE; // 玩家正常重力
}

// Pico玩家类实现
namespace picoloop
{
	// @brief 绘制玩家，调用绘制正常玩家函数
	void PicoPlayer::draw() const
	{
		draw(_buff);
	}

	// 绘制玩家，根据指定 buff 状态绘制
	void PicoPlayer::draw(BUFF buff) const
	{
		switch (buff)
		{
		case BUFF::NONE:
			draw_buff_none();
			break;
		case BUFF::SUPER:
			draw_buff_super();
			break;
		case BUFF::FLY:
			draw_buff_fly();
			break;
		case BUFF::POISON:
			draw_buff_poison();
			break;
		default:
			break;
		}
	}

	// 绘制玩家（正常状态）
	void PicoPlayer::draw_buff_none() const
	{ 
		_get_bk_image();
		// 绘制身体部分
		setfillcolor(0x7baed3);
		solidrectangle(_40x(5), _40y(5), _40x(34), _40y(34));
		// 绘制头部
		setfillcolor(0x6655ff);
		solidrectangle(_40x(8), _40y(0), _40x(32), _40y(4));
		// 绘制眼睛
		setfillcolor(0x000000);
		solidrectangle(_40x(25), _40y(10), _40x(30), _40y(15));
		// 绘制手臂
		setfillcolor(0x2b7eba);
		solidrectangle(_40x(35), _40y(15), _40x(40), _40y(25));
		solidrectangle(_40x(0), _40y(20), _40x(5), _40y(30));
		// 绘制嘴巴
		setfillcolor(0x110099);
		solidrectangle(_40x(31), _40y(23), _40x(34), _40y(27));
		// 绘制脚
		setfillcolor(0x1b6294);
		solidrectangle(_40x(10), _40y(35), _40x(15), _40y(40));
		solidrectangle(_40x(25), _40y(35), _40x(30), _40y(40));
		// 绘制口袋
		setfillcolor(0xaa5500);
		solidrectangle(_40x(6), _40y(27), _40x(11), _40y(32));
		// 刷新缓存区，使显示动画时不闪屏
		FlushBatchDraw(); 
	}

	// 绘制玩家（超级状态）
	void PicoPlayer::draw_buff_super() const
	{
		_get_bk_image();
		// 身体部分颜色修改为淡紫色
		setfillcolor(0xff80b4);
		solidrectangle(_40x(5), _40y(5), _40x(34), _40y(34));
		setfillcolor(0x6655ff);
		solidrectangle(_40x(8), _40y(0), _40x(32), _40y(4));
		setfillcolor(0x000000);
		solidrectangle(_40x(25), _40y(10), _40x(30), _40y(15));
		setfillcolor(0x2b7eba);
		solidrectangle(_40x(35), _40y(15), _40x(40), _40y(25));
		solidrectangle(_40x(0), _40y(20), _40x(5), _40y(30));
		setfillcolor(0x110099);
		solidrectangle(_40x(31), _40y(23), _40x(34), _40y(27));
		setfillcolor(0x1b6294);
		solidrectangle(_40x(10), _40y(35), _40x(15), _40y(40));
		solidrectangle(_40x(25), _40y(35), _40x(30), _40y(40));
		setfillcolor(0xaa5500);
		solidrectangle(_40x(6), _40y(27), _40x(11), _40y(32));
		// 刷新缓存区，使显示动画时不闪屏
		FlushBatchDraw();
	}

	// 绘制玩家（飞行状态）
	void PicoPlayer::draw_buff_fly() const
	{
		_get_bk_image();
		// 身体部分颜色修改为淡蓝色
		setfillcolor(0xffb660);
		solidrectangle(_40x(5), _40y(5), _40x(34), _40y(34));
		setfillcolor(0x6655ff);
		solidrectangle(_40x(8), _40y(0), _40x(32), _40y(4));
		setfillcolor(0x000000);
		solidrectangle(_40x(25), _40y(10), _40x(30), _40y(15));
		setfillcolor(0x2b7eba);
		solidrectangle(_40x(35), _40y(15), _40x(40), _40y(25));
		solidrectangle(_40x(0), _40y(20), _40x(5), _40y(30));
		setfillcolor(0x110099);
		solidrectangle(_40x(31), _40y(23), _40x(34), _40y(27));
		setfillcolor(0x1b6294);
		solidrectangle(_40x(10), _40y(35), _40x(15), _40y(40));
		solidrectangle(_40x(25), _40y(35), _40x(30), _40y(40));
		setfillcolor(0xaa5500);
		solidrectangle(_40x(6), _40y(27), _40x(11), _40y(32));
		// 刷新缓存区，使显示动画时不闪屏
		FlushBatchDraw();
	}

	// 绘制玩家（中毒状态）
	void PicoPlayer::draw_buff_poison() const
	{
		_get_bk_image();
		// 身体部分颜色修改为深紫色
		setfillcolor(0xff00be);
		solidrectangle(_40x(5), _40y(5), _40x(34), _40y(34));
		setfillcolor(0x6655ff);
		solidrectangle(_40x(8), _40y(0), _40x(32), _40y(4));
		setfillcolor(0x000000);
		solidrectangle(_40x(25), _40y(10), _40x(30), _40y(15));
		setfillcolor(0x2b7eba);
		solidrectangle(_40x(35), _40y(15), _40x(40), _40y(25));
		solidrectangle(_40x(0), _40y(20), _40x(5), _40y(30));
		setfillcolor(0x110099);
		solidrectangle(_40x(31), _40y(23), _40x(34), _40y(27));
		setfillcolor(0x1b6294);
		solidrectangle(_40x(10), _40y(35), _40x(15), _40y(40));
		solidrectangle(_40x(25), _40y(35), _40x(30), _40y(40));
		setfillcolor(0xaa5500);
		solidrectangle(_40x(6), _40y(27), _40x(11), _40y(32));
		// 刷新缓存区，使显示动画时不闪屏
		FlushBatchDraw();
	}

	// 绘制玩家（死亡状态）
	void PicoPlayer::draw_died() const
	{
		_get_bk_image();
		// 死亡状态下，身体、头部、手脚都变成灰色
		setfillcolor(DARKGRAY);
		solidrectangle(_40x(5), _40y(5), _40x(34), _40y(34));
		setfillcolor(DARKGRAY);
		solidrectangle(_40x(8), _40y(0), _40x(32), _40y(4));
		setfillcolor(BLACK);
		solidrectangle(_40x(25), _40y(10), _40x(30), _40y(15));
		setfillcolor(DARKGRAY);
		solidrectangle(_40x(35), _40y(15), _40x(40), _40y(25));
		solidrectangle(_40x(0), _40y(20), _40x(5), _40y(30));
		setfillcolor(BLACK);
		solidrectangle(_40x(31), _40y(23), _40x(34), _40y(27));
		setfillcolor(DARKGRAY);
		solidrectangle(_40x(10), _40y(35), _40x(15), _40y(40));
		solidrectangle(_40x(25), _40y(35), _40x(30), _40y(40));
	}

	// 擦除玩家
	void PicoPlayer::erase() const
	{
		_put_bk_image();
		// 绘制
	}

	// 设置玩家当前的 buff 状态
	void PicoPlayer::set_buff(BUFF buff)
	{
		switch (buff)
		{
		case BUFF::NONE:
			_max_speed_x = SPEED::MOVE::BUFF_NONE;
			_max_speed_y = SPEED::JUMP::BUFF_NONE;
			_gravity = GRAVITY::BUFF_NONE;
			erase();
			draw_buff_none();
			break;
		case BUFF::SUPER:
			_max_speed_x = SPEED::MOVE::BUFF_SUPER;
			_max_speed_y = SPEED::JUMP::BUFF_SUPER;
			_gravity = GRAVITY::BUFF_SUPER;
			erase();
			draw_buff_super();
			break;
		case BUFF::FLY:
			_max_speed_x = SPEED::MOVE::BUFF_FLY;
			_max_speed_y = SPEED::JUMP::BUFF_FLY;
			_gravity = GRAVITY::BUFF_FLY;
			erase();
			draw_buff_fly();
			break;
		case BUFF::POISON:
			_max_speed_x = SPEED::MOVE::BUFF_POISON;
			_max_speed_y = SPEED::JUMP::BUFF_POISON;
			_gravity = GRAVITY::BUFF_POISON;
			erase();
			draw_buff_poison();
			break;
		default:
			return;
		}
		// 设置玩家当前的 buff 状态
		_buff = buff;
		// 将最大速度和重力复制到备份变量中
		_max_speed_x_copy = _max_speed_x;
		_max_speed_y_copy = _max_speed_y;
		_gravity_copy = _gravity;
		// 限制玩家的速度，防止使用原来的速度
		limit_speed_x(_max_speed_x);
		limit_speed_y(_max_speed_y);
	}

	// 监听键盘事件
	void PicoPlayer::listen_keyboard(ExMessage& event)
	{
		if (_has_died)
		{
			update_clock();
			return;
		}
		clock_now = std::clock();
		if (GetAsyncKeyState(VK_UP) & 0x8000)
		{
			// 玩家跳跃
			jump(clock_now);
		}
		else
		{
			if (_player_jumped)
			{
				_player_jumped = false;
			}
			if (_speed_y < 0)
			{
				if (_can_control_jump)
				{
					_speed_y /= 2;
				}
			}
			else if (!_can_control_jump)
			{
				_can_control_jump = true;
			}
		}
		if (GetAsyncKeyState(VK_LEFT) & 0x8000)
		{
			move_left(clock_now);
		}
		else if (GetAsyncKeyState(VK_RIGHT) & 0x8000)
		{
			move_right(clock_now);
		}
		else
		{
			_player_stop();
		}
		drop(clock_now);
		_move(clock_now);
	}

	// 监听条件事件
	void PicoPlayer::listen_condition(bool jump_if, 
		bool left_if, bool right_if)
	{
		if (_has_died)
		{
			update_clock();
			return;
		}
		clock_now = std::clock();
		if (jump_if)
		{
			// 玩家跳跃
			jump(clock_now);
		}
		else
		{
			if (_player_jumped)
			{
				_player_jumped = false;
			}
			if (_speed_y < 0)
			{
				if (_can_control_jump)
				{
					_speed_y /= 2;
				}
			}
			else if (!_can_control_jump)
			{
				_can_control_jump = true;
			}
		}
		if (left_if)
		{
			move_left(clock_now);
		}
		else if (right_if)
		{
			move_right(clock_now);
		}
		else
		{
			_player_stop();
		}
		drop(clock_now);
		_move(clock_now);
	}

	// 监听键盘和条件事件
	void PicoPlayer::listen_keyboard_and_condition(ExMessage& event, 
		bool jump_if, bool left_if, bool right_if)
	{
		if (_has_died)
		{
			update_clock();
			return;
		}
		clock_now = std::clock();
		if ((GetAsyncKeyState(VK_UP) & 0x8000) || jump_if)
		{
			// 玩家跳跃
			jump(clock_now);
		}
		else
		{
			if (_player_jumped)
			{
				_player_jumped = false;
			}
			if (_speed_y < 0)
			{
				if (_can_control_jump)
				{
					_speed_y /= 2;
				}
			}
			else if (!_can_control_jump)
			{
				_can_control_jump = true;
			}
		}
		if ((GetAsyncKeyState(VK_LEFT) & 0x8000) || left_if)
		{
			move_left(clock_now);
		}
		else if ((GetAsyncKeyState(VK_RIGHT) & 0x8000) || right_if)
		{
			move_right(clock_now);
		}
		else
		{
			_player_stop();
		}
		drop(clock_now);
		_move(clock_now);
	}

	// 更新系统时钟
	void PicoPlayer::update_clock()
	{
		_player_jumped = false;
		clock_now = std::clock(); // 系统时钟
		last_jump = clock_now;
		last_move_x = clock_now;
		last_move_y = clock_now;
	}

	// 向左移动玩家
	void PicoPlayer::move_left(std::clock_t clock_now)
	{
		if (!can_move_left())
		{
			_speed_x = 0;
			return;
		}
		// 玩家的速度为自身最大速度 + 被动移动速度
		_speed_x = -_max_speed_x + _passive_move_speed;
	}

	// 向右移动玩家
	void PicoPlayer::move_right(std::clock_t clock_now)
	{
		if (!can_move_right())
		{
			_speed_x = 0;
			return;
		}
		// 玩家的速度为自身最大速度 + 被动移动速度
		_speed_x = _max_speed_x + _passive_move_speed;
	}

	// 使玩家下落
	void PicoPlayer::drop(std::clock_t clock_now)
	{
		// 玩家不可下落时，不下落
		if (!can_drop())  
		{
			if (_speed_y > 0)
			{
				_speed_y = 0;
			}
			last_jump = clock_now;
			return;
		}
		if (y + size + MOVE_STEP >= limit_bottom)
		{
			if (_speed_y != 0)
			{
				_speed_y = 0;
			}
			last_jump = clock_now;
			die(); // 掉落到底部时，玩家死亡
			return;
		}
		double dt = double(clock_now - last_jump) / CLOCKS_PER_SEC;
		if (dt >= 0.01)
		{
			_speed_y += int(_gravity * dt);
			last_jump = clock_now;
		}
	}

	// 使玩家跳跃
	void PicoPlayer::jump(std::clock_t clock_now)
	{
		// 如果有固定跳跃速度，则改为向上移动
		if (has_fixed_jump_speed())
		{
			_speed_y = -std::abs(_fixed_jump_speed);
			//_move(clock_now);
			return;
		}
		// 玩家跳跃
		if (!_player_jumped)
		{
			if (!can_jump()) return;
			_speed_y = -_max_speed_y;
			_move(clock_now);
			_player_jumped = true;
		}
	}

	// 使玩家人物死亡
	void PicoPlayer::die()
	{
		if (_has_died) return;
		_has_died = true;
		erase();
		draw_died();
	}

	// 重置玩家状态
	void PicoPlayer::reset_data()
	{
		base_reset();
		_speed_x = 0;
		_speed_y = 0;
		_max_speed_x = SPEED::MOVE::BUFF_NONE;
		_max_speed_y = SPEED::JUMP::BUFF_NONE;
		_gravity = GRAVITY::BUFF_NONE;
		_buff = BUFF::NONE;
		_has_died = false;
		_has_won = false;
		_coins_locked = false;
		_transferred = false;
		_keys_count = 0;
		_coins_count = 0;
		_jump_ability = 0;
		_drop_ability = 1;
		_move_left_ability = 1;
		_move_right_ability = 1;
		//--- 新增属性
		_max_speed_x_copy = _max_speed_x;
		_max_speed_y_copy = _max_speed_y;
		_gravity_copy = _gravity;
		_passive_move_speed = 0;
		_fixed_jump_speed = 0;
		_max_speed_x_set_count = 0;
		_max_speed_y_set_count = 0;
		_gravity_set_count = 0;
		_passive_move_set_count = 0;
		_fixed_jump_set_count = 0;
		// 清理状态
		update_clock();
	}

	// 玩家胜利
	void PicoPlayer::win()
	{
		if (_has_won) return;
		_has_won = true;
	}

	// 停止玩家上升
	void PicoPlayer::stop_shift()
	{
		_speed_y = 0;
		if (y + MOVE_STEP <= limit_bottom)
		{
			if (_has_died) return;
			erase();
			y += MOVE_STEP;
			draw();
		}
	}

	// 将玩家传送至下一个传送门
	void PicoPlayer::transfer_to_next(int now_x, int now_y, int off_x, int off_y)
	{
		// 如果已经胜利，则不传送
		if (has_won()) return;
		if (_transferables.empty())
		{
			throw std::runtime_error("No transferable elements.");
		}
		auto it = _transferables.upper_bound(
			std::make_pair(now_x, now_y));
		// 如果有下一个，则传送到下一个
		if (it != _transferables.end())
		{
			erase();
			this->x = it->first + off_x;
			this->y = it->second + off_y;
			draw();
		}
		// 否则传送到开始
		else
		{
			erase();
			auto fit = _transferables.begin();
			this->x = fit->first + off_x;
			this->y = fit->second + off_y;
			draw();
		}
	}

	// 克隆玩家
	PicoElement* PicoPlayer::clone() const
	{
		return new PicoPlayer(*this);
	}

	// 玩家停止的辅助函数
	void PicoPlayer::_player_stop()
	{
		if (_passive_move_speed < 0 && !can_move_left())
		{
			_speed_x = 0;
		}
		else if (_passive_move_speed > 0 && !can_move_right())
		{
			_speed_x = 0;
		}
		else
		{
			_speed_x = _passive_move_speed;
		}
	}

	// 移动玩家的辅助函数
	void PicoPlayer::_move(std::clock_t clock_now)
	{
		double dt_x = double(clock_now - last_move_x) / CLOCKS_PER_SEC;
		double dt_y = double(clock_now - last_move_y) / CLOCKS_PER_SEC;
		int ax = std::abs(_speed_x); // 速度 x 分量的绝对值
		int ay = std::abs(_speed_y); // 速度 y 分量的绝对值
		// 使玩家按照速度移动，间隔 = 速度的倒数；速度为 0 时，不移动
		// x 方向的移动
		if (ax > 0 && dt_x > 1.0 / ax * MOVE_STEP)
		{
			erase();
			if (_speed_x > 0)
			{
				if (x + size + MOVE_STEP <= limit_right)
				{
					x += MOVE_STEP;
				}
				else
				{
					_speed_x = 0;
				}
			}
			else if (_speed_x < 0)
			{
				if (x - MOVE_STEP >= limit_left)
				{
					x -= MOVE_STEP;
				}
				else 
				{
					_speed_x = 0;
				}
			}
			draw();
			last_move_x = clock_now;
		}
		// y 方向的移动
		if (ay > 0 && dt_y > 1.0 / ay * MOVE_STEP)
		{
			erase();
			if (_speed_y > 0)
			{
				if (y + size + MOVE_STEP <= limit_bottom)
				{
					y += MOVE_STEP;
				}
				else 
				{
					_speed_y = 0;
				}
			}
			else if (_speed_y < 0)
			{
				if (y - MOVE_STEP >= limit_top)
				{
					y -= MOVE_STEP;
				}
				else
				{
					_speed_y = 0;
				}
			}
			draw();
			last_move_y = clock_now;
		}
	}
}