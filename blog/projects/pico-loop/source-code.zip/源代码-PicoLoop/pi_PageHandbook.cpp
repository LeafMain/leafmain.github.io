﻿#include "picoloop.h"

// 图鉴页面类静态常量定义
namespace picoloop
{
	const int PageHandbook::PLAYGROUND_ROW = 12; // 游戏区行数
	const int PageHandbook::PLAYGROUND_COLUMN = 3; // 游戏区列数
	const COLORREF PageHandbook::COLOR::BACKGROUND = 0x111111; // 页面背景颜色
	const COLORREF PageHandbook::COLOR::BACKGROUND_INFO = 0x222222; // 信息背景颜色
	const COLORREF PageHandbook::COLOR::PANEL_LINE = DARKGRAY; // 面板边框颜色
	const COLORREF PageHandbook::COLOR::PANEL_SELECT = LIGHTGREEN; // 面板选中颜色
	const COLORREF PageHandbook::COLOR::TITLE = CYAN; // 页面标题颜色
	const COLORREF PageHandbook::COLOR::REGION_TITLE = BROWN; // 区域标题颜色
	const COLORREF PageHandbook::COLOR::BOTTOM_TIPS = 0x555555; // 底部提示颜色
	const COLORREF PageHandbook::COLOR::DIVIDER = DARKGRAY; // 页面标题颜色
	const COLORREF PageHandbook::COLOR::BRIEF = 0x11AA22; // 简要信息颜色
	const COLORREF PageHandbook::COLOR::DETAIL = 0xDDDDDD; // 详细信息颜色
	const COLORREF PageHandbook::COLOR::BUTTON_FUNC = 0x008080; // 功能按钮颜色
	const COLORREF PageHandbook::COLOR::BUTTON_FUNC_HOVER = 0x00BFFF; // 功能按钮颜色
	const COLORREF PageHandbook::COLOR::BUTTON_EXIT = LIGHTGRAY; // 退出按钮颜色
	const COLORREF PageHandbook::COLOR::BUTTON_EXIT_HOVER = DARKGRAY; // 退出按钮颜色
	const LPCTSTR PageHandbook::FONT::TITLE_FONT = _T("Arial Rounded MT Bold"); // 页面标题字体
	const LPCTSTR PageHandbook::FONT::BRIEF_FONT = _T("Arial Bold"); // 简要信息字体
	const LPCTSTR PageHandbook::FONT::DETAIL_FONT = _T("Arial"); // 详细信息字体
	const LPCTSTR PageHandbook::FONT::BUTTON_FONT = _T("Arial Rounded MT Bold"); // 按钮字体
	const int PageHandbook::FONT_SIZE::BRIEF_INFO = 45; // 简要信息字体大小
	const int PageHandbook::FONT_SIZE::DETAIL_INFO = 28; // 详细信息字体大小
	const int PageHandbook::FONT_SIZE::DETAIL_INFO_LARGE = 32; // 详细信息大字体大小
}

// 图鉴页面类实现
namespace picoloop
{
	// 图鉴页面类构造函数
	PageHandbook::PageHandbook(Game& game) 
		: Page(game), game_title(220, 13, 0.5),
		select_panel{
			20, 60, 3, 26, 40, COLOR::PANEL_LINE, 
			COLOR::PANEL_LINE, COLOR::PANEL_SELECT
		}, element_showcase{
			1062, 60, 120, 20, PicoElementCollection::EMPTY,
			COLOR::PANEL_LINE, 2, PS_SOLID
		}, element_data{
			19, 300, PLAYGROUND_ROW, PLAYGROUND_COLUMN, 40, COLOR::BACKGROUND
		}, playground(element_data),
		button_select{
			1072, 290, 100, 80, 4, 4, 30, 1, PS_SOLID, _T("Levels"), 
			FONT::BRIEF_FONT, COLOR::BACKGROUND, COLOR::BUTTON_FUNC, 
			COLOR::BUTTON_FUNC, COLOR::BACKGROUND, COLOR::BUTTON_FUNC_HOVER,
			COLOR::BUTTON_FUNC_HOVER, COLOR::BACKGROUND, COLOR::BUTTON_FUNC_HOVER,
			COLOR::BUTTON_FUNC_HOVER
		}, button_editor{
			1072, 390, 100, 80, 4, 4, 32, 1, PS_SOLID, _T("Editor"), 
			FONT::BRIEF_FONT, COLOR::BACKGROUND, COLOR::BUTTON_FUNC, 
			COLOR::BUTTON_FUNC, COLOR::BACKGROUND, COLOR::BUTTON_FUNC_HOVER,
			COLOR::BUTTON_FUNC_HOVER, COLOR::BACKGROUND, COLOR::BUTTON_FUNC_HOVER,
			COLOR::BUTTON_FUNC_HOVER
		}, button_stage{
			1072, 490, 100, 80, 4, 4, 33, 1, PS_SOLID, _T("Stage"), 
			FONT::BRIEF_FONT, COLOR::BACKGROUND, COLOR::BUTTON_FUNC, 
			COLOR::BUTTON_FUNC, COLOR::BACKGROUND, COLOR::BUTTON_FUNC_HOVER,
			COLOR::BUTTON_FUNC_HOVER, COLOR::BACKGROUND, COLOR::BUTTON_FUNC_HOVER,
			COLOR::BUTTON_FUNC_HOVER
		}, button_keydown{
			1072, 590, 100, 80, 4, 4, 25, 1, PS_SOLID, _T("Keydown"), 
			FONT::BRIEF_FONT, COLOR::BACKGROUND, COLOR::BUTTON_FUNC, 
			COLOR::BUTTON_FUNC, COLOR::BACKGROUND, COLOR::BUTTON_FUNC_HOVER,
			COLOR::BUTTON_FUNC_HOVER, COLOR::BACKGROUND, COLOR::BUTTON_FUNC_HOVER,
			COLOR::BUTTON_FUNC_HOVER
		}, button_exit{
			1072, 690, 100, 80, 4, 4, 30, 1, PS_SOLID, _T("Back"), 
			FONT::BUTTON_FONT, COLOR::BACKGROUND, COLOR::BUTTON_EXIT, 
			COLOR::BUTTON_EXIT, COLOR::BACKGROUND, COLOR::BUTTON_EXIT_HOVER,
			COLOR::BUTTON_EXIT_HOVER
		}, _panel_selected_type(PicoElementCollection::EMPTY)
	{}

	// 绘制页面
	void PageHandbook::draw_page() const
	{
		// 绘制游戏标题
		game_title.draw();
		_draw_page_title();
		select_panel.draw();
		element_showcase.draw();
		// 开始批量绘制
		BeginBatchDraw();
		_draw_divider();
		_draw_region_text();
		// 绘制按钮
		button_select.draw();
		button_editor.draw();
		button_stage.draw();
		button_keydown.draw();
		button_exit.draw();
		EndBatchDraw();
		
	}

	// 页面进入前调用
	void PageHandbook::on_enter()
	{
		// 取消默认睡眠时间
		game.set_sleep_time(0); 
		_reset_page();
	}

	// 页面进入后调用
	void PageHandbook::on_after_enter()
	{
		select_panel.select_first();
	}

	// 页面离开前调用
	void PageHandbook::on_leave()
	{
		// 恢复默认睡眠时间
		game.set_sleep_time(Game::DEFUALT_SLEEP_TIME);
		playground.stop();
	}

	// 重置页面
	void PageHandbook::_reset_page()
	{
		_panel_selected_type = TYPE::EMPTY;
	}

	// 退出页面
	void PageHandbook::exit_page()
	{
		// 如果没有设置 _prev_page，则返回上一页
		enter(previous_page());
	}

	// 绘制页面标题
	void PageHandbook::_draw_page_title() const
	{
		settextcolor(COLOR::TITLE);
		settextstyle(50, 0, FONT::TITLE_FONT);
		RECT rect = { 500, 5, 1000, 55 };
		LPCTSTR text = _T("Illustrated Handbook");
		drawtext(text, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}

	// 显示元素信息
	void PageHandbook::show_element_info(TYPE type)
	{
		switch (type)
		{
		case TYPE::PLAYER:
		{
			_draw_brief_info(_T("Player"));
			_draw_detail_info(_T(
				"\tThe player element is the main character of the game. "
				"It can move around the map and interact with the environment. "
				"It can also collect keys and coins. \n"
				"\tWhen you lead the player to the flag element, you win the game; "
				"but if you let it fall into the bottom of the map or bump "
				"some fatal elements, you will lose the game and have to restart. \n"
				"\tThere may be some buffs or debuffs for the player, "
				"which can be obtained by collecting certain items. \n\n"
				"\tMove left: Press the left arrow key; \n"
				"\tMove right: Press the right arrow key; \n"
				"\tJump: Press the up arrow key. \n"
			));
			break;
		}
		case TYPE::KEY:
		{
			_draw_brief_info(_T("Key"));
			_draw_detail_info(_T(
				"\tThe key element is used to unlock the flag so that you can win. \n"
				"Before winning the game, you need to collect all the keys, otherwise, "
				"you will never win even if you have already been standing on the flag. \n\n"
				"\tYou can collect keys by running into them or by jumping on them. \n\n"
				"\tThe amount of keys you have collected will be shown on the "
				"middle left of the stage screen (in the first line). \n"
			));
			break;
		}
		case TYPE::FLAG:
		{
			_draw_brief_info(_T("Flag"));
			_draw_detail_info(_T(
				"\tThe flag element is the final goal of the player's adventure. \n"
				"You should spare no effort to reach it!\n\n"
				"\tIf there are keys for the flags, you must collect them first "
				"in order to unlock these locked flags and win the game. \n\n"
				"\tThere may be more than on flag in a game, but you can win "
				"as long as you have found all the keys and have reached one. \n\n"
				"Let's lead the player to the flag element! \n"
			));
			break;
		}
		case TYPE::BRICK:
		{
			_draw_brief_info(_T("Brick"));
			_draw_detail_info(_T(
				"\tThe brick element will prevent the player from moving and jumping. \n"
				"It can never be destroyed even if you push or pedal on it. \n\n"
				"\tHowever, when you stand on a brick, it will support you, and "
				"you will be able to jump (you can't jump in the air). \n\n"
				"\tThe bricks serve as main barriers to the player, "
				"so it is important to make best use of them. \n\n"
			));
			break;
		}
		case TYPE::FIRE:
		{
			_draw_brief_info(_T("Fire"));
			_draw_detail_info(_T(
				"\tThe fire element is a fatal element that can immediately kill "
				"the player, even if you have just touched a corner. \n\n"
				"\tYou should be aware of it and avoid it at all costs. \n\n"
				"\tBut how to avoid the fire? \n\n"
				"\t1. Avoid standing on the fire; \n"
				"\t2. Avoid running into the fire; \n"
				"\t3. Avoid jumping on the fire. \n\n"
				"\tMoreover, be careful to move near the fire! \n"
			));
			break;
		}
		case TYPE::COIN:
		{
			_draw_brief_info(_T("Coin"));
			_draw_detail_info(_T(
				"\tThe coin element is a small item that can be collected by the player. "
				"You need not collect all the coins before winning the game.\n\n"
				"\tYou can collect coins by running into them or by jumping on them. "
				"They cannot be collected when locked, but you can stand on them.\n\n"
				"\tActually, you can touch coin-lock buttons to lock/unlock all coins. \n\n"
				"\tThe amount of coins you have collected will be shown on the "
				"middle left of the stage screen (in the second line). \n"
			));
			break;
		}
		case TYPE::SUPER_SHOE:
		{
			_draw_brief_info(_T("Super Shoe"));
			_draw_detail_info(_T(
				"\tThe super shoe element is a special item that can be collected "
				"by the player. It can be used to boost the player's jump speed and "
				"jump height. \n\n"
				"\tThe normal jump height is 4.5 grids, but with the super shoe, "
				"you can jump higher, up to 7 grids. \n\n"
				"\tnote: \n"
				"\tThe buff will last continuously until you had picked other buffs.\n"
				"\tThe effect of jump enhancement cannot be stacked.\n\n"
				"\tYou can collect them by running into it or by jumping on it. "
				"Then the player's body is going to become light purple."
			));
			break;
		}
		case TYPE::WINGS:
		{
			_draw_brief_info(_T("Wings"));
			_draw_detail_info(_T(
				"\tThe wings element is a special item that can be collected "
				"by the player. It can lessen the player's gravity, like flying in the air.  \n\n"
				"\tSpecifically, it can double the player's horizontal moving speed and "
				"lightly boost the player's jumping height (up to 5.5 grids).\n"
				"\tMoreover, the player's gravity will become 3/4 of the normal value.\n\n"
				"\tnote: \n"
				"\tThe buff will last continuously until you had picked other buffs.\n"
				"\tThe effect of the wings cannot be stacked.\n\n"
				"\tYou can collect them by running into it or by jumping on it. "
				"Then the player's body is going to become light blue."
			));
			break;
		}
		case TYPE::POISON:
		{
			_draw_brief_info(_T("Poison"));
			_draw_detail_info(_T(
				"\tThe poison element is a special item that can be collected by the "
				"player. It can harm the player's physical health! How it works?\n\n"
				"\tFirstly, it can halve the player's horizontal moving speed;\n"
				"\tSecondly, it can greatly reduce the player's jumping height "
				"(from 4.5 grids to 2.5 grids). \n\n"
				"\tHowever, \"every coin has two sides.\" It may help you slow down "
				"when you need precisive moving, especially when you attempt to enter "
				"the middle of two fatal elements. \n\n"
				"\tThe buff will last continuously until you had picked other buffs.\n"
				"\tThe effect of the poison cannot be stacked.\n"
				"\tOnce collected, the player's body will become dark purple."
			));
			break;
		}
		case TYPE::ANTIDOTE:
		{
			_draw_brief_info(_T("Antidote"));
			_draw_detail_info(_T(
				"\tThe antidote element is a special item that can be collected "
				"by the player. It can cure the player's buff effect, such as "
				"super shoe, wings, and poison. \n\n"
				"\tHowever, it can only be used once, so be careful to use it "
				"when you need it. \n\n"
				"\tThe effect of the antidote will last, until you had picked new buffs.\n\n"
				"\tIf you have no buffs, it's no effect to obtain the antidote.\n\n"
				"\tWhen collected, the player's body will recover to its normal color."
			));
			break;
		}
		case TYPE::STONE:
		{
			_draw_brief_info(_T("Stone"));
			_draw_detail_info(_T(
				"\tThe stone element is a barrier that can prevent the player from "
				"moving and jumping, just like the brick elements. \n\n"
				"\tActually, it functions the same as the brick elements, but it "
				"has a different appearance. \n\n"
				"\tStones will shake a bit if you bump them.\n\n"
				"\tThe common color of stones are light gray. However, there are "
				"many colorful stones added to the game, such as red, orange, yellow, "
				"green, blue, purple, etc. They have been listed in the element "
				"selector panel.\n\n"
			));
			break;
		}
		case TYPE::RED_STONE:
		{
			_draw_brief_info(_T("Red Stone"));
			_draw_detail_info(_T(
				"\tThe red stone element is a kind of stones, preventing the player "
				"from moving and jumping. \n\n"
				"\tIt is a variation of the stone element, with the same function but "
				"a different appearance. \n\n"
				"\t- Why need I use red stones? \n"
				"\t- I can decorate my own stage with these red stones "
				"to make it more attractive. Thay are like apples.\n\n"
			));
			break;
		}
		case TYPE::ORANGE_STONE:
		{
			_draw_brief_info(_T("Orange Stone"));
			_draw_detail_info(_T(
				"\tThe orange stone element is a kind of stones, preventing the player "
				"from moving and jumping. \n\n"
				"\tIt is a variation of the stone element, with the same function but "
				"a different appearance. \n\n"
				"\t- Why need I use orange stones? \n"
				"\t- I can decorate my own stage with these orange stones "
				"to make it more attractive. They are like oranges.\n\n"
			));
			break;
		}
		case TYPE::YELLOW_STONE:
		{
			_draw_brief_info(_T("Yellow Stone"));
			_draw_detail_info(_T(
				"\tThe yellow stone element is a kind of stones, preventing the player "
				"from moving and jumping. \n\n"
				"\tIt is a variation of the stone element, with the same function but "
				"a different appearance. \n\n"
				"\t- Why need I use yellow stones? \n"
				"\t- I can decorate my own stage with these yellow stones "
				"to make it more attractive. They are like bananas.\n\n"
			));
			break;
		}
		case TYPE::GREEN_STONE:
		{
			_draw_brief_info(_T("Green Stone"));
			_draw_detail_info(_T(
				"\tThe green stone element is a kind of stones, preventing the player "
				"from moving and jumping. \n\n"
				"\tIt is a variation of the stone element, with the same function but "
				"a different appearance. \n\n"
				"\t- Why need I use green stones? \n"
				"\t- I can decorate my own stage with these green stones "
				"to make it more attractive. They are like the grass.\n\n"
			));
			break;
		}
		case TYPE::BLUE_STONE:
		{
			_draw_brief_info(_T("Blue Stone"));
			_draw_detail_info(_T(
				"\tThe blue stone element is a kind of stones, preventing the player "
				"from moving and jumping. \n\n"
				"\tIt is a variation of the stone element, with the same function but "
				"a different appearance. \n\n"
				"\t- Why need I use blue stones? \n"
				"\t- I can decorate my own stage with these blue stones "
				"to make it more attractive. They are like the sea.\n\n"
			));
			break;
		}
		case TYPE::CYAN_STONE:
		{
			_draw_brief_info(_T("Cyan Stone"));
			_draw_detail_info(_T(
				"\tThe cyan stone element is a kind of stones, preventing the player "
				"from moving and jumping. \n\n"
				"\tIt is a variation of the stone element, with the same function but "
				"a different appearance. \n\n"
				"\t- Why need I use cyan stones? \n"
				"\t- I can decorate my own stage with these cyan stones "
				"to make it more attractive. They are like the sky.\n\n"
			));
			break;
		}
		case TYPE::PURPLE_STONE:
		{
			_draw_brief_info(_T("Purple Stone"));
			_draw_detail_info(_T(
				"\tThe purple stone element is a kind of stones, preventing the player "
				"from moving and jumping. \n\n"
				"\tIt is a variation of the stone element, with the same function but "
				"a different appearance. \n\n"
				"\t- Why need I use purple stones? \n"
				"\t- I can decorate my own stage with these purple stones "
				"to make it more attractive. They are like grapes.\n\n"
			));
			break;
		}
		case TYPE::PINK_STONE:
		{
			_draw_brief_info(_T("Pink Stone"));
			_draw_detail_info(_T(
				"\tThe pink stone element is a kind of stones, preventing the player "
				"from moving and jumping. \n\n"
				"\tIt is a variation of the stone element, with the same function but "
				"a different appearance. \n\n"
				"\t- Why need I use pink stones? \n"
				"\t- I can decorate my own stage with these pink stones "
				"to make it more attractive. They are like peaches.\n\n"
			));
			break;
		}
		case TYPE::WHITE_STONE:
		{
			_draw_brief_info(_T("White Stone"));
			_draw_detail_info(_T(
				"\tThe white stone element is a kind of stones, preventing the player "
				"from moving and jumping. \n\n"
				"\tIt is a variation of the stone element, with the same function but "
				"a different appearance. \n\n"
				"\t- Why need I use white stones? \n"
				"\t- I can decorate my own stage with these white stones "
				"to make it more attractive. They are like white walls.\n\n"
			));
			break;
		}
		case TYPE::ONE_USED_DOOR:
		{
			_draw_brief_info(_T("One-Used Door"));
			_draw_detail_info(_T(
				"\tThe one-used door element can be merely passed through once. \n\n"
				"\tIf a one-used door is open in your way, you can pass through it, "
				"but remember that you only have one chance. Because the door will "
				"close and become a barrier once the player has passed through it. \n\n"
				"\tThe player can pass through one-used doors from their left or right.\n\n"
				"\tDon't try to return back while the door is closing. Otherwise, the\n"
				"player will get stuck and finally die. \n"
			));
			break;
		}
		case TYPE::UP_RIGHT_TUBE:
		{
			_draw_brief_info(_T("Up-Right Tube"));
			_draw_detail_info(_T(
				"\tThe up-right tube element allows the player to dive into it "
				"and pass through it in correct direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::NO_UP_TUBE:
		{
			_draw_brief_info(_T("No-Up Tube"));
			_draw_detail_info(_T(
				"\tThe no-up tube element allows the player to dive into it "
				"and pass through it in correct direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::UP_LEFT_TUBE:
		{
			_draw_brief_info(_T("Up-Left Tube"));
			_draw_detail_info(_T(
				"\tThe up-left tube element allows the player to dive into it "
				"and pass through it in correct direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::NO_LEFT_TUBE:
		{
			_draw_brief_info(_T("No-Left Tube"));
			_draw_detail_info(_T(
				"\tThe no-left tube element allows the player to dive into it "
				"and pass through it in correct direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::INTERSECT_TUBE:
		{
			_draw_brief_info(_T("Intersect Tube"));
			_draw_detail_info(_T(
				"\tThe intersect tube element allows the player to dive into it "
				"and pass through it in correct direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::NO_RIGHT_TUBE:
		{
			_draw_brief_info(_T("No-Right Tube"));
			_draw_detail_info(_T(
				"\tThe no-right tube element allows the player to dive into it "
				"and pass through it in correct direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::DOWN_RIGHT_TUBE:
		{
			_draw_brief_info(_T("Down-Right Tube"));
			_draw_detail_info(_T(
				"\tThe down-right tube element allows the player to dive into it "
				"and pass through it in correct direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::NO_DOWN_TUBE:
		{
			_draw_brief_info(_T("No-Down Tube"));
			_draw_detail_info(_T(
				"\tThe no-down tube element allows the player to dive into it "
				"and pass through it in correct direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::DOWN_LEFT_TUBE:
		{
			_draw_brief_info(_T("Down-Left Tube"));
			_draw_detail_info(_T(
				"\tThe down-left tube element allows the player to dive into it "
				"and pass through it in correct direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::HORIZONTAL_TUBE:
		{
			_draw_brief_info(_T("Horizontal Tube"));
			_draw_detail_info(_T(
				"\tThe horizontal tube element allows the player to dive into it "
				"and pass through it in horizontal direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::VERTICAL_TUBE:
		{
			_draw_brief_info(_T("Vertical Tube"));
			_draw_detail_info(_T(
				"\tThe vertical tube element allows the player to dive into it "
				"and pass through it in vertical direction. \n\n"
				"\tIt limits the player's movement and jumping, protecting the player "
				"from elements that can harm the player. \n\n"
				"\tThere are 11 kinds of tubes in the game, "
				"each with a different direction. \n\n"
			));
			break;
		}
		case TYPE::SOIL:
		{
			_draw_brief_info(_T("Soil"));
			_draw_detail_info(_T(
				"\tThe soil element is a barrier for the player, but it can "
				"be cleared by bumping it with the player's head. \n\n"
				"\tThe player can stand stably on soils, won't fall down. \n\n"
				"\t The soil element may always prevent the player from moving until "
				"it had been cleared. It can only be cleared by the player's head, "
				"not by other ways, such as the player's body.\n\n"
				"\tSometimes, you need to be careful to clear soils. Casual clearance "
				"of soils might cause road damage or other problems. \n\n"
			));
			break;
		}
		case TYPE::WATER:
		{
			_draw_brief_info(_T("Water"));
			_draw_detail_info(_T(
				"\tThe water element is a different environment for the player. \n\n"
				"\tWhen getting into the water, the player will be slowly sinking "
				"due to the floating effect. Speed will also be reduced. \n"
				"\tThe player can jump in the water but with a very limited height.\n\n"
				"\tdetails:\n\n"
				"\t1. The moving speed in water is half of the moving speed in air. \n"
				"\t2. The player is able to jump at any time as long as it is "
				"within the water, but the height is limited to 1 grid. \n"
				"\t3. The player will sink slowly if it is not jumping. \n"
			));
			break;
		}
		case TYPE::LADDER:
		{
			_draw_brief_info(_T("Ladder"));
			_draw_detail_info(_T(
				"\tThe ladder element is a tool for the player to climb up. \n\n"
				"\tThe player can climb up ladders by pressing the up key. \n\n"
				"\tDetails:\n"
				"\t1.The climbing speed is 3/4 of normal jumping speed "
				"(but only 1/2 in poison buff). \n\n"
				"\t2. The player can jump if standing on the top of ladders. \n\n"
				"\t3. Ladders make no difference on the player's left or right "
				"movement, as well as droping. \n\n"
			));
			break;
		}
		case TYPE::TRANSPARENT_BRICK:
		{
			_draw_brief_info(_T("Transparent Brick"));
			_draw_detail_info(_T(
				"\tThe transparent brick element is invisible and untouchable "
				"to the player. \n\n"
				"\tYou can see the dashed outline of the brick when it is "
				"invisible to the player. \n\n"
				"\tHowever, when the player's head touches the bottom of the brick, "
				"it will appear and become a visible brick, which serves as a "
				"barrier for the player. \n\n"
				"\tThe emergence of invisible bricks may block vertical roads. "
				"So you'd better using them wisely. \n\n"
			));
			break;
		}
		case TYPE::LEFT_CONVEYOR:
		{
			_draw_brief_info(_T("Left Conveyor"));
			_draw_detail_info(_T(
				"\tThe left conveyor element can carry the player so that the "
				"player can automatically move left.\n\n"
				"\tWhen the player stands on a left conveyor, it will receive a "
				"force and be carried to the left direction. \n\n"
				"\tThe speed of conveyors is half of the player's. They effects on the "
				"Player's speed. The player moves fast at left direction, but moves "
				"slowly at right direction.\n\n"
				"\tSpecially, if the player has poison buff or is in water, it can't "
				"move towards the opposite direction when standing on a conveyor. "
				"If you do this, the player will just stand still.\n"
			));
			break;
		}
		case TYPE::RIGHT_CONVEYOR:
		{
			_draw_brief_info(_T("Right Conveyor"));
			_draw_detail_info(_T(
				"\tThe right conveyor element can carry the player so that the "
				"player can automatically move right.\n\n"
				"\tWhen the player stands on a right conveyor, it will receive a "
				"force and be carried to the right direction. \n\n"
				"\tThe speed of conveyors is half of the player's. They effects on the "
				"Player's speed. The player moves fast at right direction, but moves "
				"slowly at left direction.\n\n"
				"\tSpecially, if the player has poison buff or is in water, it can't "
				"move towards the opposite direction when standing on a conveyor. "
				"If you do this, the player will just stand still.\n"
			));
			break;
		}
		case TYPE::BOUNCE_BED:
		{
			_draw_brief_info(_T("Bounce Bed"));
			_draw_detail_info(_T(
				"\tThe bounce bed element can force the player to jump up.\n\n"
				"\tWhen the player jump into a bounce bed, it will give a "
				"force to the player so that the player will shift fast. \n\n"
				"\tWhen this happened, the player's jump height will reach up to "
				"9 grids,and player can't control its vertical speed during "
				"the jump process.\n\n"
				"\tSpecially, if the player peacefully stands on the bounce bed "
				"without a tiny jump, the bed will not effect.\n"
			));
			break;
		}
		case TYPE::UP_BRICK_THRUST:
		{
			_draw_brief_info(_T("Up Brick Thrust"));
			_draw_detail_info(_T(
				"\tThe up brick thrust element can kill the player once it "
				"touched the top surface with perilous thrusts. \n\n"
				"\tThe element derives from bricks. Because something fell on "
				"the top of the element, the player can no longer stand on it.\n\n"
				"\tHowever, players can still touch its left surface, right "
				"surface, and bottom surface. These surfaces will just stop "
				"the player from moving, like bricks. \n\n"
			));
			break;
		}
		case TYPE::DOWN_BRICK_THRUST:
		{
			_draw_brief_info(_T("Down Brick Thrust"));
			_draw_detail_info(_T(
				"\tThe down brick thrust element can kill the player once it "
				"touched the bottom surface with perilous thrusts. \n\n"
				"\tThe element derives from bricks. Because something stuck on "
				"the bottom of the element, the player can no longer jump on it.\n\n"
				"\tHowever, players can still touch its left surface, right "
				"surface, and top surface. These surfaces will just stop "
				"the player from moving, like bricks. \n\n"
			));
			break;
		}
		case TYPE::LEFT_BRICK_THRUST:
		{
			_draw_brief_info(_T("Left Brick Thrust"));
			_draw_detail_info(_T(
				"\tThe left brick thrust element can kill the player once it "
				"touched the left surface with perilous thrusts. \n\n"
				"\tThe element derives from bricks. Because something fixed on "
				"the left of the element, the player can no longer push it right.\n\n"
				"\tHowever, players can still touch its top surface, right "
				"surface, and bottom surface. These surfaces will just stop "
				"the player from moving, like bricks. \n\n"
			));
			break;
		}
		case TYPE::RIGHT_BRICK_THRUST:
		{
			_draw_brief_info(_T("Right Brick Thrust"));
			_draw_detail_info(_T(
				"\tThe right brick thrust element can kill the player once it "
				"touched the right surface with perilous thrusts. \n\n"
				"\tThe element derives from bricks. Because something fixed on "
				"the right of the element, the player can no longer push it left.\n\n"
				"\tHowever, players can still touch its top surface, left "
				"surface, and bottom surface. These surfaces will just stop "
				"the player from moving, like bricks. \n\n"
			));
			break;
		}
		case TYPE::COIN_LOCKER:
		{
			_draw_brief_info(_T("Coin Locker"));
			_draw_detail_info(_T(
				"\tThe coin locker element can lock/unlock all coins in the stage."
				"This disables the player to collect any coins.\n\n"
				"\tWhen the player stands on the locker, all coins will be locked or"
				"unlocked. The locked coins serve as gray bricks, enabling the player"
				"to stand on and jump on them. Only unlocked coins can be collected. \n\n"
				"\tIt should be noticed that if the player stands on between the gap of "
				"two coin lockers, the lockers will not lock/unlock coins, since you "
				"have pressed two buttons simultaneously. \n\n"
			));
			break;
		}
		case TYPE::DOWN_LIFT:
		{
			_draw_brief_info(_T("Down Lift"));
			_draw_detail_info(_T(
				"\tThe down lift element is a special one-time platform that reacts to "
				"player's movement. \n\n"
				"\tIt vanishes instantly when stepped on with downward momentum. "
				"Only supports the player if landing with zero vertical velocity.\n\n"
				"\tIt acts as a solid block when touched from the side or below and"
				"creates risky and strategic platforming challenges.\n\n"
				"\tYou should test your timing and positioning to stand on it safely.\n\n"
			));
			break;
		}
		case TYPE::UP_BUTTER_BRICK:
		{
			_draw_brief_info(_T("Up Butter Brick"));
			_draw_detail_info(_T(
				"\tThe up butter brick element can change player's movement and jumping."
				"It halves player speed and stops normal jumps with strong stickiness.\n\n"
				"\tIt is solid from all sides and creates careful platform challenges. "
				"\tOnly the super buff can resist its effect and make a one-grid jump. "
				"Poison buff slows you more, and flying buff keeps your normal speed.\n\n"
				"\tYou are supposed to be careful to avoid being trapped on it.\n"
				"\tIt may cause the player losing capacity to jump out from it.\n\n"
			));
			break;
		}
		case TYPE::DOWN_BUTTER_BRICK:
		{
			_draw_brief_info(_T("Down Butter Brick"));
			_draw_detail_info(_T(
				"\tThe down butter brick element can stick the player on the butter ceil."
				"It stops the player from dropping and halves its horizontal speed.\n\n"
				"\tIt is solid from all sides and creates careful platform challenges."
				"\tPlayer will not get rid of unless the player try to move out from "
				"its butter surface or push some obstacles which produce a force.\n"
				"This may be helpful since you can avoid some fatal elements.\n\n"
				"\tYou are supposed to be careful to avoid being trapped on it.\n\n"
			));
			break;
		}
		case TYPE::TELEPORT_GATE:
		{
			_draw_brief_info(_T("Teleport Gate"));
			_draw_detail_info(_T(
				"\tThe teleport gate element can instantly send players to another position."
				"It creates fast travel and sudden spatial shifts across the game world.\n\n"
				"\tIt works on touch and triggers immediate relocation without delay. "
				"\tMost gates link to fixed target points and form one-way connections. "
				"Some advanced types can send you to random or dynamic destinations.\n\n"
				"\tMaster its layout to move quickly and bypass dangerous obstacles.\n"
				"\tMisuse may lead to unexpected traps or unreachable areas.\n\n"
			));
		}
		default: // 未知类型，不显示信息
			break;
		}
	}

	// 点击右侧按钮
	void PageHandbook::click_right_button(RIGHT_BUTTON button)
	{
		// 如果已经点击则不重复操作
		if (button == _button_now) return;
		_button_now = button;
		switch (button)
		{
		case RIGHT_BUTTON::SELECT:
		{
			_draw_brief_info(_T("Level Select Page Help"));
			_draw_detail_info(_T(
				"\tYou can select levels to play pre-designed levels or make "
				"your own levels. Just click on the button of level you want "
				"to play or make, and then the game will start. \n\n"
				"details:\n"
				"\t1. The play levels are made by the developers, "
				"You can only play them;\n\n"
				"\t2. The make levels are created by yourself, "
				"You can create them, modify them, save them, and play them; \n\n"
				"\t3. The amount of make levels are limited to 84, which means "
				"that you can at most create 84 levels. \n\n"
				"\tSo let's play and make levels to start your journey with PicoLoop!"
			), false);
			break;
		}
		case RIGHT_BUTTON::EDITOR:
		{
			_draw_brief_info(_T("Editor Page Help"));
			_draw_detail_info(_T(
				"\tThe editor page are designed for you to create your own levels! \n"
				"You can create levels by putting elements on your own stage. \n"
				"\tThere are many functions in the editor, including:\n"
				"\t1. Create elements: click an element on the panel, then click on an "
				"empty space on the stage to create it. \n"
				"\t2. Delete elements: select an element on the editor, then press the "
				"\"delete\" button, \" Delete\" key or right-clicking on it to delete it.\n"
				"\t3. Move elements: select an element on the editor, then drag it to "
				"the desired position to place it. \n"
				"\t4. Clear all: click the \"clear all\" button or press\"Ctrl + Delete\" "
				"to clear all elements on the editor.\n"
				"\t5. Undo && Redo: click the \"undo\" and \"redo\" buttons or press "
				"\"Ctrl + Z\" and \"Ctrl + Y\" to undo and redo your actions. \n"
				"\t6. Play: click the \"play\" button or press \"Enter\" to play your level.\n"
				"\t7. Save: click the \"save\" button or press \"Ctrl + S\" to save level."
				"\n\tYour data will be saved in \"C:\\LeafMain\\PicoLoop\\Data\\\"."
			), false);
			break;
		}
		case RIGHT_BUTTON::STAGE:
		{
			_draw_brief_info(_T("Stage Page Help"));
			_draw_detail_info(_T(
				"\tThe stage page is the main part of the game. "
				"It is where the player can move and interact with the elements, "
				"in the purpose of reaching the final goal and winning the game. \n"
				"Opeartive skills:\n"
				"\t1. Move: use the arrow keys or click the \"left\" or \"right\" button "
				"to move the player in the left or right directions in the stage. \n"
				"\t2. Jump: press the up arrow key or click the \"jump\" button to "
				"jump on the elements. \n"
				"Button functions:\n"
				"\tBack: go back to the previous page. \n"
				"\tPause: pause the game, the player and elements will stop moving. \n"
				"\tReplay: replay the game, when you make a mistake . \n\n"
				"\tPrint screen: print the screen of the game, it will be saved as a picture "
				"(.bmp) in \"C:\\LeafMain\\PicoLoop\\PrtSc\\\". \n"
				"\tHelp: show the help information of the current page. \n"
			), false);
			break;
		}
		case RIGHT_BUTTON::KEYDOWN:
		{
			_draw_brief_info(_T("Key Shortcuts in PicoLoop"));
			_draw_detail_info(_T(
				"\tThere are some key shortcuts to improve the game experience:\n"
				"In any pages:\n\t press \"Esc\" to return to the previous page. \n"
				"In the main menu:\n\t press \"P\" to play, \"M\" to make;\n"
				"In the level selecting page:\n\t press arrow keys or \"Tab\" "
				"to select levels, then press \"Enter\" to play \n\tor make them; " 
				"press \"H\" for help.\n"
				"In the editor page:\n\t press arrow keys or \"Tab\" to move the player, "
				"\"Delete\" key or right-click \n\tto delete elements, "
				"\"Ctrl + Backspace(or Delete)\" to clear all elements, \n\t"
				"\"Ctrl + Z\" and \"Ctrl + Y\" to undo and redo actions, \n\t"
				"\"Ctrl + S\" to save level, \"Ctrl + H\" for help. \n"
				"In the stage page:\n\t press arrow keys to move the player, "
				"\"Space\" key to pause the game, \n\t \"Backspace\" or \"R\" to replay,"
				"press \"P\" to print screen, \"H\" for help. \n"
			), false);
			break;
		}
		}
	}

	// 绘制简要信息
	void PageHandbook::_draw_brief_info(LPCTSTR text) const
	{
		settextcolor(COLOR::BRIEF);
		setbkmode(TRANSPARENT);
		setfont(FONT_SIZE::BRIEF_INFO, 0, FONT::BRIEF_FONT);
		RECT rect = { 148, 202, 1060, 258 };
		// 绘制与背景色相同的矩形，以覆盖上一页的文字
		setfillcolor(COLOR::BACKGROUND_INFO);
		solidrectangle(rect.left, rect.top, rect.right, rect.bottom);
		drawtext(text, &rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}

	// 绘制详细信息
	void PageHandbook::_draw_detail_info(LPCTSTR text, bool large) const
	{
		settextcolor(COLOR::DETAIL);
		setbkmode(TRANSPARENT);
		if (large)
		{
			settextstyle(FONT_SIZE::DETAIL_INFO_LARGE, 0, FONT::DETAIL_FONT);
		}
		else
		{
			settextstyle(FONT_SIZE::DETAIL_INFO, 0, FONT::DETAIL_FONT);
		}
		RECT rect = { 148, 270, 1052, 740 };
		// 绘制与背景色相同的矩形，以覆盖上一页的文字
		setfillcolor(COLOR::BACKGROUND_INFO);
		solidrectangle(rect.left, rect.top, rect.right, rect.bottom);
		drawtext(text, &rect, DT_WORDBREAK | DT_EXPANDTABS);
	}

	// 绘制分割线
	void PageHandbook::_draw_divider() const
	{
		setlinecolor(COLOR::DIVIDER);
		setlinestyle(PS_SOLID, 2);
		rectangle(20, 200, 1182, 780);
		setfillcolor(COLOR::BACKGROUND_INFO);
		fillrectangle(140, 200, 1062, 780);
	}

	// 绘制区域文字
	void PageHandbook::_draw_region_text() const
	{
		RECT left_rect = { 20, 215, 140, 300 }; // 左侧区域
		RECT right_rect = { 1061, 215, 1181, 275 }; // 右侧区域
		RECT bottom_rect = { 140, 740, 1060, 780 }; // 底部区域
		rectangle(bottom_rect.left, bottom_rect.top, bottom_rect.right, bottom_rect.bottom);
		LPCTSTR left_text = _T("Element Functions Preview");
		LPCTSTR right_text = _T("Helps");
		LPCTSTR bottom_text = _T(
			"- You can press &arrow keys to move the player in the left."
		);
		settextcolor(COLOR::REGION_TITLE);
		settextstyle(FONT_SIZE::DETAIL_INFO, 0, FONT::BRIEF_FONT);
		drawtext(left_text, &left_rect, DT_WORDBREAK | DT_CENTER);
		settextstyle(FONT_SIZE::DETAIL_INFO_LARGE, 0, FONT::BRIEF_FONT);
		drawtext(right_text, &right_rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
		settextcolor(COLOR::BOTTOM_TIPS);
		settextstyle(FONT_SIZE::DETAIL_INFO, 0, FONT::BRIEF_FONT);
		drawtext(bottom_text, &bottom_rect, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	}

	// 设置游戏预览区
	void PageHandbook::set_preview(TYPE type)
	{
		// 绘制游戏区背景，覆盖原来的元素
		setfillcolor(COLOR::BACKGROUND);
		setlinecolor(COLOR::DIVIDER);
		setlinestyle(PS_SOLID, 2);
		fillrectangle(20, playground.get_y(), 140, 780);
		// 清除元素数据
		element_data.clear_elements(false);
		// 根据元素类型设置元素
		switch (type)
		{
		case TYPE::PLAYER:
		{
			element_data.set_element(TYPE::PLAYER, 9, 0, false);
			break;
		}
		case TYPE::KEY:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::KEY, 10, 1, false);
			element_data.set_element(TYPE::KEY, 9, 0, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::FLAG:
		{
			element_data.set_element(TYPE::PLAYER, 9, 0, false);
			element_data.set_element(TYPE::FLAG, 9, 2, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			break;
		}
		case TYPE::BRICK:
		{
			element_data.set_element(TYPE::PLAYER, 5, 1, false);
			element_data.set_element(TYPE::BRICK, 2, 1, false);
			element_data.set_element(TYPE::BRICK, 4, 0, false);
			element_data.set_element(TYPE::BRICK, 4, 2, false);
			element_data.set_element(TYPE::BRICK, 6, 1, false);
			element_data.set_element(TYPE::BRICK, 8, 0, false);
			element_data.set_element(TYPE::BRICK, 8, 2, false);
			element_data.set_element(TYPE::BRICK, 10, 1, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::FIRE:
		{
			element_data.set_element(TYPE::PLAYER, 8, 2, false);
			element_data.set_element(TYPE::FIRE, 8, 0, false);
			element_data.set_element(TYPE::KEY, 6, 1, false);
			element_data.set_element(TYPE::FIRE, 9, 0, false);
			element_data.set_element(TYPE::FIRE, 9, 1, false);
			element_data.set_element(TYPE::FIRE, 10, 0, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::COIN:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 6; i <= 9; i++)
			{
				for (int j = 0; j <= 2; j++)
				{
					element_data.set_element(TYPE::COIN, i, j, false);
				}
			}
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::SUPER_SHOE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::SUPER_SHOE, 7, 0, false);
			for (int i = 10; i >= 4; i--)
			{
				element_data.set_element(TYPE::BRICK, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::WINGS:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::WINGS, 10, 1, false);
			for (int i = 9; i >= 6; i--)
			{
				element_data.set_element(TYPE::FIRE, i, 1, false);
			}
			element_data.set_element(TYPE::KEY, 4, 2, false);
			element_data.set_element(TYPE::FLAG, 10, 2, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::POISON:
		{
			element_data.set_element(TYPE::PLAYER, 9, 0, false);
			element_data.set_element(TYPE::POISON, 10, 0, false);
			element_data.set_element(TYPE::POISON, 11, 2, false);
			for (int i = 10; i >= 9; i--)
			{
				element_data.set_element(TYPE::BRICK, i, 1, false);
			}
			for (int i = 7; i >= 5; i--)
			{
				element_data.set_element(TYPE::BRICK, i, 0, false);
			}
			for (int i = 10; i >= 7; i--)
			{
				element_data.set_element(TYPE::BRICK, i, 2, false);
			}
			element_data.set_element(TYPE::FLAG, 4, 0, false);
			break;
		}
		case TYPE::ANTIDOTE:
		{
			element_data.set_element(TYPE::PLAYER, 9, 0, false);
			element_data.set_element(TYPE::POISON, 10, 0, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			element_data.set_element(TYPE::ANTIDOTE, 8, 1, false);
			element_data.set_element(TYPE::KEY, 6, 0, false);
			element_data.set_element(TYPE::FLAG, 6, 2, false);
			break;
		}
		case TYPE::STONE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::STONE, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::RED_STONE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::RED_STONE, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::ORANGE_STONE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::ORANGE_STONE, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::YELLOW_STONE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::YELLOW_STONE, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::GREEN_STONE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::GREEN_STONE, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::CYAN_STONE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::CYAN_STONE, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::BLUE_STONE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::BLUE_STONE, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::PURPLE_STONE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::PURPLE_STONE, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::PINK_STONE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::PINK_STONE, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::WHITE_STONE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::WHITE_STONE, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::ONE_USED_DOOR:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::BRICK, 9, 0, false);
			element_data.set_element(TYPE::ONE_USED_DOOR, 10, 1, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			element_data.set_element(TYPE::KEY, 9, 2, false);
			element_data.set_element(TYPE::FLAG, 9, 1, false);
			break;
		}
		case TYPE::UP_RIGHT_TUBE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::STONE, 10, 1, false);
			element_data.set_element(TYPE::UP_RIGHT_TUBE, 9, 0, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::NO_UP_TUBE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 1, false);
			element_data.set_element(TYPE::STONE, 10, 0, false);
			element_data.set_element(TYPE::STONE, 10, 2, false);
			element_data.set_element(TYPE::NO_UP_TUBE, 9, 1, false);
			element_data.set_element(TYPE::KEY, 9, 0, false);
			element_data.set_element(TYPE::FLAG, 9, 2, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			break;
		}
		case TYPE::UP_LEFT_TUBE:
		{
			element_data.set_element(TYPE::PLAYER, 10, 2, false);
			element_data.set_element(TYPE::STONE, 10, 1, false);
			element_data.set_element(TYPE::KEY, 10, 0, false);
			element_data.set_element(TYPE::UP_LEFT_TUBE, 9, 2, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::NO_LEFT_TUBE:
		{
			element_data.set_element(TYPE::NO_LEFT_TUBE, 8, 0, false);
			element_data.set_element(TYPE::PLAYER, 9, 2, false);
			element_data.set_element(TYPE::NO_LEFT_TUBE, 9, 1, false);
			element_data.set_element(TYPE::FLAG, 10, 0, false);
			element_data.set_element(TYPE::KEY, 9, 0, false);
			element_data.set_element(TYPE::STONE, 10, 2, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			break;
		}
		case TYPE::INTERSECT_TUBE:
		{
			element_data.set_element(TYPE::PLAYER, 7, 2, false);
			element_data.set_element(TYPE::STONE, 8, 2, false);
			for (int i = 0; i <= 2; i++)
			{
				element_data.set_element(TYPE::INTERSECT_TUBE, 9, i, false);
				element_data.set_element(TYPE::INTERSECT_TUBE, 10, i, false);
			}
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::NO_RIGHT_TUBE:
		{
			element_data.set_element(TYPE::NO_RIGHT_TUBE, 8, 2, false);
			element_data.set_element(TYPE::PLAYER, 9, 0, false);
			element_data.set_element(TYPE::NO_RIGHT_TUBE, 9, 1, false);
			element_data.set_element(TYPE::FLAG, 10, 2, false);
			element_data.set_element(TYPE::KEY, 9, 2, false);
			element_data.set_element(TYPE::STONE, 10, 0, false);
			element_data.set_element(TYPE::BRICK, 11, 0, false);
			break;
		}
		case TYPE::DOWN_RIGHT_TUBE:
		{
			element_data.set_element(TYPE::PLAYER, 9, 0, false);
			element_data.set_element(TYPE::STONE, 9, 1, false);
			element_data.set_element(TYPE::DOWN_RIGHT_TUBE, 10, 0, false);
			element_data.set_element(TYPE::COIN, 10, 1, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::NO_DOWN_TUBE:
		{
			element_data.set_element(TYPE::STONE, 8, 0, false);
			element_data.set_element(TYPE::PLAYER, 8, 1, false);
			element_data.set_element(TYPE::STONE, 8, 2, false);
			element_data.set_element(TYPE::NO_DOWN_TUBE, 9, 1, false);
			element_data.set_element(TYPE::FIRE, 10, 1, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::DOWN_LEFT_TUBE:
		{
			element_data.set_element(TYPE::STONE, 9, 1, false);
			element_data.set_element(TYPE::KEY, 9, 0, false);
			element_data.set_element(TYPE::COIN, 9, 2, false);
			element_data.set_element(TYPE::PLAYER, 10, 1, false);
			element_data.set_element(TYPE::FLAG, 10, 0, false);
			element_data.set_element(TYPE::DOWN_LEFT_TUBE, 10, 2, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			break;
		}
		case TYPE::HORIZONTAL_TUBE:
		{
			element_data.set_element(TYPE::STONE, 9, 0, false);
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::FIRE, 9, 1, false);
			element_data.set_element(TYPE::HORIZONTAL_TUBE, 10, 1, false);
			element_data.set_element(TYPE::FLAG, 9, 2, false);
			element_data.set_element(TYPE::STONE, 11, 2, false);
			break;
		}
		case TYPE::VERTICAL_TUBE:
		{
			element_data.set_element(TYPE::PLAYER, 6, 0, false);
			element_data.set_element(TYPE::STONE, 7, 0, false);
			element_data.set_element(TYPE::VERTICAL_TUBE, 7, 1, false);
			element_data.set_element(TYPE::STONE, 7, 2, false);
			for (int i = 10; i >= 8; i--)
			{
				element_data.set_element(TYPE::FIRE, i, 0, false);
				if (i != 10) 
					element_data.set_element(TYPE::VERTICAL_TUBE, i, 1, false);
				element_data.set_element(TYPE::FIRE, i, 2, false);
			}
			element_data.set_element(TYPE::FLAG, 10, 1, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			break;
		}
		case TYPE::SOIL:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 9; i >= 7; i--)
			{
				element_data.set_element(TYPE::SOIL, i, 0, false);
				element_data.set_element(TYPE::SOIL, i, 1, false);
				element_data.set_element(TYPE::SOIL, i, 2, false);
			}
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			element_data.set_element(TYPE::FLAG, 6, 2, false);
			break;
		}
		case TYPE::WATER:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 9; i >= 5; i--)
			{
				element_data.set_element(TYPE::WATER, i, 0, false);
				element_data.set_element(TYPE::BLUE_STONE, i, 1, false);
				element_data.set_element(TYPE::WATER, i, 2, false);
			}
			element_data.set_element(TYPE::BRICK, 10, 1, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		case TYPE::LADDER:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::KEY, 10, 2, false);
			for (int i = 9; i >= 3; i--)
			{
				element_data.set_element(TYPE::LADDER, i, 0, false);
				element_data.set_element(TYPE::LADDER, i, 2, false);
			}
			element_data.set_element(TYPE::COIN, 2, 0, false);
			element_data.set_element(TYPE::FLAG, 2, 2, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			break;
		}
		case TYPE::TRANSPARENT_BRICK:
		{
			element_data.set_element(TYPE::TRANSPARENT_BRICK, 6, 1, false);
			element_data.set_element(TYPE::TRANSPARENT_BRICK, 6, 2, false);
			element_data.set_element(TYPE::PLAYER, 7, 0, false);
			element_data.set_element(TYPE::FLAG, 5, 2, false);
			element_data.set_element(TYPE::TRANSPARENT_BRICK, 9, 0, false);
			element_data.set_element(TYPE::TRANSPARENT_BRICK, 9, 1, false);
			element_data.set_element(TYPE::KEY, 10, 1, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			break;
		}
		case TYPE::LEFT_CONVEYOR:
		{
			element_data.set_element(TYPE::LEFT_CONVEYOR, 11, 2, false);
			element_data.set_element(TYPE::PLAYER, 7, 2, false);
			element_data.set_element(TYPE::LEFT_CONVEYOR, 9, 2, false);
			element_data.set_element(TYPE::LEFT_CONVEYOR, 9, 1, false);
			element_data.set_element(TYPE::FLAG, 10, 2, false);
			break;
		}
		case TYPE::RIGHT_CONVEYOR:
		{
			element_data.set_element(TYPE::RIGHT_CONVEYOR, 11, 2, false);
			element_data.set_element(TYPE::PLAYER, 7, 0, false);
			element_data.set_element(TYPE::RIGHT_CONVEYOR, 9, 0, false);
			element_data.set_element(TYPE::RIGHT_CONVEYOR, 9, 1, false);
			element_data.set_element(TYPE::FLAG, 10, 0, false);
			break;
		}
		case TYPE::BOUNCE_BED:
		{
			element_data.set_element(TYPE::PLAYER, 9, 1, false);
			element_data.set_element(TYPE::RIGHT_CONVEYOR, 10, 1, false);
			element_data.set_element(TYPE::BOUNCE_BED, 11, 2, false);
			element_data.set_element(TYPE::FLAG, 1, 0, false);
			element_data.set_element(TYPE::KEY, 1, 2, false);
			break;
		}
		case TYPE::UP_BRICK_THRUST:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::BRICK, 10, 1, false);
			element_data.set_element(TYPE::BRICK, 9, 1, false);
			element_data.set_element(TYPE::BRICK, 8, 1, false);
			element_data.set_element(TYPE::UP_BRICK_THRUST, 7, 1, false);
			element_data.set_element(TYPE::COIN, 6, 1, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			
			break;
		}
		case TYPE::DOWN_BRICK_THRUST:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			element_data.set_element(TYPE::DOWN_BRICK_THRUST, 9, 0, false);
			element_data.set_element(TYPE::DOWN_BRICK_THRUST, 9, 1, false);
			element_data.set_element(TYPE::DOWN_BRICK_THRUST, 7, 2, false);
			element_data.set_element(TYPE::DOWN_BRICK_THRUST, 7, 1, false);
			element_data.set_element(TYPE::UP_LEFT_TUBE, 8, 2, false);
			element_data.set_element(TYPE::DOWN_LEFT_TUBE, 10, 2, false);
			element_data.set_element(TYPE::KEY, 9, 2, false);
			element_data.set_element(TYPE::FLAG, 5, 2, false);

			break;
		}
		case TYPE::LEFT_BRICK_THRUST:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			for (int i = 7; i <= 10; i++)
			{
				element_data.set_element(TYPE::LEFT_BRICK_THRUST, i, 1, false);
			}
			element_data.set_element(TYPE::KEY, 6, 1, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);

			break;
		}
		case TYPE::RIGHT_BRICK_THRUST:
		{
			element_data.set_element(TYPE::PLAYER, 9, 0, false);
			for (int i = 6; i <= 10; i++)
			{
				element_data.set_element(TYPE::RIGHT_BRICK_THRUST, i, 1, false);
			}
			element_data.set_element(TYPE::KEY, 9, 2, false);
			element_data.set_element(TYPE::STONE, 10, 2, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			element_data.set_element(TYPE::FLAG, 10, 0, false);
			break;
		}
		case TYPE::COIN_LOCKER:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::COIN_LOCKER, 11, 2, false);
			for (int i = 0; i <= 2; i++)
			{
				element_data.set_element(TYPE::COIN, 7, i, false);
				element_data.set_element(TYPE::COIN, 8, i, false);
			}
			element_data.set_element(TYPE::FLAG, 4, 1, false);
			break;
		}
		case TYPE::DOWN_LIFT:
		{
			element_data.set_element(TYPE::PLAYER, 4, 1, false);
			element_data.set_element(TYPE::DOWN_LIFT, 5, 1, false);
			element_data.set_element(TYPE::STONE, 6, 1, false);
			for (int i = 4; i <= 10; i++)
			{
				element_data.set_element(TYPE::DOWN_LIFT, i, 0, false);
				element_data.set_element(TYPE::DOWN_LIFT, i, 2, false);
			}
			for (int i = 7; i <= 9; i++)
			{
				element_data.set_element(TYPE::DOWN_LIFT, i, 1, false);
			}
			element_data.set_element(TYPE::FLAG, 10, 1, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			break;
		}
		case TYPE::UP_BUTTER_BRICK:
		{
			element_data.set_element(TYPE::PLAYER, 9, 0, false);
			for (int i = 0; i < 3; i++)
			{
				element_data.set_element(TYPE::UP_BUTTER_BRICK, 10, i, false);
			}
			element_data.set_element(TYPE::SUPER_SHOE, 9, 2, false);
			element_data.set_element(TYPE::FLAG, 8, 0, false);
			element_data.set_element(TYPE::POISON, 9, 1, false);
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			break;
		}
		case TYPE::DOWN_BUTTER_BRICK:
		{
			element_data.set_element(TYPE::PLAYER, 10, 0, false);
			element_data.set_element(TYPE::UP_BRICK_THRUST, 10, 1, false);
			element_data.set_element(TYPE::UP_BRICK_THRUST, 10, 2, false);
			for (int i = 0; i < 3; i++)
			{
				element_data.set_element(TYPE::DOWN_BUTTER_BRICK, 8, i, false);
			}
			element_data.set_element(TYPE::BRICK, 11, 2, false);
			element_data.set_element(TYPE::KEY, 9, 1, false);
			element_data.set_element(TYPE::FLAG, 9, 2, false);
			break;
		}
		case TYPE::TELEPORT_GATE:
		{
			element_data.set_element(TYPE::PLAYER, 6, 0, false);
			element_data.set_element(TYPE::TELEPORT_GATE, 10, 0, false);
			for (int i = 5; i < 10; i++)
			{
				element_data.set_element(TYPE::BRICK, i, 1, false);
			}
			element_data.set_element(TYPE::BRICK, 5, 0, false);
			element_data.set_element(TYPE::BRICK, 5, 2, false);
			element_data.set_element(TYPE::TELEPORT_GATE, 6, 2, false);
			element_data.set_element(TYPE::KEY, 10, 1, false);
			element_data.set_element(TYPE::FLAG, 11, 2, false);
			break;
		}
		default: 
			return;
		}
		// 绘制底部砖块
		for (int i = 0; i < 2; i++)
		{
			element_data.set_element(TYPE::BRICK, 11, i, false);
		}
		playground.transfer(element_data, nullptr, true);
	}

	// 监听面板选择事件
	void PageHandbook::_listen_panel_select(void)
	{
		// 如果面板没有选中任何元素，则不处理
		if (!select_panel.selected_not_empty()) return;
		// 如果选中元素类型发生变化，则更新元素展示区
		if (select_panel.selected_type() != _panel_selected_type)
		{
			// 清除右侧按钮记录
			_button_now = RIGHT_BUTTON::NONE;
			_panel_selected_type = select_panel.selected_type();
			// 将选中元素替换到元素展示区
			element_showcase.set_element(_panel_selected_type);
			show_element_info(_panel_selected_type);
			set_preview(_panel_selected_type);
		}
		// 元素动画更新
		if (element_showcase.get_element() != nullptr)
		{
			// 只有当使用性能模式时才更新
			if (game.sleep_time() == 0)
			{
				element_showcase.get_element()->update_animation();
			}
		}
	}

	// 监听按钮事件
	void PageHandbook::_listen_buttons(ExMessage& event)
	{
		button_select.listen_active(event);
		button_editor.listen_active(event);
		button_stage.listen_active(event);
		button_keydown.listen_active(event);
		if (button_select.clicked(event))
		{
			click_right_button(RIGHT_BUTTON::SELECT);
		}
		else if (button_editor.clicked(event))
		{
			click_right_button(RIGHT_BUTTON::EDITOR);
		}
		else if (button_stage.clicked(event))
		{
			click_right_button(RIGHT_BUTTON::STAGE);
		}
		else if (button_keydown.clicked(event))
		{
			click_right_button(RIGHT_BUTTON::KEYDOWN);
		}
		else if (button_exit.clicked(event))
		{
			exit_page();
			event.message = WM_NULL;
		}
	}

	// 监听键盘事件
	void PageHandbook::_listen_keyboard(ExMessage& event)
	{
		if (event.message == WM_KEYDOWN && !event.prevdown)
		{
			switch (event.vkcode)
			{
			case VK_ESCAPE: // 按下ESC键返回上一页
				exit_page();
				break;
			case VK_TAB: // 按下TAB键切换面板选中项
				// 如果同时按下SHIFT键，切换到上一个面板项
				if (GetAsyncKeyState(VK_SHIFT) & 0x8000)
				{
					select_panel.select_prev();
				}
				// 否则切换到下一个面板项
				else
				{
					select_panel.select_next();
				} 
			case VK_BACK: // 按下 backspace 或 R 键重新开始
			case 'R':
			case 'r':
				playground.replay();
				break;
			case '1': // 按下 1 键点击第一个按钮
				click_right_button(RIGHT_BUTTON::SELECT);
				break;
			case '2': // 按下 2 键点击第二个按钮
				click_right_button(RIGHT_BUTTON::EDITOR);
				break;
			case '3': // 按下 3 键点击第三个按钮
				click_right_button(RIGHT_BUTTON::STAGE);
				break;
			case '4': // 按下 4 键点击第四个按钮
				click_right_button(RIGHT_BUTTON::KEYDOWN);
				break;
			default:
				break;
			}
		}
	}

	// 监听游戏区事件
	void PageHandbook::_listen_playground(ExMessage& event)
	{
		// 当窗口最小化或失去焦点时，暂停游戏
		if (event.message != WM_MOVE && (
			event.wParam == Window::MINIMIZE ||
			event.wParam == Window::KILL_FOCUS))
		{
			if (!playground.paused())
			{
				playground.pause();
			}
			if (game.sleep_time() == 0) // 切换至能效模式
			{
				game.set_sleep_time(Game::DEFUALT_SLEEP_TIME);
			}
			return;
		}
		else if (playground.paused() && (event.message == 
			WM_ACTIVATE || event.message == WM_KEYDOWN))
		{
			if (game.sleep_time() != 0) // 切换至性能模式
			{
				game.set_sleep_time(0);
			}
			playground.resume();
		}
		if (element_data.has_player())
		{
			// 页面处于活动状态时，监听游戏区事件
			if (current_page() == this)
			{
				playground.listen_event(event);
			}
			// 玩家死亡或胜利后重播
			if (playground.player_died() || playground.player_won())
			{
				playground.replay();
			}
		}
	}

	// 监听页面事件
	void PageHandbook::listen_event(ExMessage& event)
	{
		select_panel.listen_select(event);
		_listen_panel_select();
		_listen_buttons(event);
		_listen_keyboard(event);
		_listen_playground(event);
	}
}