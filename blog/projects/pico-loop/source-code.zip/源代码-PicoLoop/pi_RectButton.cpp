﻿#include "picoloop.h"

// 矩形按钮类实现
namespace picoloop
{
	// RectButton 类构造函数
	RectButton::RectButton(int x, int y, int width, int height,
		int rx, int ry, int font_size, int border_thickness,
		int border_style, LPCTSTR text_content, LPCTSTR font_name, 
		COLORREF backgroud_color, COLORREF border_color, COLORREF text_color, 
		COLORREF hover_backgroud_color, COLORREF hover_border_color,
		COLORREF hover_text_color, COLORREF active_backgroud_color,
		COLORREF active_border_color, COLORREF active_text_color, 
		COLORREF disabled_color) :
		x(x), y(y), width(width), height(height), rx(rx), ry(ry),
		font_size(font_size), border_thickness(border_thickness),
		border_style(border_style), backgroud_color(backgroud_color),
		border_color(border_color), text_color(text_color),
		hover_backgroud_color(hover_backgroud_color),
		hover_border_color(hover_border_color), hover_text_color(hover_text_color),
		active_backgroud_color(active_backgroud_color),
		active_border_color(active_border_color),
		active_text_color(active_text_color), disabled_color(disabled_color) 
	{
		this->text_content = _tcsdup(text_content);
		this->font_name = _tcsdup(font_name);
	}

	// RectButton 析构函数
	RectButton::~RectButton()
	{
		// 必须释放由 _tcsdup 动态分配的内存
		std::free(text_content);
		std::free(font_name);
	}

	// 复制构造函数
	RectButton::RectButton(const RectButton& other) :
		x(other.x), y(other.y), width(other.width), height(other.height),
		rx(other.rx), ry(other.ry), font_size(other.font_size),
		border_thickness(other.border_thickness),
		border_style(other.border_style), backgroud_color(other.backgroud_color),
		border_color(other.border_color), text_color(other.text_color),
		hover_backgroud_color(other.hover_backgroud_color),
		hover_border_color(other.hover_border_color),
		hover_text_color(other.hover_text_color),
		active_backgroud_color(other.active_backgroud_color),
		active_border_color(other.active_border_color),
		active_text_color(other.active_text_color),
		disabled_color(other.disabled_color)
	{
		this->text_content = _tcsdup(other.text_content);
		this->font_name = _tcsdup(other.font_name);
	}

	// 拷贝赋值函数
	RectButton& RectButton::operator=(const RectButton& other)
	{
		if (this == &other)
		{
			return *this;
		}
		this->x = other.x;
		this->y = other.y;
		this->width = other.width;
		this->height = other.height;
		this->rx = other.rx;
		this->ry = other.ry;
		this->font_size = other.font_size;
		this->border_thickness = other.border_thickness;
		this->border_style = other.border_style;
		this->backgroud_color = other.backgroud_color;
		this->border_color = other.border_color;
		this->text_color = other.text_color;
		this->hover_backgroud_color = other.hover_backgroud_color;
		this->hover_border_color = other.hover_border_color;
		this->hover_text_color = other.hover_text_color;
		this->active_backgroud_color = other.active_backgroud_color;
		this->active_border_color = other.active_border_color;
		this->active_text_color = other.active_text_color;
		this->disabled_color = other.disabled_color;
		std::free(this->text_content);
		this->text_content = _tcsdup(other.text_content);
		std::free(this->font_name);
		this->font_name = _tcsdup(other.font_name);
		return *this;
	}

	// 绘制矩形按钮
	void RectButton::draw() const
	{
		// 应用样式
		_apply_styles();
		// 绘制矩形按钮
		fillroundrect(x, y, x + width, y + height, rx * 2, ry * 2);
		// 绘制文本
		RECT rect = { x + rx, y + ry, x + width, y + height};
		drawtext(text_content, &rect, DT_SINGLELINE | DT_CENTER | DT_VCENTER);
	}

	// 设置按钮文本内容
	void RectButton::set_text(LPCTSTR text)
	{
		free(text_content);
		text_content = _tcsdup(text);
		if (_has_drawn)
		{
			draw();
		}
	}
	// 应用样式
	void RectButton::_apply_styles() const
	{
		if (_is_hover) // 鼠标悬停
		{
			setfillcolor(hover_backgroud_color);
			setlinecolor(hover_border_color);
			settextcolor(hover_text_color);
		}
		else if (_is_active) // 按钮被按下
		{
			setfillcolor(active_backgroud_color);
			setlinecolor(active_border_color);
			settextcolor(active_text_color);
		}
		else if (_disabled) // 按钮被禁用
		{
			setfillcolor(disabled_color);
			setlinecolor(border_color);
			settextcolor(text_color);
		}
		else // 正常状态
		{
			setfillcolor(backgroud_color);
			setlinecolor(border_color);
			settextcolor(text_color);
		}
		setbkmode(TRANSPARENT);
		setlinestyle(border_style, border_thickness);
		settextstyle(font_size, 0, font_name);
	}
}