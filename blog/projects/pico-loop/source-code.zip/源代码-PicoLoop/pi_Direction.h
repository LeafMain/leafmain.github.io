﻿#pragma once

// 方向类声明
namespace picoloop
{
    /**
    * @brief 方向类
    */
    class Direction
    {
    public:
        Direction() = delete; // 删除默认构造函数
        // 方向枚举
        enum TYPE { UP, RIGHT, DOWN, LEFT, LENGTH, NONE };

        /**
        * @brief 判断两个方向是否相反
        */
        [[nodiscard]] static bool is_opposite(TYPE dir1, TYPE dir2);

        /**
        * @brief 获得相反方向
        */
        [[nodiscard]] static TYPE to_opposite(TYPE dir);
       
    };

    // 方向枚举
    typedef Direction::TYPE DIRECTION;
}