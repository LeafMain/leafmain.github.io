﻿#pragma once

// 元素选择面板类
namespace picoloop
{
	/**
	* @brief 元素选择面板类
	*/
	class PicoElementSelectPanel
	{
	public:
		const int X; // 元素选择面板左上角 x 坐标
		const int Y; // 元素选择面板左上角 y 坐标
		const int GRID_ROW = 26; // 网格行数
		const int GRID_COLUMN = 3; // 网格列数
		const int GRID_SIZE; // 网格大小
		COLORREF line_color; // 网格线颜色
		COLORREF hover_color; // 悬停颜色
		COLORREF select_color; // 选中颜色
		PicoElementSelectPanel(const PicoElementSelectPanel&) = delete;
		PicoElementSelectPanel& operator=(const PicoElementSelectPanel&) = delete;
		/**
		* @brief 元素选择面板类构造函数
		* @param x 元素选择面板左上角 x 坐标，默认为 0
		* @param y 元素选择面板左上角 y 坐标，默认为 0
		* @param grid_row 网格行数，默认为 26
		* @param grid_column 网格列数，默认为 3
		* @param grid_size 网格大小，默认为 30
		* @param line_color 网格线颜色，默认为 LIGHTGRAY
		* @param select_color 选中颜色，默认为 MAGENTA
		*/
		explicit PicoElementSelectPanel(int x = 0, int y = 0, int grid_row = 26, 
			int grid_column = 3, int grid_size = 30, 
			COLORREF line_color = LIGHTGRAY, COLORREF hover_color = LIGHTGREEN,
			COLORREF select_color = MAGENTA);
		/**
		* @brief 元素选择面板类析构函数
		*/
		virtual ~PicoElementSelectPanel();
		/**
		* @brief 绘制元素选择面板
		*/
		void draw() const;
		/**
		* @brief 监听选中事件
		* @param event 事件
		*/
		void listen_select(ExMessage& event);
		/**
		* @brief 监听键盘 tab 事件
		* @param event 事件
		*/
		void listen_tab(ExMessage& event);
		/**
		* @brief 获取整个网格宽度
		* @return 整个网格宽度
		*/
		[[nodiscard]] int get_width() const { return X + GRID_SIZE * GRID_COLUMN; }
		/**
		* @brief 获取整个网格高度
		* @return 整个网格高度
		*/
		[[nodiscard]] int get_height() const { return Y + GRID_SIZE * GRID_ROW; }
		/**
		* @brief 返回选中元素类型
		* @return 选中元素类型，如果没有选中元素则返回 LENGTH
		*/
		[[nodiscard]] PicoElementCollection::TYPE selected_type() const;
		/**
		* @brief 返回选中的元素是否非空
		* @return 如果非空则返回 true，否则返回 false
		*/
		[[nodiscard]] bool selected_not_empty() const;
		/**
		* @brief 移除选中元素
		*/
		void remove_select();
		/**
		* @brief 选中第一个非空元素
		*/
		void select_first();
		/**
		* @brief 选中上一个元素
		*/
		void select_prev();
		/**
		* @brief 选中下一个元素
		*/
		void select_next();
	protected:
		/**
		* @brief PicoElementSelectPanel 类保护构造函数
		* @brief 仅用于派生类使用，派生类必须对 elements 指针进行分配和释放
		*/
		explicit PicoElementSelectPanel(bool no_allocate, int x = 0, int y = 0,
			int grid_row = 26, int grid_column = 3, int grid_size = 30,
			COLORREF line_color = LIGHTGRAY,  COLORREF hover_color = LIGHTGREEN, 
			COLORREF select_color = MAGENTA);
		Grid grid; // 网格对象
		PicoElement*** elements; // 元素指针
	};
}