﻿#pragma once

// 对梯子元素类的声明
namespace picoloop
{
    /**
     * @brief 梯子元素类
     */
    class PicoLadderElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制梯子元素
        */
        void draw() const override;
        /**
         * @brief 克隆梯子元素
         * @return 克隆出的 PicoLadderElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoLadderElement(*this); }
    protected:
        /**
        * @brief 梯子元素被碰到时触发的事件
        * @param player 玩家对象
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 梯子元素被踩到时触发的事件
        * @param player 玩家对象
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
    };
}