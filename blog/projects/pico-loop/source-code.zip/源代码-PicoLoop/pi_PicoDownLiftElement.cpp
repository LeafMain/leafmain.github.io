﻿#include "picoloop.h"

// 对下降机元素类的实现
namespace picoloop
{
    // 绘制下降机元素
    void PicoDownLiftElement::draw() const
    {
        if (!_exist)
        {
            return; // 元素不存在则不绘制
        }
        _get_bk_image();
        setfillcolor(0x282828);
        setlinecolor(0x606060);
        setlinestyle(PS_SOLID, 1);
        fillrectangle(_40x(1), _40y(1), _40x(39), _40y(39));
        setlinecolor(0x858585);
        setlinestyle(PS_SOLID, _40x(2) - _40x(0));
        line(_40x(20), _40y(7), _40x(20), _40y(33));
        line(_40x(10), _40y(23), _40x(20), _40y(33));
        line(_40x(30), _40y(23), _40x(20), _40y(33));
        setlinestyle(PS_SOLID, 1);
    }

    // 重置元素数据
    void PicoDownLiftElement::reset_data()
    {
        base_reset();
        _exist = true;
        _jump_enabled = false;
    }

    // 下降机元素被踩时触发的事件
    void PicoDownLiftElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (!_exist)
            {
                return; // 不存在则不处理
            }
            if (first)
            {
                if (player.get_speed_y() > 0)
                {
                    player.enable_jump();
                    player.set_speed_y(10);
                    _jump_enabled = true;
                    _exist = false;
                    erase();
                }
                else
                {
                    player.disable_drop();
                    player.enable_jump();
                    _drop_disabled = true;
                }
                
            }
        }
        else
        {
            if (first)
            {
                if (_jump_enabled)
                {
                    player.disable_jump();
                    _jump_enabled = false;
                }
                else if (_drop_disabled)
                {
                    player.enable_drop();
                    player.disable_jump();
                    _drop_disabled = false;
                }
            }
        }
    }

    // 下降机元素被顶起时触发的事件
    void PicoDownLiftElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist)
        {
            return; // 不存在则不处理
        }
        if (occurred)
        {
            if (first)
            {
                player.stop_shift();
            }
        }
    }

    // 下降机元素向左推动时触发的事件
    void PicoDownLiftElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist)
        {
            return; // 不存在则不处理
        }
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
            }
        }
    }

    // 下降机元素向右推动时触发的事件
    void PicoDownLiftElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (!_exist)
        {
            return; // 不存在则不处理
        }
        if (occurred)
        {
            if (first)
            {
                player.disable_move_right();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_right();
            }
        }
    }
}