﻿#pragma once

// 页面抽象类声明
namespace picoloop
{
	class Game; // 依赖项
	/**
	* @brief 页面抽象类, 子类必须实现 
	* @brief public void listen_event(ExMessage& event)、
	* @brief protected void draw_page(void) const 方法
	* @note Page 类及其子类不可复制、不可移动
	*/
	class Page
	{
	public:
		Page(const Page&) = delete; // 删除拷贝构造函数
		Page(Page&&) = delete; // 删除移动构造函数
		Page& operator=(const Page&) = delete; // 删除拷贝赋值运算符
		Page& operator=(Page&&) = delete; // 删除移动赋值运算符

		using ID = size_t; // 页面ID类型
		/**
		* @brief Page 构造函数
		*/
		explicit Page(Game& game);
		/**
		* @brief Page 析构函数
		*/
		virtual ~Page();
		/**
		* @brief 监听事件
		*/
		virtual void listen_event(ExMessage& event) = 0;
		/**
		* @brief 获取页面ID
		* @return 页面ID
		*/
		[[nodiscard]] ID page_id() const { return _id; };
		/**
		* @brief 获取页面创建的数量
		* @return 页面创建的数量
		*/
		[[nodiscard]] static size_t pages_created() { return _counter; }
		/**
		* @brief 获取当前页面
		* @return 当前页面，不存在时返回 nullptr
		*/
		[[nodiscard]] static Page* current_page() { return _current_page; }
		/**
		* @brief 获取上一个页面
		* @return 上一个页面，不存在时返回 nullptr
		*/
		[[nodiscard]] static Page* previous_page() { return _previous_page; }
		/**
		* @brief 静态方法，进入页面
		* @param page 页面
		*/
		static void enter(Page* page);
		/**
		* @brief 静态方法，退出页面
		* @param page 页面
		*/
		static void leave(Page* page);
		/**
		* @brief 实例方法，进入页面
		* - 禁止常对象调用
		*/
		void enter() { enter(this); }
		/**
		* @brief 实例方法，退出页面
		* - 禁止常对象调用
		*/
		void leave() { leave(this); }
	protected:
		Game& game; // 游戏对象引用
		/**
		* @brief 绘制页面
		*/
		virtual void draw_page() const = 0;
		/**
		* @brief 擦除页面的绘制内容
		*/
		virtual void erase_page() const;
		/**
		* @brief 页面进入前调用
		*/
		virtual void on_enter();
		/**
		* @brief 页面进入后调用
		*/
		virtual void on_after_enter();
		/**
		* @brief 页面退出时调用
		*/
		virtual void on_leave();
	private:
		ID _id; // 页面ID
		static size_t _counter; // 页面创建的数量
		static Page* _current_page; // 当前页面指针
		static Page* _previous_page; // 上一个页面指针
	};
}