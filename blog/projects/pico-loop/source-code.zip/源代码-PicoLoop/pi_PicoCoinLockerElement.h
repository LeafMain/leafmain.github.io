﻿#pragma once

// 对金币锁柜元素类的声明
namespace picoloop
{
    /**
     * @brief 金币锁柜元素类
     */
    class PicoCoinLockerElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制金币锁柜元素
        */
        void draw() const override;
        /**
        * @brief 绘制未锁定金币锁柜元素
        */
        void draw_unlocked() const;
        /**
        * @brief 绘制锁定金币锁柜元素
        */
        void draw_locked() const;
        /**
        * @brief 重置元素数据
        */
        void reset_data() override;
        /**
        * @brief 判断是否锁住了金币
        * @return 是否锁住了金币
        */ 
        [[nodiscard]] bool locked() const { return _locked; }
        /**
         * @brief 克隆金币锁柜元素
         * @return 克隆出的 PicoCoinLockerElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoCoinLockerElement(*this); }
    protected:
        /**
        * @brief 金币锁柜元素被踩时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 金币锁柜元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 金币锁柜元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 金币锁柜元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
    private:
        bool _locked = false; // 是否锁住了金币
    };
}