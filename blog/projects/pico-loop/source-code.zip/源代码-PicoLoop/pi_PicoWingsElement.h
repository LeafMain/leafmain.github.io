﻿#pragma once

// Pico 翅膀类声明
namespace picoloop
{
    /**
    * @brief Pico 翅膀类
    */
    class PicoWingsElement : public PicoElement
    {
    public:
        static const int ROTATE_PART; // 旋转份数
        static const double ROTATE_ANGLE; // 旋转角度
        static const double ANIMATION_CYCLE; // 动画周期
        /**
        * @brief Pico 翅膀类构造函数
        * @param x 翅膀元素 x 坐标
        * @param y 翅膀元素 y 坐标
        * @param size 翅膀元素大小
        */
        PicoWingsElement(int x, int y, int size);
        /**
        * @brief 绘制翅膀元素
        */
        void draw() const override;
        /**
        * @brief 绘制旋转翅膀元素
        * @param rotate_part 旋转部分，0 - ROTATE_PART - 1
        */
        void draw_rotated(int rotate_part) const;
        /**
        * @brief 克隆翅膀元素
        * @return 克隆的翅膀元素指针，需要手动管理内存
        */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoWingsElement(*this); }
        /**
        * @brief 更新系统时钟
        */
        void update_clock() override;
        /**
        * @brief 更新翅膀元素动画
        */
        void update_animation() override;
        /**
        * @brief 重置翅膀元素数据
        */
        void reset_data() override;
        /**
        * @brief 翅膀是否存在
        * @return 翅膀是否存在，存在 true，不存在 false
        */
        [[nodiscard]] bool exist() const { return _exist; }
    protected:
        /**
        * @brief 玩家碰到翅膀时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生了按下事件
        * @param first 是否是第一次按下
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
    private:
        static constexpr double PI = 3.14159265358979323846;
        bool _exist = true; // 翅膀是否存在
        int _rotate_part = 0; // 旋转部分
        std::clock_t _last_clock = 0; // 上次更新时钟
        std::vector<int> _rotate_rx; // 旋转翅膀的 x 半轴
        bool _pre_calculated = false; // 是否已经预计算过旋转翅膀元素
        /**
        * @brief 绘制旋转翅膀元素
        * @param rotate_part 旋转部分，0 - ROTATE_PART - 1
        */
        void _draw_rotated(int rotate_part) const;
        /**
        * @brief 预计算旋转翅膀元素
        */
        void _pre_calculate();
    };
}