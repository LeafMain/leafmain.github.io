﻿#include "picoloop.h"

// 程序的入口
int main()
{
	// 用 static 创建大对象防止栈溢出
	static picoloop::Game game;
	try 
	{
		game.run();	// 运行游戏
	}
	catch (const std::exception& e)
	{
		// 报告异常
		game.report_exception(e);
		return 1;
	}
	return 0;
}