﻿#pragma once

// Pico 毒药类声明
namespace picoloop
{
    /**
    * @brief Pico 毒药类
    */
    class PicoPoisonElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制毒药元素
        */
        void draw() const override;
        /**
        * @brief 克隆毒药元素
        * @return 克隆的毒药元素指针，需要手动管理内存
        */
        [[nodiscard]] PicoElement* clone() const override 
        { return new PicoPoisonElement(*this); }
        /**
        * @brief 重置毒药元素数据
        */
        void reset_data() override;
        /**
        * @brief 毒药是否存在
        * @return 毒药是否存在，存在 true，不存在 false
        */
        [[nodiscard]] bool exist() const { return _exist; }
    protected:
        /**
        * @brief 玩家碰到毒药时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生了按下事件
        * @param first 是否是第一次按下
        */
        void on_bump(PicoPlayer& player, bool occurred, bool first) override;
    private:
        bool _exist = true; // 毒药是否存在
    };
}