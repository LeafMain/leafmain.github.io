﻿#pragma once

// 游戏文字类声明
namespace picoloop
{
	/**
	* @brief 游戏文字类
	*/
	class GameTitle
	{
	public:
		int x; // 位置 x 坐标
		int y; // 位置 y 坐标
		double scale; // 缩放比例

		/**
		* @brief 构造函数
		* @param x 位置 x 坐标，默认 0
		* @param y 位置 y 坐标，默认 0
		* @param scale 缩放比例，默认 1.0
		*/
		explicit GameTitle(int x = 0, int y = 0, double scale = 1.0) :
			x(x), y(y), scale(scale) {}
		/**
		* @brief 绘制游戏标题
		*/
		void draw() const;
		/**
		* @brief 获取游戏标题宽度
		* @return 宽度
		*/
		[[nodiscard]] int get_width() const
		{ return static_cast<int>(WIDTH * scale); }
		/**
		* @brief 获取游戏标题高度
		* @return 高度
		*/
		[[nodiscard]] int get_height() const
		{ return static_cast<int>(HEIGHT * scale); }

	private:
		// 31 * 5
		static const int WIDTH; // 宽度
		static const int HEIGHT; // 高度
		static constexpr int ALPHA_COUNT = 8; // 字母数量
		static const COLORREF ALPHA_COLOR[ALPHA_COUNT]; // 字母颜色数组

		/**
		* @brief 计算绝对 x 坐标
		* @param x 相对 x 坐标
		*/
		[[nodiscard]] int _ax(int x) const
		{ return static_cast<int>(std::round(x * scale)) + this->x; }

		/**
		* @brief 计算绝对 y 坐标
		* @param y 相对 y 坐标
		*/
		[[nodiscard]] int _ay(int y) const
		{ return static_cast<int>(std::round(y * scale)) + this->y; }
	};
}