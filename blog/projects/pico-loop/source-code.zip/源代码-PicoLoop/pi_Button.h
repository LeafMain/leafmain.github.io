﻿#pragma once

// 按钮抽象类声明
namespace picoloop
{
	/**
	* @brief 按钮抽象类，子类必须实现
	* @brief public void draw() const、
	* @brief public bool in_area(int x, int y) const 方法
	*/
	class Button
	{
	public:
		/**
		* @brief 绘制按钮
		*/
		virtual void draw() const = 0;
		/**
		* @brief 判断一个点是否在按钮区域内
		* @param x 要判断的 x 坐标
		* @param y 要判断的 y 坐标
		* @return true 在按钮区域内，false 不在按钮区域内
		*/
		[[nodiscard]] virtual bool in_area(int x, int y) const = 0;
		/**
		* @brief 监听鼠标悬停事件，做出响应
		* @param event 事件消息
		*/
		void listen_hover(ExMessage& event);
		/**
		* @brief 监听鼠标激活事件，做出响应
		* @param event 事件消息
		*/
		void listen_active(ExMessage& event);
		/**
		* @brief 判断按钮是否被点击
		* @param event 事件消息
		* @return true 被点击，false 未被点击
		*/
		[[nodiscard]] bool clicked(ExMessage& event) const;
		/**
		* @brief 判断按钮是否被按下
		* @param event 事件消息
		* @return true 被按下，false 未被按下
		*/
		[[nodiscard]] bool pressed(ExMessage& event) const;
		/**
		* @brief 判断按钮是否被悬停
		* @param event 事件消息
		* @return true 被悬停，false 未被悬停
		*/
		[[nodiscard]] bool hovered(ExMessage& event) const;
		/**
		* @brief 判断按钮是否被禁用
		* @return true 被禁用，false 未被禁用
		*/
		[[nodiscard]] bool disabled() const { return _disabled; }
		/**
		* @brief 设置按钮禁用状态
		* @param disabled true 禁用，false 启用
		*/
		void set_disabled(bool disabled);
	protected:
		mutable bool _has_drawn = false; // 缓存按钮是否已经绘制过
		bool _disabled = false; // 按钮是否被禁用
		bool _is_hover = false; // 鼠标是否悬停在按钮上
		bool _is_active = false; // 鼠标是否激活按钮
	};
}