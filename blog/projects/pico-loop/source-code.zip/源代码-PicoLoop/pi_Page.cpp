﻿#include "picoloop.h"

// 页面抽象类实现
namespace picoloop
{
	size_t Page::_counter = 0; // 页面计数器
	Page* Page::_current_page = nullptr; // 当前页面指针
	Page* Page::_previous_page = nullptr; // 上一个页面指针
		
	// Page 类构造函数
	Page::Page(Game& game) : game(game)
	{
		// 页面计数器自增
		_counter++;
		// 设置页面 ID 为当前计数器
		_id = _counter;
	}

	// Page 类析构函数
	Page::~Page()
	{
		// 页面计数器自减
		_counter--;
		// 清除页面 ID
		_id = 0;
	}

	// 静态方法，进入页面
	void Page::enter(Page* page)
	{
		// 页面为空时不进行操作
		if (page == nullptr) return;
		// 页面就是当前页面时不进行操作
		if (_current_page == page) return;
		// 退出当前页面
		if (_current_page != nullptr)
		{
			_current_page->on_leave(); // 页面退出前调用
			_current_page->erase_page(); // 绘制内容擦除
		}
		_previous_page = _current_page;
		// 进入新页面
		_current_page = page;
		_current_page->on_enter(); // 页面进入前调用
		_current_page->draw_page(); // 绘制页面
		_current_page->on_after_enter(); // 页面进入后调用
	}

	// 静态方法，退出页面
	void Page::leave(Page* page)
	{
		// 页面为空时不进行操作
		if (page == nullptr) return;
		// 页面不是当前页面时不进行操作
		if (_current_page != page) return;
		// 退出当前页面
		_current_page->on_leave(); // 页面退出前调用
		_current_page->erase_page(); // 绘制内容擦除
		_current_page = nullptr;
	}

	// 擦除页面的绘制内容
	void Page::erase_page() const
	{
		// 默认调用 cleardevice() 清除屏幕
		cleardevice();
	}

	// 页面进入前调用
	void Page::on_enter() {}

	// 页面进入后调用
	void Page::on_after_enter() {}

	// 页面退出时调用
	void Page::on_leave() {}
}