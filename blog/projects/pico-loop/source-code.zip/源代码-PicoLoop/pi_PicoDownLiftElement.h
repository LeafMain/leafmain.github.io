﻿#pragma once

// 对下降机元素类的声明
namespace picoloop
{
    /**
     * @brief 下降机元素类
     */
    class PicoDownLiftElement : public PicoElement
    {
    public:
        using PicoElement::PicoElement;
        /**
        * @brief 绘制下降机元素
        */
        void draw() const override;
        /**
        * @brief 重置元素数据
        */
        void reset_data() override;
        /**
        * @brief 判断下降机元素是否存在
        */
        [[nodiscard]] bool exist() const { return _exist; }
        /**
         * @brief 克隆下降机元素
         * @return 克隆出的 PicoDownLiftElement 实例
         * @param occurred 是否发生事件
         * @param first 是否第一次发生事件
         */
        [[nodiscard]] PicoElement* clone() const override
        {
            return new PicoDownLiftElement(*this);
        }
    protected:
        /**
        * @brief 下降机元素被踩时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_pedal(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 下降机元素被顶起时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_jump(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 下降机元素向左推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_left(PicoPlayer& player, bool occurred, bool first) override;
        /**
        * @brief 下降机元素向右推动时触发的事件
        * @param player 玩家对象
        * @param occurred 是否发生事件
        * @param first 是否第一次发生事件
        */
        void on_push_right(PicoPlayer& player, bool occurred, bool first) override;
    private:
        bool _exist = true; // 下降机元素是否存在
        bool _jump_enabled = false; // 是否启用了玩家跳跃
        bool _drop_disabled = false; // 是否禁用了玩家下降
    };
}