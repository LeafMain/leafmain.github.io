﻿#include "picoloop.h"

// Pico 解药类实现
namespace picoloop
{
    // 绘制解药元素
    void PicoAntidoteElement::draw() const
    {
        // 不存在时不绘制
        if (!_exist) return;
        _get_bk_image();
        // 绘制解药元素
        int a = 12, b = 40 - a, r = 9;
        int s = static_cast<int>(std::ceil((std::sqrt(2) * r / 2)));
        setlinestyle(PS_SOLID, 2); // 使用粗线条绘制药丸
        setlinecolor(0x277ec7);
        setfillcolor(0x277ec7);
        // 绘制药丸两个头
        fillcircle(_40x(a), _40y(b), _40x(r) - _40x(0));
        fillcircle(_40x(b), _40y(a), _40y(r) - _40y(0));
        // 绘制药丸身体
        const POINT points[4] =
        {
            _40x(a - s), _40y(b - s), _40x(b - s), _40y(a - s),
            _40x(b + s), _40y(a + s), _40x(a + s), _40y(b + s),
        };
        setfillcolor(0xeeffee);
        fillpolygon(points, 4);
        // 将画笔粗细还原，避免因其他元素忘记还原粗细而造成影响
        setlinestyle(PS_SOLID, 1);
    }

    // 重置解药元素数据
    void PicoAntidoteElement::reset_data()
    {
        base_reset(); // 调用基类的重置方法
        _exist = true;
    }

    // 玩家碰到解药时触发的事件
    void PicoAntidoteElement::on_bump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred && first)
        {
            if (_exist)
            {
                // 玩家获得解药，清除所有 buff
                player.set_buff(PicoPlayer::BUFF::NONE);
                // 销毁解药元素
                this->erase();
                _exist = false;
            }
        }
    }
}