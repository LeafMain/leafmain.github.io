﻿#include "picoloop.h"

// 对透明砖块元素类的实现
namespace picoloop
{
    // 绘制透明砖块元素
    void PicoTransparentBrickElement::draw() const
    {
        if (!_appeared)
        {
            draw_invisible();
        }
        else
        {
            draw_appeared();
        }
    }

    // 绘制不可见时的透明砖块元素
    void PicoTransparentBrickElement::draw_invisible() const
    {
        _get_bk_image();
        setlinecolor(0xbbbbbb);
        setlinestyle(PS_DASH, 1);
        rectangle(_40x(1), _40y(1), _40x(39), _40y(39));
        setlinestyle(PS_SOLID, 1);
    }

    // 绘制出现时的透明砖块元素
    void PicoTransparentBrickElement::draw_appeared() const
    {
        _get_bk_image();
        setfillcolor(0x002f85);
        solidrectangle(_40x(1), _40y(1), _40x(39), _40y(39));
    }

    // 重置透明砖块元素数据
    void PicoTransparentBrickElement::reset_data()
    {
        base_reset(); // 调用基类的重置数据函数
        _appeared = false; // 透明砖块元素存在
    }

    // 透明砖块元素被踩时触发的事件
    void PicoTransparentBrickElement::on_pedal(PicoPlayer& player, 
        bool occurred, bool first)
    {
        // 透明砖块元素未出现时，不响应踩踏事件
        if (!_appeared) return;
        if (occurred)
        {
            if (first)
            {
                player.disable_drop();
                player.enable_jump();
            }
        }
        else
        {
            if (first)
            {
                player.enable_drop();
                player.disable_jump();
            }
        }
    }

    // 透明砖块元素被顶起时触发的事件
    void PicoTransparentBrickElement::on_jump(PicoPlayer& player, 
        bool occurred, bool first)
    {
        if (occurred && first)
        {
            // 透明砖块元素被顶起时，
            // 只有当玩家是跳跃碰到的才会触发
            if (player.get_speed_y() <= 0)
            {
                if (!_appeared)
                {
                    player.stop_shift();
                    _appeared = true;
                    erase();
                    draw_appeared();
                }
                else
                {
                    player.stop_shift();
                }
            }
        }
    }

    // 透明砖块元素向左推动时触发的事件
    void PicoTransparentBrickElement::on_push_left(PicoPlayer& player, 
        bool occurred, bool first)
    {
        // 透明砖块元素未出现时，不响应左推事件
        if (!_appeared) return; 
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
            }
        }
    }

    // 透明砖块元素向右推动时触发的事件
    void PicoTransparentBrickElement::on_push_right(PicoPlayer& player, 
        bool occurred, bool first)
    {
        // 透明砖块元素未出现时，不响应右推事件
        if (!_appeared) return; 
        if (occurred)
        {
            if (first)
            {
                player.disable_move_right();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_right();
            }
        }
    }
}