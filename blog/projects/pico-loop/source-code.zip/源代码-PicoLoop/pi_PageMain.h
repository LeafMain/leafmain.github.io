﻿#pragma once

// 主页类声明
namespace picoloop
{
	/**
	* @brief 主页类
	*/
	class PageMain : public Page
	{
	public:
		/**
		* @brief PageMain 构造函数
		* @param game 游戏对象引用
		*/
		explicit PageMain(Game& game);
		/**
		* @brief 监听事件
		* @param event 事件
		*/
		void listen_event(ExMessage& event) override;
	protected:
		/**
		* @brief 显示主页
		*/
		void draw_page() const override;
		/**
		* @brief 页面进入时调用
		*/
		void on_enter() override;
		/**
		* @brief 页面进入绘制后调用
		*/
		void on_after_enter() override;
		/**
		* @brief 页面离开时调用
		*/
		void on_leave() override;
		
	private:
		struct COLOR // 颜色结构体
		{
			static const COLORREF BACKGROUND; // 背景颜色
			static const COLORREF PLAY_BUTTON; // 开始游戏按钮颜色
			static const COLORREF PLAY_BUTTON_BACKGROUD; // 开始游戏按钮背景颜色
			static const COLORREF PLAY_BUTTON_HOVER; // 开始游戏按钮悬停颜色
			static const COLORREF MAKE_BUTTON; // 制作游戏按钮颜色
			static const COLORREF MAKE_BUTTON_BACKGROUD; // 制作游戏按钮背景颜色
			static const COLORREF MAKE_BUTTON_HOVER; // 制作游戏按钮悬停颜色
			static const COLORREF EXIT_BUTTON; // 退出游戏按钮颜色
			static const COLORREF EXIT_BUTTON_HOVER; // 退出游戏按钮悬停颜色
			static const COLORREF AUTHOR_TEXT; // 作者文字颜色
		};

		struct FONT // 字体结构体
		{
			static const LPCTSTR BUTTON_FONT; // 按钮字体
			static const LPCTSTR AUTHOR_FONT; // 作者字体
		};
		GameTitle game_title; // 游戏标题对象
		RectButton play_button; // 开始游戏按钮对象
		RectButton make_button; // 制作游戏按钮对象
		RectButton exit_button; // 退出游戏按钮对象
		PicoElementEditor editor; // 元素创建对象
		PicoPlayground playground; // 游戏展示对象
		std::clock_t _enter_clock = 0; // 进入页面时时钟
		bool _playground_loaded = false; // 展示区是否加载
		bool _has_activated = false; // 窗口是否被激活
		/**
		* @brief 绘制作者信息
		*/
		void _draw_author_text() const;
		/**
		* @brief 创建游戏展示区
		*/
		void _create_playground();
		/**
		* @brief 重置时钟
		*/
		void _reset_clock();
		/**
		* @brief 监听展示区事件
		*/
		void _listen_playground(ExMessage& event);
		/**
		* @brief 监听操作事件
		*/
		void _listen_operate_event(ExMessage& event);
		/**
		* @brief 玩家向左运动的条件
		* @param diff 时间差的秒数
		* @return 在时间差内满足则返回 true
		*/
		[[nodiscard]] bool _player_left_if(double diff);
		/**
		* @brief 玩家向右运动的条件
		* @param diff 时间差的秒数
		* @return 在时间差内满足则返回 true
		*/
		[[nodiscard]] bool _player_right_if(double diff);
		/**
		* @brief 玩家向上运动的条件
		* @param diff 时间差的秒数
		* @return 在时间差内满足则返回 true
		*/
		[[nodiscard]] bool _player_up_if(double diff);
	};
}