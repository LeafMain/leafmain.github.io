﻿#include "picoloop.h"

// 对金币锁柜元素类的实现
namespace picoloop
{
    // 绘制金币锁柜元素
    void PicoCoinLockerElement::draw() const
    {
        if (_locked)
        {
            draw_locked();
        }
        else
        {
            draw_unlocked();
        }
    }

    // 绘制未锁定金币锁柜元素
    void PicoCoinLockerElement::draw_unlocked() const
    {
        _get_bk_image();
        // 绘制整体造型
        setlinestyle(PS_SOLID, 1);
        setlinecolor(0xaacaca);
        setfillcolor(0xb8bbbb);
        fillroundrect(_40x(1), _40y(1), _40x(39), _40y(39), 
            _40x(20) - _40x(0), _40y(20) - _40y(0));
        setfillcolor(0xbbcccc);
        solidrectangle(_40x(1), _40y(10), _40x(39), _40y(39));
        // 绘制中间矩形
        setfillcolor(0xc38237);
        solidrectangle(_40x(2), _40y(8), _40x(38), _40y(38));
        // 绘制金币
        setlinecolor(0x68a7b7);
        setfillcolor(0x55d5fa);
        fillcircle(_40x(20), _40y(23), _40x(12) - _40x(0));
        setfillcolor(0xc37237);
        solidrectangle(_40x(16), _40y(19), _40x(24), _40y(27));
    }

    // 绘制锁定金币锁柜元素
    void PicoCoinLockerElement::draw_locked() const
    {
        _get_bk_image();
        // 绘制整体造型
        setlinestyle(PS_SOLID, 1);
        setlinecolor(0xaabbbb);
        setfillcolor(0x989999);
        fillroundrect(_40x(1), _40y(1), _40x(39), _40y(39),
            _40x(20) - _40x(0), _40y(20) - _40y(0));
        setfillcolor(0xaabbbb);
        solidrectangle(_40x(1), _40y(10), _40x(39), _40y(39));
        // 绘制中间矩形
        setfillcolor(0x555555);
        solidrectangle(_40x(2), _40y(8), _40x(38), _40y(38));
        // 绘制金币
        setlinecolor(0x888888);
        setfillcolor(0x888888);
        fillcircle(_40x(20), _40y(23), _40x(12) - _40x(0));
        setfillcolor(0x555555);
        solidrectangle(_40x(16), _40y(19), _40x(24), _40y(27));
    }

    // 重置元素数据
    void PicoCoinLockerElement::reset_data()
    {
        base_reset();
        _locked = false;
    }

    // 金币锁柜元素被踩时触发的事件
    void PicoCoinLockerElement::on_pedal(PicoPlayer& player, bool occurred, bool first)
    {
        // 切换锁定状态
        if (player.coins_locked() != _locked)
        {
            _locked = player.coins_locked();
            erase();
            draw();
        }
        if (occurred)
        {
            if (first)
            {
                player.disable_drop();
                player.enable_jump();
                // 限制速度是为了防止上跳触发
                if (player.get_speed_y() >= 0)
                {
                    // 切换玩家金币锁状态
                    if (player.coins_locked())
                    {
                        player.unlock_all_coins();
                    }
                    else
                    {
                        player.lock_all_coins();
                    }
                }
            }
        }
        else
        {
            if (first)
            {
                player.enable_drop();
                player.disable_jump();
            }
        }
    }

    // 金币锁柜元素被顶起时触发的事件
    void PicoCoinLockerElement::on_jump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.stop_shift();
            }
        }
    }

    // 金币锁柜元素向左推动时触发的事件
    void PicoCoinLockerElement::on_push_left(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_left();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_left();
            }
        }
    }

    // 金币锁柜元素向右推动时触发的事件
    void PicoCoinLockerElement::on_push_right(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred)
        {
            if (first)
            {
                player.disable_move_right();
            }
        }
        else
        {
            if (first)
            {
                player.enable_move_right();
            }
        }
    }
}