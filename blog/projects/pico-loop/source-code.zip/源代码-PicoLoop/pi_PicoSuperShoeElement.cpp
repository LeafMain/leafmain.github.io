﻿#include "picoloop.h"

// Pico 超级跑鞋类实现
namespace picoloop
{
    // 绘制超级跑鞋元素
    void PicoSuperShoeElement::draw() const
    {
        // 不存在时不绘制
        if (!_exist) return;
        _get_bk_image();
        setlinecolor(0xff4289);
        setlinestyle(PS_SOLID, 1);
        setfillcolor(0xffa8cf);
        fillellipse(_40x(2), _40y(19), _40x(37), _40y(37));
        setfillcolor(0xff6faf);
        solidrectangle(_40x(19), _40y(12), _40x(37), _40y(36));
        setfillcolor(0xff187e);
        solidrectangle(_40x(19), _40y(9), _40x(37), _40y(12));
        setfillcolor(0x2b7eba);
        solidrectangle(_40x(16), _40y(4), _40x(37), _40y(10));
        setfillcolor(0xff6faf);
        solidellipse(_40x(14), _40y(19), _40x(23), _40y(37));
    }

    // 重置超级跑鞋元素数据
    void PicoSuperShoeElement::reset_data()
    {
        base_reset(); // 调用基类的重置方法
        _exist = true;
    }

    // 玩家碰到超级跑鞋时触发的事件
    void PicoSuperShoeElement::on_bump(PicoPlayer& player, bool occurred, bool first)
    {
        if (occurred && first)
        {
            if (_exist)
            {
                // 玩家获得超级跑鞋，获得超级 buff
                player.set_buff(PicoPlayer::BUFF::SUPER);
                // 销毁超级跑鞋元素
                this->erase();
                _exist = false;
            }
        }
    }
}