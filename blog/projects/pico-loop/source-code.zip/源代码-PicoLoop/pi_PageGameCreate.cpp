﻿#include "picoloop.h"

// 游戏创建页面静态常量定义
namespace picoloop
{
	const COLORREF PageGameCreate::COLOR::BACKGROUND = 0x111111; // 背景颜色
	const COLORREF PageGameCreate::COLOR::PANEL_LINE = DARKGRAY; // 面板线颜色
	const COLORREF PageGameCreate::COLOR::PANEL_SELECT = LIGHTGREEN; // 面板选中颜色
	const COLORREF PageGameCreate::COLOR::EDITOR_LINE = DARKGRAY; // 编辑器线颜色
	const COLORREF PageGameCreate::COLOR::EDITOR_HOVER = LIGHTGRAY; // 编辑器悬停颜色
	const COLORREF PageGameCreate::COLOR::EDITOR_SELECT = LIGHTGREEN; // 编辑器选中颜色
	const COLORREF PageGameCreate::COLOR::BUTTON_PLAY = 0x00FF00; // 开始按钮颜色
	const COLORREF PageGameCreate::COLOR::BUTTON_PLAY_HOVER = 0x008000; // 开始按钮鼠标悬停颜色
	const COLORREF PageGameCreate::COLOR::BUTTON_FUNCTIONAL = 0x008080; // 功能按钮颜色
	const COLORREF PageGameCreate::COLOR::BUTTON_FUNCTIONAL_HOVER = 0x004040; // 功能按钮鼠标悬停颜色
	const COLORREF PageGameCreate::COLOR::BUTTON_BACK = LIGHTGRAY; // 返回按钮颜色
	const COLORREF PageGameCreate::COLOR::BUTTON_BACK_HOVER = DARKGRAY; // 返回按钮鼠标悬停颜色
	const COLORREF PageGameCreate::COLOR::KEY_SHORTCUT = LIGHTGRAY; // 快捷键颜色
	const LPCTSTR PageGameCreate::FONT::BUTTON_FONT = _T("Arial Rounded MT Bold"); // 按钮字体
	const LPCTSTR PageGameCreate::FONT::KEY_SHORTCUT_FONT = _T("Arial"); // 快捷键字体
}

// 游戏创建页面类实现
namespace picoloop
{
	// 游戏创建页面类构造函数
	PageGameCreate::PageGameCreate(Game& game)
		: Page(game), 
		element_select_panel { // 面板选择元素
			1, 10, 26, 3, 30, COLOR::PANEL_LINE, 
			COLOR::PANEL_LINE, COLOR::PANEL_SELECT
		}, 
		element_editor{ // 元素编辑器
			100, 0, 20, 25, 40, COLOR::EDITOR_LINE,
			COLOR::EDITOR_HOVER, COLOR::EDITOR_SELECT
		}, 
		button_play{ // 开始按钮
			1110, 20, 80, 50, 2, 2, 34, 1, PS_SOLID,
			_T("Play"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_PLAY, COLOR::BUTTON_PLAY, COLOR::BACKGROUND,
			COLOR::BUTTON_PLAY_HOVER, COLOR::BUTTON_PLAY_HOVER
		}, 
		button_blur{ // 取消选择按钮
			1110, 80, 80, 50, 2, 2, 34, 1, PS_SOLID,
			_T("Blur"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL, COLOR::BUTTON_FUNCTIONAL, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL_HOVER, COLOR::BUTTON_FUNCTIONAL_HOVER
		}, 
		button_undo{ // 撤销按钮
			1110, 140, 80, 50, 2, 2, 30, 1, PS_SOLID,
			_T("Undo"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL, COLOR::BUTTON_FUNCTIONAL, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL_HOVER, COLOR::BUTTON_FUNCTIONAL_HOVER
		}, 
		button_redo{ // 重做按钮
			1110, 200, 80, 50, 2, 2, 30, 1, PS_SOLID,
			_T("Redo"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL, COLOR::BUTTON_FUNCTIONAL, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL_HOVER, COLOR::BUTTON_FUNCTIONAL_HOVER
		}, 
		button_delete{ // 删除按钮
			1110, 260, 80, 50, 2, 2, 27, 1, PS_SOLID,
			_T("Delete"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL, COLOR::BUTTON_FUNCTIONAL, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL_HOVER, COLOR::BUTTON_FUNCTIONAL_HOVER
		}, 
		button_clear{ // 清空按钮
			1110, 320, 80, 50, 2, 2, 29, 1, PS_SOLID,
			_T("Clear"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL, COLOR::BUTTON_FUNCTIONAL, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL_HOVER, COLOR::BUTTON_FUNCTIONAL_HOVER
		}, 
		button_save{ // 保存按钮
			1110, 380, 80, 50, 2, 2, 31, 1, PS_SOLID,
			_T("Save"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL, COLOR::BUTTON_FUNCTIONAL, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL_HOVER, COLOR::BUTTON_FUNCTIONAL_HOVER
		}, 
		button_back{ // 返回按钮
			1110, 675, 80, 50, 2, 2, 30, 1, PS_SOLID,
			_T("Back"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_BACK, COLOR::BUTTON_BACK, COLOR::BACKGROUND,
			COLOR::BUTTON_BACK_HOVER, COLOR::BUTTON_BACK_HOVER
		}, 
		button_help{ // 帮助按钮
			1110, 735, 80, 50, 2, 2, 31, 1, PS_SOLID,
			_T("Help"), FONT::BUTTON_FONT, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL, COLOR::BUTTON_FUNCTIONAL, COLOR::BACKGROUND,
			COLOR::BUTTON_FUNCTIONAL_HOVER, COLOR::BUTTON_FUNCTIONAL_HOVER
		}
	{}

	// 游戏创建页面类析构函数
	PageGameCreate::~PageGameCreate()
	{
		// 必须释放由 _tcsdup 创建的内存
		std::free(_game_name);
	}

	// 设置游戏名称
	void PageGameCreate::set_level_name(LPCTSTR level_name)
	{
		std::free(_game_name); // 释放之前的游戏名称
		_game_name = _tcsdup(level_name);
		game.page_playground.set_level_name(level_name);
		
	}

	// 设置关卡序号
	void PageGameCreate::set_level_number(int number)
	{
		_level_number = number;
		game.page_playground.set_level_number(number);
	}

	// 绘制页面
	void PageGameCreate::draw_page() const
	{
		setbkcolor(COLOR::BACKGROUND); // 设置背景颜色
		cleardevice();
		// 绘制元素选择面板
		element_select_panel.draw();
		element_editor.draw();
		// 绘制按钮
		button_play.draw();
		button_blur.draw();
		button_undo.draw();
		button_redo.draw();
		button_delete.draw();
		button_clear.draw();
		button_save.draw();
		button_back.draw();
		button_help.draw();
		// 绘制快捷键
		_draw_shortcuts();
	}

	// 开始游戏
	void PageGameCreate::play_game() 
	{
		if (element_editor.has_player())
		{
			element_editor.remove_select();
			save_data();
			// 设置标题和序号，进入游戏广场页面即可
			//game.page_playground.set_level_name(_game_name);
			//game.page_playground.set_level_number(_level_number);
			game.page_playground.enter();
			// 设置上一页面为本页面
			game.page_playground.set_previous_page(this);
		}
	}

	// 从文件加载数据
	void PageGameCreate::load_data(const std::string& file_name)
	{
		std::string parent = game.parent_path();
		std::ifstream file;
		file.open(parent + "\\Data\\" + file_name);
		_save_file_name = file_name;
		// 如果文件不存在，将元素数据全部设置为空元素
		if (!file)
		{
			_clear_elements_data();
			element_editor.set_elements_from_data(_elements_data, false);
			return;
		}
		// 如果文件存在，加载数据
		using TYPE = PicoElementCollection::TYPE;
		int data = 0;
		_elements_data.clear(); // 清空元素数据
		for (int row = 0; row < element_editor.GRID_ROW; row++)
		{
			_elements_data.push_back(std::vector<TYPE>());
			for (int col = 0; col < element_editor.GRID_COLUMN; col++)
			{
				// 一旦读取失败，将元素数据全部设置为空元素
				if (!(file >> data))
				{
					_clear_elements_data();
					element_editor.set_elements_from_data(_elements_data, false);
					return;
				}
				// 如果元素在枚举范围内，设置元素
				if (data >= TYPE::EMPTY && data < TYPE::LENGTH)
				{
					TYPE type = static_cast<TYPE>(data);
					_elements_data.at(row).push_back(type);
				}
				// 如果元素不在枚举范围内，设置为空元素
				else
				{
					_elements_data.at(row).push_back(TYPE::EMPTY);
				}
			}
		}
		element_editor.set_elements_from_data(_elements_data, false);
	}

	// 从元素数据中加载数据
	void PageGameCreate::load_data(const PicoElementCollection::Data&& data)
	{
		if (!data.empty())
		{
			this->_elements_data = data;
			element_editor.set_elements_from_data(_elements_data, false);
		}
	}

	// 保存数据
	void PageGameCreate::save_data()
	{
		if (_save_file_name.empty()) return;
		std::string parent = game.parent_path();
		std::ofstream file;
		file.open(parent + "\\Data\\" + _save_file_name);
		// 如果目录不存在，创建目录
		if (!file)
		{
			game.create_directories();
			file.open(parent + "\\Data\\" + _save_file_name);
		}
		// 保存游戏编辑器数据
		if (file)
		{
			// 保存元素编辑器数据
			auto editor_data = element_editor.get_elements_data();
			for (auto& row : editor_data)
			{
				for (auto& type : row)
				{
					file << static_cast<int>(type) << " ";
				}
				file << std::endl;
			}
		}
	}

	// 退出页面
	void PageGameCreate::exit_page()
	{
		// 进入制作选择页面即可
		game.page_make_select.enter();
	}

	// 进入帮助页面
	void PageGameCreate::enter_help()
	{
		game.page_handbook.enter();
	}

	// 页面离开时调用的方法
	void PageGameCreate::on_leave()
	{
		element_select_panel.remove_select();
		element_editor.remove_select();
	}

	// 监听事件
	void PageGameCreate::listen_event(ExMessage& event)
	{
		// 监听面板选择和元素编辑器
		element_select_panel.listen_select(event);
		element_select_panel.listen_tab(event);
		element_editor.listen_panel_event(event, element_select_panel);
		// 监听按钮的鼠标悬停事件
		button_play.listen_hover(event); 
		button_blur.listen_hover(event); 
		button_undo.listen_hover(event); 
		button_redo.listen_hover(event);
		button_delete.listen_hover(event); 
		button_clear.listen_hover(event); 
		button_save.listen_hover(event);
		button_back.listen_hover(event); 
		button_help.listen_hover(event);
		// 监听鼠标的点击事件
		if (event.message == WM_LBUTTONDOWN)
		{
			// 开始按钮被点击
			if (button_play.clicked(event))
			{
				play_game(); // 开始游戏
			}
			// 取消选择按钮被点击
			else if (button_blur.clicked(event))
			{
				// 移除面板和元素的选择
				element_editor.blur(element_select_panel);
			}
			// 撤销按钮被点击
			else if (button_undo.clicked(event))
			{
				element_editor.undo(); // 撤销操作
			}
			// 重做按钮被点击
			else if (button_redo.clicked(event))
			{
				element_editor.redo(); // 重做操作
			}
			// 删除按钮被点击
			else if (button_delete.clicked(event))
			{
				// 移除元素的选择
				element_editor.remove_selected_element();
			}
			// 清空按钮被点击
			else if (button_clear.clicked(event))
			{
				element_editor.clear_elements(); // 清空元素
			}
			// 保存按钮被点击
			else if (button_save.clicked(event))
			{
				save_data(); // 保存数据
			}
			// 返回按钮被点击
			else if (button_back.clicked(event))
			{
				exit_page(); // 退出页面
			}
			// 帮助按钮被点击
			else if (button_help.clicked(event))
			{
				event.message = WM_NULL; // 清空消息，防止重复触发
				enter_help(); // 进入帮助页面
			}
			// 当鼠标移至元素面板时，移除编辑器的选择
			const auto& pan = element_select_panel;
			if (event.x >= pan.X && event.x <= pan.X + pan.get_width() &&
				event.y >= pan.Y && event.y <= pan.Y + pan.get_height())
			{
				if (element_editor.selected_not_empty())
				{
					element_editor.remove_select();
				}
			}
		}
		// 按下 ctrl 组合键时监听组合键
		if (GetAsyncKeyState(VK_CONTROL) & 0x8000)
		{
			if (event.message == WM_KEYDOWN && !event.prevdown)
			{
				switch (event.vkcode)
				{
				case 'Z': // 按下 ctrl + z 组合键撤销
				case 'z':
					element_editor.undo();
					break;
				case 'Y': // 按下 ctrl + y 组合键重做
				case 'y':
					element_editor.redo();
					break;
				case VK_BACK: // 按下 ctrl + backspace / delete 组合键清空
				case VK_DELETE:
					element_editor.clear_elements();
					break;
				case 'B': // 按下 ctrl + b 组合键失去焦点
				case 'b':
					// 移除面板和元素的选择
					element_select_panel.remove_select();
					element_editor.remove_select();
					break;
				case 'S': // 按下 ctrl + s 组合键保存数据
				case 's':
					save_data();
					break;
				case 'H': // 按下 ctrl + h 组合键进入帮助页面
				case 'h':
					enter_help();
					break;
				}
			}
		}
		// 没有按下 ctrl 键时，要监听的按键
		else
		{
			if (event.message == WM_KEYDOWN && !event.prevdown)
			{
				switch (event.vkcode)
				{
				case VK_RETURN: // 按下回车键，开始游戏
					play_game();
					break;
				case VK_SPACE: // 按下空格键，移除面板和元素的选择
					element_editor.blur(element_select_panel);
					break;
				case VK_BACK: // 按下 backsapce 键，删除选中元素
					element_editor.remove_selected_element();
					break;
				case VK_DELETE: // 按下 delete 键，删除选中元素
					element_editor.remove_selected_element();
					break;
				case VK_F1: // 按下 F1 键，进入帮助页面
					enter_help();
					break;
				case VK_ESCAPE: // 按下 escape 键，退出页面
					exit_page();
					break;
				}
			}
		}
	}

	// @brief 绘制快捷键
	void PageGameCreate::_draw_shortcuts() const
	{
		settextcolor(COLOR::KEY_SHORTCUT);
		settextstyle(15, 0, FONT::KEY_SHORTCUT_FONT);
		RECT area = { 1105, 445, 1195, 655 };
		LPCTSTR text = _T(
			"Enter: Play\nBackspace: Blur\n\n"
			"Ctrl + Z: Undo\nCtrl + Y: Redo\n\n"
			"Right Button / Delete: Delete\n"
			"Ctrl + Delete: Clear all\n\n"
			"Ctrl + S: Save\nEsc: Back\nCtrl + H: Help"
		);
		drawtext(text, &area, DT_CENTER | DT_WORDBREAK);
	}

	// 清除元素数据
	void PageGameCreate::_clear_elements_data()
	{
		using TYPE = PicoElementCollection::TYPE;
		_elements_data.clear(); // 清空元素数据
		for (int row = 0; row < element_editor.GRID_ROW; row++)
		{
			_elements_data.push_back(std::vector<TYPE>());
			for (int col = 0; col < element_editor.GRID_COLUMN; col++)
			{
				_elements_data.at(row).push_back(TYPE::EMPTY);
			}
		}
	}
}