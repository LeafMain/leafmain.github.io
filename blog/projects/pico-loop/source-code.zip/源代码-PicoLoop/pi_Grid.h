﻿#pragma once

// 网格类声明
namespace picoloop
{
	/**
	* @brief 网格类
	*/
	class Grid
	{
	public:
		/**
		* @brief Grid 构造函数
		* @param x 网格左上角横坐标，默认为 0
		* @param y 网格左上角纵坐标，默认为 0
		* @param row 网格行数，默认为 4
		* @param column 网格列数，默认为 4
		* @param size 网格大小，默认为 16
		* @param line_width 网格线宽度，默认为 1
		* @param line_type 网格线类型，默认为 PS_SOLID
		* @param line_color 网格线颜色，默认为WHITE
		* @param hover_color 鼠标悬停颜色，默认为GREEN
		* @param active_color 鼠标按下颜色，默认为MAGENTA
		*/
		explicit Grid(int x = 0, int y = 0, int row = 4, int column = 4,
			int size = 16, int line_width = 1, int line_type = PS_SOLID,
			COLORREF line_color = WHITE, COLORREF hover_color = GREEN,
			COLORREF active_color = MAGENTA) :
			X(x), Y(y), ROW(row), COLUMN(column), SIZE(size),
			line_width(line_width), line_type(line_type), 
			line_color(line_color),hover_color(hover_color),
			active_color(active_color) {}
		/**
		* @brief 析构函数
		*/
		const int X;  // 网格左上角横坐标
		const int Y;  // 网格左上角纵坐标
		const int ROW;  // 网格行数
		const int COLUMN;  // 网格列数
		const int SIZE;  // 网格大小
		int line_width;  // 网格线宽度
		int line_type;  // 网格线类型
		COLORREF line_color;  // 网格线颜色
		COLORREF hover_color;  // 鼠标悬停颜色
		COLORREF active_color;  // 鼠标按下颜色
		Grid& operator=(const Grid&) = delete;
		/**
		* @brief 判断点是否在网格区域内
		* @param x 点的横坐标
		* @param y 点的纵坐标
		* @return true 点在网格区域内，false 点不在网格区域内
		*/
		[[nodiscard]] bool in_area(int x, int y) const
		{ return x >= X && x <= X + ROW * SIZE && 
			y >= Y && y <= Y + COLUMN * SIZE; }
		/**
		* @brief 将列数转换为绝对坐标
		* @param column 列数
		* @return 绝对坐标
		*/
		[[nodiscard]] int abs_x(int column) const
		{ return X + column * SIZE; }
		/**
		* @brief 将行数转换为绝对坐标
		* @param row 行数
		* @return 绝对坐标
		*/
		[[nodiscard]] int abs_y(int row) const
		{ return Y + row * SIZE; }
		/**
		* @brief 将绝对坐标转换为列数
		* @param x 绝对坐标
		* @return 列数，可能超出网格范围
		*/
		[[nodiscard]] int to_column(int x) const
		{ return x < X ? -1 : (x - X) / SIZE; }
		/**
		* @brief 将绝对坐标转换为行数
		* @param y 绝对坐标
		* @return 行数，可能超出网格范围
		*/
		[[nodiscard]] int to_row(int y) const
		{ return y < Y ? -1 : (y - Y) / SIZE; }
		/**
		* @brief 判断行数和列数是否在网格限制的范围内
		* @param row 行数
		* @param column 列数
		* @return true 行列在范围内，false 行列不在范围内
		*/
		[[nodiscard]] bool in_range(int row, int column) const
		{ return row >= 0 && row < ROW && column >= 0 && column < COLUMN; }

		/**
		* @brief 判断坐标是否在网格限制的范围内
		* @param x 坐标的横坐标
		* @param y 坐标的纵坐标
		* @return true 坐标在范围内，false 坐标不在范围内
		*/
		[[nodiscard]] bool in_grid(int x, int y) const
		{ return in_grid(to_row(y), to_column(x)); }

		/**
		* @brief 绘制网格线
		*/
		void draw() const;
		/**
		* @brief 补充网格线
		* @param row 补充的行数
		* @param column 补充的列数
		* @param hovered 是否为鼠标悬停状态
		*/
		void supple_grid(int row, int column) const;
		/**
		* @brief 监听鼠标悬停事件
		* @param event 鼠标事件
		*/
		void listen_hover(ExMessage& event);
		/**
		* @brief 监听网格选中事件
		* @param event 鼠标事件
		*/
		void listen_active(ExMessage& event);
		/**
		* @brief 判断是否有鼠标悬停
		* @return true 有鼠标悬停，false 没有鼠标悬停
		*/
		[[nodiscard]] bool has_hover() const 
		{ return _hover_row >= 0 && _hover_column >= 0; }
		/**
		* @brief 判断是否有选中网格
		* @return true 有鼠标选中网格，false 没有选中网格
		*/
		[[nodiscard]] bool has_active() const 
		{ return _active_row >= 0 && _active_column >= 0; }
		/**
		* @brief 获取鼠标悬停的行数
		* @return 鼠标悬停的行数
		*/
		[[nodiscard]] int hover_row() const { return _hover_row; }
		/**
		* @brief 获取鼠标悬停的列数
		* @return 鼠标悬停的列数
		*/
		[[nodiscard]] int hover_column() const { return _hover_column; }
		/**
		* @brief 获取鼠标按下时的行数
		* @return 鼠标按下时的行数
		*/
		[[nodiscard]] int active_row() const { return _active_row; }
		/**
		* @brief 获取鼠标按下时的列数
		* @return 鼠标按下时的列数
		*/
		[[nodiscard]] int active_column() const { return _active_column; }
		/*
		* @brief 判断活动格是否与指定行列相邻
		* @param row 行数
		* @param column 列数
		* @return 如果激活格与指定行列相邻返回 true，否则返回 false
		*/
		[[nodiscard]] bool active_adjacent(int row, int column) const;
		/**
		* @brief 设置鼠标悬停的行列
		* @param row 行数
		* @param column 列数
		* @param over 是否覆盖绘制，默认 false
		*/
		void set_hover(int row, int column, bool over = false);
		/**
		* @brief 设置鼠标按下时的行列
		* @param row 行数
		* @param column 列数
		* @param over 是否覆盖绘制，默认 false
		*/
		void set_active(int row, int column, bool over = false);
		/**
		* @brief 移除鼠标悬停状态
		*/
		void remove_hover();
		/**
		* @brief 移除激活状态
		*/
		void remove_active();
	private:
		int _hover_row = -1;  // 鼠标悬停的行数
		int _hover_column = -1;  // 鼠标悬停的列数
		int _active_row = -1;  // 鼠标按下时的行数
		int _active_column = -1;  // 鼠标按下时的列数

		/**
		* @brief 绘制网格矩形辅助函数
		*/
		void _draw_rect(int row, int column, COLORREF line_color) const;

		/**
		* @brief 判断行列是否被激活
		* @param row 行数
		* @param column 列数
		* @return true 行列被激活，false 行列未被激活
		*/
		[[nodiscard]] bool _activated(int row, int column) const
		{ return _active_row == row && _active_column == column; }
	};
}